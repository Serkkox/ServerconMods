tag @s add end
function custom_ender_dragon:check_spreadplayers {distance:5}
effect give @s minecraft:blindness 2 0 true
effect give @s minecraft:darkness 2 0 true
effect give @s minecraft:resistance 10 4 true
clear @s minecraft:end_portal_frame

title @s subtitle {"translate":"roguecraft.title.ender_dragon.subtitle","color":"light_purple"}
title @s title {"translate":"roguecraft.title.ender_dragon.main","color":"light_purple"}