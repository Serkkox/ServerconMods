title @a[tag=ready_final] subtitle ""
$title @a[tag=ready_final] title {"text":"$(number)","bold":true,"color":"white"}
$execute as @a[tag=ready_final] at @s run playsound minecraft:block.note_block.hat master @s ~ ~ ~ 2 $(pitch)
execute as @a[tag=ready_final] at @s run playsound minecraft:block.note_block.bass master @s ~ ~ ~ 0.4 0.5