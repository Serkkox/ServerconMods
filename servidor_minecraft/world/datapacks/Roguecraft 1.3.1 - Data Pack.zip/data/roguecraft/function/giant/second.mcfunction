#set bossbar
$bossbar set roguecraft:boss_$(boss_id) players @a[gamemode=!spectator,distance=..96]

#check if in new chunk
execute store success storage roguecraft:master success byte 1 run forceload add ~ ~
execute unless data storage roguecraft:master {success:1b} run return 0

#remove forceload nearby
forceload remove ~16 ~16 ~16 ~-16
forceload remove ~-16 ~16 ~-16 ~-16
forceload remove ~ ~16
forceload remove ~ ~-16