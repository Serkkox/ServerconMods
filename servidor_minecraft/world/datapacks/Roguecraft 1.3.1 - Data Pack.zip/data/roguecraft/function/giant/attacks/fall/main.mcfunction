particle minecraft:explosion ~ ~ ~ 3 0.8 3 0 50
playsound minecraft:entity.breeze.wind_burst master @a ~ ~ ~ 2 0.7
playsound minecraft:entity.generic.explode master @a ~ ~ ~ 0.5 1.5
execute positioned ~-6 ~1 ~-6 as @e[type=!minecraft:item,dx=12,dy=2,dz=12,tag=!giant] if data entity @s {OnGround:1b} run damage @s 10
execute if data entity @s {OnGround:1b} run tag @s remove fall