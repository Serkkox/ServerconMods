playsound minecraft:block.enchantment_table.use master @a ~ ~ ~ 2 1.5
playsound minecraft:entity.generic.explode player @a ~ ~ ~ 0.2 1.5
summon minecraft:marker ~ ~6 ~ {Tags:["giant_shockbolt"]}

scoreboard players set @s attack_cooldown 130
scoreboard players set @s last_attack 7