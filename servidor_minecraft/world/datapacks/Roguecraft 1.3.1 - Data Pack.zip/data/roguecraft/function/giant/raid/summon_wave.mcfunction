tag @s remove current_main

execute at @a[distance=..192] facing entity @s eyes as @p run playsound minecraft:item.goat_horn.sound.2 master @s ^ ^ ^20 2 1 1

$function roguecraft:giant/raid/spawn/wave_$(wave)
spreadplayers ~ ~ 0 5 false @e[tag=raid_member,distance=..1]
kill @s