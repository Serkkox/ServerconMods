$bossbar add roguecraft:boss_$(id) [{"translate":"event.minecraft.raid"},": ",{"translate":"roguecraft.bossbar.wave","with":["1"]}]
$bossbar set roguecraft:boss_$(id) color red
$bossbar set roguecraft:boss_$(id) max 300
$bossbar set roguecraft:boss_$(id) style notched_10
$bossbar set roguecraft:boss_$(id) players @a[distance=..96]