# post raid stuff
tellraw @a[distance=..256] {"translate":"roguecraft.dialogue.raid_4","color":"#ff8800","with":[{"translate":"roguecraft.dialogue_name.raid"}]}
execute as @a[distance=..256] at @s run playsound minecraft:entity.pillager.ambient voice @s ~ ~ ~ 0.5 0.9

# summon giant marker
summon minecraft:marker ~ ~ ~ {Tags:["giant_spawner"]}
spreadplayers ~ ~ 64 16 false @e[tag=giant_spawner,distance=..1]

kill @s

# check multiple distances in case the spawner spawns really high or low or something
execute as @n[tag=giant_spawner,distance=..200] at @s run return run function roguecraft:giant/spawn_1
execute as @n[tag=giant_spawner,distance=..400] at @s run return run function roguecraft:giant/spawn_1
execute as @n[tag=giant_spawner] at @s run return run function roguecraft:giant/spawn_1