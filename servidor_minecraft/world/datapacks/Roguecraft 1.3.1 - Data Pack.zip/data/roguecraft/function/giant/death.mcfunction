execute at @s unless entity @a[distance=..512] run return 0

$bossbar remove roguecraft:boss_$(boss_id)

#particles
execute positioned ~ ~3.4 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:0,total_steps:5,vertical:0,other_angle:5,particle_type:"minecraft:end_rod",speed:0.0000000009,force:"force"}
execute positioned ~ ~3.4 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:0,total_steps:64,vertical:0,other_angle:7,particle_type:"minecraft:end_rod",speed:0.0000000012,force:"force"}
execute positioned ~ ~3.4 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:0,total_steps:10,vertical:0,other_angle:10,particle_type:"minecraft:end_rod",speed:0.0000000016,force:"force"}

execute positioned ~ ~3.4 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:0,total_steps:5,vertical:1,other_angle:5,particle_type:"minecraft:end_rod",speed:0.0000000009,force:"force"}
execute positioned ~ ~3.4 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:0,total_steps:64,vertical:1,other_angle:7,particle_type:"minecraft:end_rod",speed:0.0000000012,force:"force"}
execute positioned ~ ~3.4 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:0,total_steps:10,vertical:1,other_angle:10,particle_type:"minecraft:end_rod",speed:0.0000000016,force:"force"}

execute positioned ~ ~3.4 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:0,total_steps:5,vertical:1,other_angle:90,particle_type:"minecraft:end_rod",speed:0.0000000009,force:"force"}
execute positioned ~ ~3.4 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:0,total_steps:64,vertical:1,other_angle:90,particle_type:"minecraft:end_rod",speed:0.0000000012,force:"force"}
execute positioned ~ ~3.4 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:0,total_steps:10,vertical:1,other_angle:90,particle_type:"minecraft:end_rod",speed:0.0000000016,force:"force"}

#dialogue
tellraw @a[distance=..256] {"translate":"roguecraft.dialogue.raid_5","color":"#ff8800","with":[{"translate":"roguecraft.dialogue_name.raid"}]}
execute as @a[distance=..256] at @s run playsound minecraft:entity.pillager.hurt voice @s ~ ~ ~ 0.5 0.9

execute at @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{giant_death:{}}}}}] run loot spawn ~ ~ ~ loot roguecraft:mob_essence/boss_loot

title @a[gamemode=!spectator,distance=..64] subtitle ""
title @a[gamemode=!spectator,distance=..64] title {"translate":"roguecraft.title.run_end_giant","color":"green"}
tellraw @a[tag=!hub,tag=!garden,distance=64.1..] {"translate":"roguecraft.chat_messages.boss_defeated","color":"dark_purple","with":[{"translate":"roguecraft.title.giant.main"}]}

execute as @a[gamemode=!spectator,distance=..64] at @s run playsound minecraft:ui.toast.challenge_complete master @a ~ ~ ~ 0.5 1
advancement grant @a[gamemode=!spectator,distance=..64] only roguecraft:progression/hero_of_the_village

execute unless data storage roguecraft:master {bosses_defeated:{corpus:1b}} if data storage roguecraft:master {speedrun:{new_world_display:1b}} run function roguecraft:speedrun/tell_time {type:"new_world",message:"roguecraft.speedrun.giant_message"}
execute if data storage roguecraft:master {speedrun:{single_run_display:1b}} run function roguecraft:speedrun/tell_time {type:"single_run",message:"roguecraft.speedrun.giant_message"}
execute as @a[gamemode=!spectator,tag=!hub,tag=!garden] if data storage roguecraft:master {speedrun:{single_run_display:1b}} run function roguecraft:speedrun/save_time {boss:"corpus"}

execute unless data storage roguecraft:master {bosses_defeated:{corpus:1b}} in roguecraft:infinite_garden run summon minecraft:marker 0 100 0 {Tags:["boss_defeated"]}
execute unless data storage roguecraft:master {bosses_defeated:{corpus:1b}} run data modify storage roguecraft:master obelisk_queue append value "corpus"
data modify storage roguecraft:master bosses_defeated.corpus set value 1b

function roguecraft:misc/set_gamerule {gamerule:"doDaylightCycle",value:"true"}
execute if data storage roguecraft:master {sleep:0b} run function roguecraft:misc/set_gamerule {gamerule:"playersSleepingPercentage",value:"0"}

kill @s
kill @e[type=minecraft:item,nbt={Item:{components:{"minecraft:custom_data":{giant_death:{}}}}}]
clear @a minecraft:light[minecraft:custom_data={giant_death:{}}]
playsound roguecraft:entity.giant.death hostile @a ~ ~ ~ 2

#store death
data modify storage roguecraft:master mid_run_bosses_defeated.corpus set value 1b

function roguecraft:compass/change_route