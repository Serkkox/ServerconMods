#set ice
fill ~-6 ~-3 ~-6 ~6 ~14 ~6 minecraft:ice replace minecraft:water

#prevent from turning into drowned
data modify entity @s InWaterTime set value 0

#drill follow-up
scoreboard players set @s attack_cooldown 1010
function roguecraft:giant/set_book/full {cmd:"300232"}