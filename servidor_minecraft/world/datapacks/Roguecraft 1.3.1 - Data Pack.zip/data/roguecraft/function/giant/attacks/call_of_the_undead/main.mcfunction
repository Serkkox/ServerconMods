#sound
execute as @a[distance=..80] at @s run playsound roguecraft:entity.giant.summon

#summon markers
summon minecraft:marker ~ ~ ~ {Tags:["giant_zombie_minion"]}
summon minecraft:marker ~ ~ ~ {Tags:["giant_zombie_minion"]}
summon minecraft:marker ~ ~ ~ {Tags:["giant_zombie_minion"]}

#spread markers
spreadplayers ~ ~ 2 10 false @e[tag=giant_zombie_minion,distance=..1]

#summon zombies at markers
execute at @e[type=minecraft:marker,distance=..64,tag=giant_zombie_minion] summon minecraft:zombie run function roguecraft:giant/attacks/call_of_the_undead/summon
kill @e[type=minecraft:marker,distance=..64,tag=giant_zombie_minion]

#scores
scoreboard players set @s attack_cooldown 50
scoreboard players set @s last_attack 8