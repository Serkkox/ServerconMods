$scoreboard players set @s raid_phase $(next_phase)

$summon minecraft:marker ~ ~ ~ {Tags:["current_main","raid_wave"],data:{wave:$(wave)}}
function roguecraft:giant/raid/set_wave_pos
scoreboard players set @s raid_bar 0