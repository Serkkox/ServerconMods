particle minecraft:dust{color:[0.2f,0.7f,1.0f],scale:4.0f} ~ ~ ~ 3 0.2 3 0 60 force
particle minecraft:dust{color:[0.2f,0.7f,1.0f],scale:4.0f} ~ ~1 ~ 0.4 0.6 0.4 0 10 force

function roguecraft:difficulty/apply_difficulty with storage roguecraft:master
execute if block ~ ~-1 ~ minecraft:short_grass run tp ~ ~-1 ~