#prepare thyself 
kill @s[type=!minecraft:player]
fill ~-3 ~ ~-3 ~3 ~9 ~3 air destroy

#presentation
execute at @s as @a[distance=..256] at @s run playsound minecraft:block.end_portal.spawn master @s ^ ^ ^10 0.25 0.75

execute unless data storage roguecraft:master {bosses_encountered:{corpus:1b}} run title @a[distance=..128] subtitle {"translate":"roguecraft.title.giant.subtitle","color":"aqua"}
execute unless data storage roguecraft:master {bosses_encountered:{corpus:1b}} run title @a[distance=..128] title {"translate":"roguecraft.title.giant.main","color":"aqua"}
tellraw @a[tag=!hub,tag=!garden] {"translate":"roguecraft.chat_messages.boss_awoken","color":"dark_purple","with":[{"translate":"roguecraft.title.giant.main"}]}

data modify storage roguecraft:master bosses_encountered.corpus set value 1b
particle minecraft:dust{color:[0.2f,0.7f,1.0f],scale:4.0f} ~ ~3 ~ 2 3 2 0 100 force

execute positioned ~ ~1 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:6,total_steps:30,vertical:0,other_angle:0,particle_type:"minecraft:end_rod",speed:0.0000000007,force:"normal"}
execute positioned ~ ~2.5 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:0,total_steps:30,vertical:0,other_angle:0,particle_type:"minecraft:end_rod",speed:0.00000000075,force:"normal"}
execute positioned ~ ~4 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:6,total_steps:30,vertical:0,other_angle:0,particle_type:"minecraft:end_rod",speed:0.0000000008,force:"normal"}
execute positioned ~ ~5.5 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:0,total_steps:30,vertical:0,other_angle:0,particle_type:"minecraft:end_rod",speed:0.00000000075,force:"normal"}
execute positioned ~ ~7 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:6,total_steps:30,vertical:0,other_angle:0,particle_type:"minecraft:end_rod",speed:0.0000000007,force:"normal"}

#set boss id
execute store result storage roguecraft:master boss_id int 1 run scoreboard players add #roguecraft_master boss_id 1

function roguecraft:giant/spawn_2 with storage roguecraft:master