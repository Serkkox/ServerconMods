execute as @a if items entity @s container.* minecraft:light[custom_data={giant_death:{}}] as @n[type=minecraft:marker,tag=giant] run function roguecraft:giant/death with entity @s data
clear @s minecraft:light[custom_data={giant_death:{}}]

advancement revoke @a only roguecraft:triggers/giant_death_detection_item