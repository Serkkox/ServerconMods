#break if condition is broken
execute unless entity @e[tag=giant,type=minecraft:zombie,scores={attack_cooldown=1000..}] run return 0

#particles
execute as @a at @s at @e[distance=..32,tag=giant,type=minecraft:zombie,nbt={HandItems:[{id:"minecraft:warped_fungus_on_a_stick",components:{"minecraft:custom_model_data":300332}},{}]},scores={attack_cooldown=1000..}] run particle minecraft:wax_off ~ ~4 ~ 4.5 4.5 4.5 0.1 10 normal @s

#loop
schedule function roguecraft:giant/attacks/damage_sphere/sparks 1t