#heal
effect give @s minecraft:instant_damage 1 3

#presentation
particle minecraft:heart ~ ~3.5 ~ 1.5 3 1.5 0 40
playsound minecraft:block.enchantment_table.use master @a ~ ~ ~ 2 1.5

#update bossbar
schedule function roguecraft:giant/damage_delayed 2t

#delay stuff
scoreboard players set @s attack_cooldown 20
scoreboard players set @s last_attack 9