advancement revoke @s only roguecraft:triggers/raid_omen
effect clear @s minecraft:raid_omen

tag @s add raid_start

execute at @n[type=minecraft:marker,distance=..64,tag=village_center] run function roguecraft:giant/raid/found