function roguecraft:giant/attacks/arrow_wave/main
function roguecraft:giant/attacks/levitate/main

function roguecraft:giant/set_book/main {cmd:"300412"}

scoreboard players set @s attack_cooldown 150
scoreboard players set @s last_attack 6