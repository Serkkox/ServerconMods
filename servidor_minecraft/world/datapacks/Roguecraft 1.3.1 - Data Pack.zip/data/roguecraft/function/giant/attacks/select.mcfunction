scoreboard players set @s attack_cooldown 1040

scoreboard players set @s temp 0
execute if entity @a[distance=..8] run scoreboard players add @s temp 1
execute if entity @a[distance=8..20] run scoreboard players add @s temp 2
execute if entity @a[distance=20..64] run scoreboard players add @s temp 4

execute if score @s temp matches 0 run return fail

# close range | pulse sphere, explosion, levitate, levitate + arrow shockwave, levitate + dirt walker, shockbolt, heal || 5 attacks (5 normal, 0 combos)
execute if score @s temp matches 1 store result score @s random run random value 0..4
# mid range | explosion, arrow shockwave, levitate + arrow shockwave, levitate + dirt walker, shockbolt, damage sphere, heal || 6 attacks (5 normal, 1 combo)
execute if score @s temp matches 2 store result score @s random run random value 0..8
# close + mid range | pulse sphere, explosion, levitate, levitate + arrow shockwave, levitate + dirt walker, arrow shockwave, shockbolt, heal || 7 attacks (6 normal, 1 combo)
execute if score @s temp matches 3 store result score @s random run random value 0..10
# far range | arrow shockwave, levitate + arrow shockwave, levitate + dirt walker, fireball, shockbolt, heal || 5 attacks (4 normal, 1 combo)
execute if score @s temp matches 4 store result score @s random run random value 0..7
# close + far range | pulse sphere, explosion, levitate, levitate + arrow shockwave, levitate + dirt walker, arrow shockwave, fireball, shockbolt, heal || 8 attacks (7 normal, 1 combo)
execute if score @s temp matches 5 store result score @s random run random value 0..12
# mid + far range | explosion, arrow shockwave, levitate + arrow shockwave, levitate + dirt walker, fireball, shockbolt, heal || 6 attacks (5 normal, 1 combo)
execute if score @s temp matches 6 store result score @s random run random value 0..8
# all ranges | pulse sphere, explosion, levitate, levitate + arrow shockwave, levitate + dirt walker, arrow shockwave, fireball, shockbolt, heal || 8 attacks (7 normal, 1 combo)
execute if score @s temp matches 7 store result score @s random run random value 0..12

## id system
# 0 : none
# 1 : levitate
# 2 : pulse sphere
# 3 : explosion
# 4 : arrow shockwave
# 5 : fireball
# 6 : levitate + arrow shockwave
# 7 : shockbolt
# 8 : call of the undead
# 9 : quick heal

##drill exception
execute anchored eyes unless block ~ ~ ~ #roguecraft:pass_through run function roguecraft:giant/set_book/full {cmd:"300232"}

##liquid_walker exception
execute unless data entity @s {InWaterTime:-1} run return run function roguecraft:giant/set_book/full {cmd:"300832"}

##call of the undead exception
execute store result storage roguecraft:master random byte 1 run random value 0..5
execute unless score @s last_attack matches 8 if score @s boss_health < @s boss_half_health if data storage roguecraft:master {random:0b} run return run function roguecraft:giant/attacks/call_of_the_undead/main

## close range
#levitate
execute if score @s temp matches 1 if score @s random matches 0 unless score @s last_attack matches 1 run return run function roguecraft:giant/set_book/full {cmd:"300732"}
#pulse sphere
execute if score @s temp matches 1 if score @s random matches 1 unless score @s last_attack matches 2 run return run function roguecraft:giant/set_book/damage_sphere {cmd:"300332"}
#explosion
#execute if score @s temp matches 1 if score @s random matches 2 unless score @s last_attack matches 3 run return run function roguecraft:giant/set_book/full {cmd:"300032"}
#shockbolt
execute if score @s temp matches 1 if score @s random matches 3 unless score @s last_attack matches 7 run return run function roguecraft:giant/set_book/full {cmd:"301232"}
#quick heal
execute if score @s temp matches 1 if score @s random matches 4 unless score @s last_attack matches 9 run return run function roguecraft:giant/set_book/full {cmd:"300132"}

## mid range
#explosion
#execute if score @s temp matches 2 if score @s random matches 0..1 unless score @s last_attack matches 3 run return run function roguecraft:giant/set_book/full {cmd:"300032"}
#arrow wave
execute if score @s temp matches 2 if score @s random matches 2..3 unless score @s last_attack matches 4 run return run function roguecraft:giant/set_book/full {cmd:"300412"}
#levitate arrow wave combo
execute if score @s temp matches 2 if score @s random matches 4 unless score @s last_attack matches 6 run return run function roguecraft:giant/set_book/full {cmd:"300742"}
#shockbolt
execute if score @s temp matches 2 if score @s random matches 5 unless score @s last_attack matches 7 run return run function roguecraft:giant/set_book/full {cmd:"301232"}
#pulse sphere
execute if score @s temp matches 2 if score @s random matches 6..7 unless score @s last_attack matches 2 run return run function roguecraft:giant/set_book/damage_sphere {cmd:"300332"}
#quick heal
execute if score @s temp matches 2 if score @s random matches 8 unless score @s last_attack matches 9 run return run function roguecraft:giant/set_book/full {cmd:"300132"}

## close + mid range
#levitate
execute if score @s temp matches 3 if score @s random matches 0..1 unless score @s last_attack matches 1 run return run function roguecraft:giant/set_book/full {cmd:"300732"}
#pulse sphere
execute if score @s temp matches 3 if score @s random matches 2..3 unless score @s last_attack matches 2 run return run function roguecraft:giant/set_book/damage_sphere {cmd:"300332"}
#explosion
#execute if score @s temp matches 3 if score @s random matches 4..5 unless score @s last_attack matches 3 run return run function roguecraft:giant/set_book/full {cmd:"300032"}
#arrow wave
execute if score @s temp matches 3 if score @s random matches 6..7 unless score @s last_attack matches 4 run return run function roguecraft:giant/set_book/full {cmd:"300412"}
#levitate arrow wave combo
execute if score @s temp matches 3 if score @s random matches 8 unless score @s last_attack matches 6 run return run function roguecraft:giant/set_book/full {cmd:"300742"}
#shockbolt
execute if score @s temp matches 3 if score @s random matches 9 unless score @s last_attack matches 7 run return run function roguecraft:giant/set_book/full {cmd:"301232"}
#quick heal
execute if score @s temp matches 3 if score @s random matches 4 unless score @s last_attack matches 8 run return run function roguecraft:giant/set_book/full {cmd:"300132"}

## far range
#arrow wave
execute if score @s temp matches 4 if score @s random matches 0..1 unless score @s last_attack matches 4 run return run function roguecraft:giant/set_book/full {cmd:"300412"}
#fireball
execute if score @s temp matches 4 if score @s random matches 2..3 unless score @s last_attack matches 5 run return run function roguecraft:giant/set_book/full {cmd:"300632"}
#levitate arrow wave combo
execute if score @s temp matches 4 if score @s random matches 4 unless score @s last_attack matches 6 run return run function roguecraft:giant/set_book/full {cmd:"300742"}
#shockbolt
execute if score @s temp matches 4 if score @s random matches 5 unless score @s last_attack matches 7 run return run function roguecraft:giant/set_book/full {cmd:"301232"}
#quick heal
execute if score @s temp matches 4 if score @s random matches 6..7 unless score @s last_attack matches 9 run return run function roguecraft:giant/set_book/full {cmd:"300132"}

## close + far range
#levitate
execute if score @s temp matches 5 if score @s random matches 0..1 unless score @s last_attack matches 1 run return run function roguecraft:giant/set_book/full {cmd:"300732"}
#pulse sphere
execute if score @s temp matches 5 if score @s random matches 2..3 unless score @s last_attack matches 2 run return run function roguecraft:giant/set_book/damage_sphere {cmd:"300332"}
#explosion
#execute if score @s temp matches 5 if score @s random matches 4..5 unless score @s last_attack matches 3 run return run function roguecraft:giant/set_book/full {cmd:"300032"}
#arrow wave
execute if score @s temp matches 5 if score @s random matches 6..7 unless score @s last_attack matches 4 run return run function roguecraft:giant/set_book/full {cmd:"300412"}
#fireball
execute if score @s temp matches 5 if score @s random matches 8..9 unless score @s last_attack matches 5 run return run function roguecraft:giant/set_book/full {cmd:"300632"}
#levitate arrow wave combo
execute if score @s temp matches 5 if score @s random matches 10 unless score @s last_attack matches 6 run return run function roguecraft:giant/set_book/full {cmd:"300742"}
#shockbolt
execute if score @s temp matches 5 if score @s random matches 11 unless score @s last_attack matches 7 run return run function roguecraft:giant/set_book/full {cmd:"301232"}
#quick heal
execute if score @s temp matches 5 if score @s random matches 12 unless score @s last_attack matches 9 run return run function roguecraft:giant/set_book/full {cmd:"300132"}

## mid + far range
#explosion
#execute if score @s temp matches 6 if score @s random matches 0..1 unless score @s last_attack matches 3 run return run function roguecraft:giant/set_book/full {cmd:"300032"}
#arrow wave
execute if score @s temp matches 6 if score @s random matches 2..3 unless score @s last_attack matches 4 run return run function roguecraft:giant/set_book/full {cmd:"300412"}
#fireball
execute if score @s temp matches 6 if score @s random matches 4..5 unless score @s last_attack matches 5 run return run function roguecraft:giant/set_book/full {cmd:"300632"}
#levitate arrow wave combo
execute if score @s temp matches 6 if score @s random matches 6 unless score @s last_attack matches 6 run return run function roguecraft:giant/set_book/full {cmd:"300742"}
#shockbolt
execute if score @s temp matches 6 if score @s random matches 7 unless score @s last_attack matches 7 run return run function roguecraft:giant/set_book/full {cmd:"301232"}
#quick heal
execute if score @s temp matches 6 if score @s random matches 8 unless score @s last_attack matches 9 run return run function roguecraft:giant/set_book/full {cmd:"300132"}

## all ranges
#levitate
execute if score @s temp matches 7 if score @s random matches 0..1 unless score @s last_attack matches 1 run return run function roguecraft:giant/set_book/full {cmd:"300732"}
#pulse sphere
execute if score @s temp matches 7 if score @s random matches 2..3 unless score @s last_attack matches 2 run return run function roguecraft:giant/set_book/damage_sphere {cmd:"300332"}
#explosion
#execute if score @s temp matches 7 if score @s random matches 4..5 unless score @s last_attack matches 3 run return run function roguecraft:giant/set_book/full {cmd:"300032"}
#arrow wave
execute if score @s temp matches 7 if score @s random matches 6..7 unless score @s last_attack matches 4 run return run function roguecraft:giant/set_book/full {cmd:"300412"}
#fireball
execute if score @s temp matches 7 if score @s random matches 8..9 unless score @s last_attack matches 5 run return run function roguecraft:giant/set_book/full {cmd:"300632"}
#levitate arrow wave combo
execute if score @s temp matches 7 if score @s random matches 10 unless score @s last_attack matches 6 run return run function roguecraft:giant/set_book/full {cmd:"300742"}
#shockbolt
execute if score @s temp matches 7 if score @s random matches 11 unless score @s last_attack matches 7 run return run function roguecraft:giant/set_book/full {cmd:"301232"}
#quick heal
execute if score @s temp matches 7 if score @s random matches 12 unless score @s last_attack matches 9 run return run function roguecraft:giant/set_book/full {cmd:"300132"}

## in case of duplicate attack
function roguecraft:giant/attacks/select