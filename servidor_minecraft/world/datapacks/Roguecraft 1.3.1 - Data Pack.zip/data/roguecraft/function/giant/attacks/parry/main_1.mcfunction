function roguecraft:ability/spikes/level_1

scoreboard players set @s attack_cooldown 1020

data modify entity @s HandItems set value [{id:"warped_fungus_on_a_stick",components:{"minecraft:custom_model_data":300542}},{}]