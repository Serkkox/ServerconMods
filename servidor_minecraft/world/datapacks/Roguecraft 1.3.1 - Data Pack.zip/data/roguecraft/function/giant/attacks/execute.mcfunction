## id system
# 0 : none
# 1 : levitate
# 2 : pulse sphere
# 3 : explosion
# 4 : arrow shockwave
# 5 : fireball
# 6 : levitate + arrow shockwave
# 7 : shockbolt
# 8 : liquid walker
# 9 : drill

#levitate
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300732}},{}]} run return run function roguecraft:giant/attacks/levitate/main

#pulse sphere
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300332}},{}]} run return run function roguecraft:giant/attacks/damage_sphere/main

#explosion
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300032}},{}]} run return run function roguecraft:giant/attacks/explosion/main

#arrow shockwave
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300412}},{}]} run return run function roguecraft:giant/attacks/arrow_wave/main

#fireball
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300632}},{}]} run return run function roguecraft:giant/attacks/fireball/main

#levitate + arrow shockwave combot
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300742}},{}]} run return run function roguecraft:giant/attacks/combos/levitate_arrow_wave

#shockbolt
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":301232}},{}]} run return run function roguecraft:giant/attacks/shockbolt/main

#liquid walker
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300832}},{}]} run return run function roguecraft:giant/attacks/liquid_walker/main

#drill
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300232}},{}]} run return run function roguecraft:giant/attacks/drill/main

#quick heal
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300132}},{}]} run return run function roguecraft:giant/attacks/heal/main

#parry
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300532}},{}]} run return run function roguecraft:giant/attacks/parry/main_1
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300542}},{}]} run return run function roguecraft:giant/attacks/parry/main_2
execute if data entity @s {HandItems:[{components:{"minecraft:custom_model_data":300552}},{}]} run return run function roguecraft:giant/attacks/parry/main_3