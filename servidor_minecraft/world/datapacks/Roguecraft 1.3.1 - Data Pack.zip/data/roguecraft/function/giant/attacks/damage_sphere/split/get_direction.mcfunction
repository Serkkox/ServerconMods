execute store result storage roguecraft:master random_pitch int 1 run random value -20..0
execute store result storage roguecraft:master random_yaw int 1 run random value -180..180

function roguecraft:giant/attacks/damage_sphere/split/init with storage roguecraft:master