particle minecraft:flame ~ ~ ~ 0 0 0 0.5 100 force
playsound minecraft:item.firecharge.use hostile @a ~ ~ ~ 2

execute facing entity @r[distance=..128,gamemode=!spectator] eyes run tp @s ~ ~ ~ ~ ~
function roguecraft:ability/fireball/level_1