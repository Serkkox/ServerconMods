execute as @e[type=minecraft:marker,tag=village_center] at @s run function roguecraft:giant/raid/disable with entity @s data
data modify storage roguecraft:master raid.active set value 0b