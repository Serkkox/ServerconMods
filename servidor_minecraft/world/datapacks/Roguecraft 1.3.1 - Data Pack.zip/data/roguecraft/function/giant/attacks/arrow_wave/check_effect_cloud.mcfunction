execute as @s[type=minecraft:area_effect_cloud,tag=giant_arrow_wave_1] if data entity @s {Age:1} at @n[type=minecraft:zombie,tag=giant] run function roguecraft:ability/arrow_wave/level_1
execute as @s[type=minecraft:area_effect_cloud,tag=giant_arrow_wave_2] if data entity @s {Age:16} at @n[type=minecraft:zombie,tag=giant] run function roguecraft:ability/arrow_wave/level_2
execute as @s[type=minecraft:area_effect_cloud,tag=giant_arrow_wave_3] if data entity @s {Age:31} at @n[type=minecraft:zombie,tag=giant] run function roguecraft:ability/arrow_wave/level_3

#execute as @s[type=minecraft:area_effect_cloud,tag=giant_arrow_wave_1] if data entity @s {Age:0} at MonoCodeYT run function roguecraft:ability/arrow_wave/level_1
#execute as @s[type=minecraft:area_effect_cloud,tag=giant_arrow_wave_2] if data entity @s {Age:7} at MonoCodeYT run function roguecraft:ability/arrow_wave/level_1
#execute as @s[type=minecraft:area_effect_cloud,tag=giant_arrow_wave_3] if data entity @s {Age:15} at MonoCodeYT run function roguecraft:ability/arrow_wave/level_2
#execute as @s[type=minecraft:area_effect_cloud,tag=giant_arrow_wave_4] if data entity @s {Age:23} at MonoCodeYT run function roguecraft:ability/arrow_wave/level_2
#execute as @s[type=minecraft:area_effect_cloud,tag=giant_arrow_wave_5] if data entity @s {Age:31} at MonoCodeYT run function roguecraft:ability/arrow_wave/level_3
#execute as @s[type=minecraft:area_effect_cloud,tag=giant_arrow_wave_6] if data entity @s {Age:39} at MonoCodeYT run function roguecraft:ability/arrow_wave/level_3