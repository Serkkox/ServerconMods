forceload remove ~ ~
forceload remove ~16 ~16
forceload remove ~16 ~
forceload remove ~16 ~-16
forceload remove ~ ~-16
forceload remove ~-16 ~-16
forceload remove ~-16 ~
forceload remove ~-16 ~16
forceload remove ~ ~16

$bossbar set roguecraft:boss_$(boss_id) players @s