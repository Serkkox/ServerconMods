playsound minecraft:entity.creeper.primed hostile @a ~ ~ ~ 2


summon minecraft:tnt ~ ~ ~ {Motion:[0.0d,1.0d,0.0d],fuse:100}

summon minecraft:tnt ~ ~ ~ {Motion:[0.3d,0.3d,0.3d],fuse:120}
summon minecraft:tnt ~ ~ ~ {Motion:[0.3d,0.3d,-0.3d],fuse:120}
summon minecraft:tnt ~ ~ ~ {Motion:[-0.3d,0.3d,0.3d],fuse:120}
summon minecraft:tnt ~ ~ ~ {Motion:[-0.3d,0.3d,-0.3d],fuse:120}

summon minecraft:tnt ~ ~ ~ {Motion:[0.45d,0.45d,0.45d],fuse:140}
summon minecraft:tnt ~ ~ ~ {Motion:[0.45d,0.45d,-0.45d],fuse:140}
summon minecraft:tnt ~ ~ ~ {Motion:[-0.45d,0.45d,0.45d],fuse:140}
summon minecraft:tnt ~ ~ ~ {Motion:[-0.45d,0.45d,-0.45d],fuse:140}
summon minecraft:tnt ~ ~ ~ {Motion:[0.45d,0.45d,0.0d],fuse:140}
summon minecraft:tnt ~ ~ ~ {Motion:[-0.45d,0.45d,0.0d],fuse:140}
summon minecraft:tnt ~ ~ ~ {Motion:[0.0d,0.45d,0.45d],fuse:140}
summon minecraft:tnt ~ ~ ~ {Motion:[0.0d,0.45d,-0.45d],fuse:140}

scoreboard players set @s attack_cooldown 1095
scoreboard players set @s last_attack 3

function roguecraft:giant/set_book/full {cmd:"300532"}

effect give @s resistance 8 3 true