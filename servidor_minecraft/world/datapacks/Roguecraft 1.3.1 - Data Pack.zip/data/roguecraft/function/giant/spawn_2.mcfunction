$summon minecraft:zombie ~ ~1 ~ {\
    attributes:[\
        {id:"minecraft:max_health",base:100000},\
        {id:"minecraft:attack_damage",base:6},\
        {id:"minecraft:scale",base:4.25},\
        {id:"minecraft:fall_damage_multiplier",base:0},\
        {id:"minecraft:knockback_resistance",base:0.75},\
        {id:"minecraft:movement_speed",base:0.2},\
        {id:"minecraft:movement_efficiency",base:1},\
        {id:"minecraft:oxygen_bonus",base:1024},\
        {id:"minecraft:water_movement_efficiency",base:1},\
        {id:"minecraft:attack_knockback",base:2.5}],\
    DeathLootTable:"roguecraft:giant_death_detection",\
    PersistenceRequired:true,\
    Silent:true,\
    HandItems:[{id:"minecraft:warped_fungus_on_a_stick",components:{"minecraft:custom_model_data":400004}},{}],\
    HandDropChances:[0.0f,0.0f],\
    Tags:["giant","$(boss_id)","buffed"]\
}

#set magic strength
$scoreboard players set @e[type=minecraft:zombie,tag=$(boss_id),limit=1] magic_strength 10

#scaling
$execute as @e[type=minecraft:zombie,tag=$(boss_id),limit=1] run function roguecraft:bosses/get_health_scaling {boss:"corpus"}

###health
##main
$execute as @e[type=minecraft:zombie,tag=$(boss_id),limit=1] run function roguecraft:bosses/set_scaling_score {score:"boss",base:180,per_player:120,half_health:1,quarter_health:0,players:"@a[gamemode=!spectator,distance=..80]"}

$execute as @e[type=minecraft:zombie,tag=$(boss_id),limit=1] store result entity @s Health int 1 run scoreboard players get @s boss_health
$execute store result entity @e[type=minecraft:zombie,tag=$(boss_id),limit=1] attributes[{id:"minecraft:max_health"}].base int 1 run scoreboard players get @e[type=minecraft:zombie,tag=$(boss_id),limit=1] boss_health
$data modify entity @e[type=minecraft:zombie,tag=$(boss_id),limit=1] Health set value 1024.0f

$execute as @e[type=minecraft:zombie,tag=giant,tag=!tagged] at @s run summon minecraft:marker ~ ~ ~ {Tags:["giant","$(boss_id)"],data:{boss_id:$(boss_id)}}
execute as @e[type=minecraft:zombie,tag=giant,tag=!tagged] run tag @s add tagged

$scoreboard players set @e[type=minecraft:zombie,tag=$(boss_id)] attack_cooldown 15
$scoreboard players set @e[type=minecraft:zombie,tag=$(boss_id)] last_attack 0

#random name
execute store result storage roguecraft:master random int 1 run random value 0..99
$execute if data storage roguecraft:master {random:99} run bossbar add roguecraft:boss_$(boss_id) {"translate":"roguecraft.bossbar.giant_variant"}
$execute unless data storage roguecraft:master {random:99} run bossbar add roguecraft:boss_$(boss_id) {"translate":"roguecraft.bossbar.giant"}
$execute unless data storage roguecraft:master {bosses_defeated:{corpus:1b}} run bossbar set roguecraft:boss_$(boss_id) name {"translate":"roguecraft.bossbar.giant"}

#rest of bossbar
$bossbar add roguecraft:boss_$(boss_id) {"translate":"roguecraft.bossbar.giant"}
$bossbar set roguecraft:boss_$(boss_id) players @a[gamemode=!spectator,distance=..96]
$bossbar set roguecraft:boss_$(boss_id) style notched_12
$bossbar set roguecraft:boss_$(boss_id) color red
$execute store result bossbar roguecraft:boss_$(boss_id) max run scoreboard players get @e[type=minecraft:zombie,tag=$(boss_id),limit=1] boss_health
$execute store result bossbar roguecraft:boss_$(boss_id) value run scoreboard players get @e[type=minecraft:zombie,tag=$(boss_id),limit=1] boss_health