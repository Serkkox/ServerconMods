execute store result storage roguecraft:master random_pitch int 1 run random value -75..-40
execute store result storage roguecraft:master random_yaw int 1 run random value -180..180

function roguecraft:giant/attacks/fireball/spawner/init with storage roguecraft:master