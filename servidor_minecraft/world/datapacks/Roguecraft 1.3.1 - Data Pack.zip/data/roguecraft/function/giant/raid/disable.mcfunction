forceload remove ~256 ~256 ~-256 ~-256
$bossbar remove roguecraft:boss_$(id)