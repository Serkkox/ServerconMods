effect give @s levitation 1 20 true

scoreboard players set @s attack_cooldown 90
scoreboard players set @s last_attack 1

#effect other players and entities
execute at @s positioned ~-3 ~-1.5 ~-3 as @e[dx=6,dy=4,dz=6] run effect give @s minecraft:levitation 1 9 true

particle minecraft:trial_spawner_detection_ominous ~ ~ ~ 2 0.1 2 0 50

playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 2 1.5
playsound minecraft:entity.breeze.land master @a ~ ~ ~