#timer
scoreboard players add @s timer 1

#visuals
particle minecraft:end_rod ~ ~ ~ 0.25 0.25 0.25 0 2 normal

#movement
execute if score @s timer matches 0..4 run tp @s ^ ^ ^1
execute if score @s timer matches 5..8 run tp @s ^ ^ ^0.85
execute if score @s timer matches 9..12 run tp @s ^ ^ ^0.7
execute if score @s timer matches 13..16 run tp @s ^ ^ ^0.55
execute if score @s timer matches 17..20 run tp @s ^ ^ ^0.35
execute if score @s timer matches 21..24 run tp @s ^ ^ ^0.2
execute if score @s timer matches 25..28 run tp @s ^ ^ ^0.15
execute if score @s timer matches 32..34 run tp @s ^ ^ ^0.1

#thunder
execute if score @s timer >= @s temp run function roguecraft:giant/attacks/damage_sphere/split/main
execute if score @s timer >= @s temp run kill @s