#scores
scoreboard players set @s timer 0

#explosion timer
execute store result score @s temp run random value 50..70

#tags
data modify entity @s Tags set value ["giant_damage_sphere"]

#rotation
$tp @s ~ ~ ~ $(random_yaw) $(random_pitch)