function roguecraft:ability/spikes/level_1

scoreboard players set @s attack_cooldown 20