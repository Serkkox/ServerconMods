particle minecraft:trial_spawner_detection_ominous ~ ~ ~ 2 5 2 0 200
playsound minecraft:block.enchantment_table.use master @a ~ ~ ~ 2 1.5

$function roguecraft:giant/set_book/main {cmd:"$(cmd)"}