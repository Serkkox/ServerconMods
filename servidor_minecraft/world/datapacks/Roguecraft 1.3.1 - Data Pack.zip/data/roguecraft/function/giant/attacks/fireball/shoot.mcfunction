tag @e[type=minecraft:marker,tag=giant_fireball,tag=!tagged,limit=1] add tagged
execute as @e[type=minecraft:marker,tag=giant_fireball,tag=tagged,limit=1] at @s at @e[type=minecraft:zombie,tag=giant,sort=nearest,limit=1] positioned ~ ~5 ~ facing entity @a feet run tp @s ~ ~ ~ ~ ~

execute store result storage roguecraft:master random byte 1 run random value 0..1

execute if data storage roguecraft:master {random:0b} as @e[type=minecraft:marker,tag=giant_fireball,tag=tagged] run function roguecraft:ability/fireball/level_2
execute if data storage roguecraft:master {random:1b} as @e[type=minecraft:marker,tag=giant_fireball,tag=tagged] run function roguecraft:ability/fireball/level_3

kill @e[type=minecraft:marker,tag=giant_fireball,tag=tagged]