summon minecraft:area_effect_cloud ~ ~ ~ {Duration:40,Tags:["giant_arrow_wave","giant_arrow_wave_1"]}
summon minecraft:area_effect_cloud ~ ~ ~ {Duration:40,Tags:["giant_arrow_wave","giant_arrow_wave_2"]}
summon minecraft:area_effect_cloud ~ ~ ~ {Duration:40,Tags:["giant_arrow_wave","giant_arrow_wave_3"]}

scoreboard players set @s attack_cooldown 110
scoreboard players set @s last_attack 4