#create fireball spawners
execute summon minecraft:marker run function roguecraft:giant/attacks/fireball/spawner/get_direction
execute summon minecraft:marker run function roguecraft:giant/attacks/fireball/spawner/get_direction
execute summon minecraft:marker run function roguecraft:giant/attacks/fireball/spawner/get_direction
execute summon minecraft:marker run function roguecraft:giant/attacks/fireball/spawner/get_direction
execute summon minecraft:marker run function roguecraft:giant/attacks/fireball/spawner/get_direction

#presentation
playsound minecraft:item.firecharge.use hostile @a ~ ~ ~ 2

#delay stuffs
scoreboard players set @s attack_cooldown 80
scoreboard players set @s last_attack 5