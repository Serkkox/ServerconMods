scoreboard players remove @s attack_cooldown 1
execute if score @s attack_cooldown matches ..0 at @s run function roguecraft:bosses/roll_attack {boss_name:"giant",roll_max:9}
execute if score @s attack_cooldown matches 200..1000 at @s run function roguecraft:giant/attacks/execute