#if health is greater than the max health, decrease it (ran into some issue with max health (nvm, fixed that))
#execute store result score @s temp run data get entity @s Health
#execute if score @s temp > @s boss_health run execute store result entity @s Health int 1 run scoreboard players get @s boss_health

$function roguecraft:giant/update_bossbar {boss_id:"$(boss_id)"}

playsound roguecraft:entity.giant.hurt hostile @a ~ ~ ~ 2