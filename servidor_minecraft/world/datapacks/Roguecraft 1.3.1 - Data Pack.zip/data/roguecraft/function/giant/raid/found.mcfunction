#tellraw @a "village center found / forceloaded"
tag @s remove raid_start

execute if score @n[type=minecraft:marker,tag=village_center,distance=..1] raid_phase matches 1.. run return 0

tellraw @a[distance=..192] {"translate":"roguecraft.dialogue.raid_1","color":"#ff8800","with":[{"translate":"roguecraft.dialogue_name.raid"}]}
execute as @a[distance=..192] at @s run playsound minecraft:entity.pillager.ambient voice @s ~ ~ ~ 0.5 0.9

scoreboard players add @n[type=minecraft:marker,tag=village_center,distance=..1] raid_phase 1
scoreboard players set @n[type=minecraft:marker,tag=village_center,distance=..1] raid_bar 0

execute store result score @n[type=minecraft:marker,tag=village_center,distance=..1] boss_id run scoreboard players add #roguecraft_master boss_id 1

execute as @n[type=minecraft:marker,tag=village_center,distance=..1] store result entity @s data.id int 1 run scoreboard players get @s boss_id
function roguecraft:giant/raid/add_bossbar with entity @n[type=minecraft:marker,tag=village_center,distance=..1] data

data modify storage roguecraft:master raid.active set value 1b

forceload add ~72 ~72 ~-72 ~-72