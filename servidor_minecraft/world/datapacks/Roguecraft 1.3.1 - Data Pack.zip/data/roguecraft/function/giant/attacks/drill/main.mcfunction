summon minecraft:area_effect_cloud ~ ~ ~ {Duration:10,Tags:["giant_drill","giant_drill_1"]}
summon minecraft:area_effect_cloud ~ ~ ~ {Duration:20,Tags:["giant_drill","giant_drill_2"]}
summon minecraft:area_effect_cloud ~ ~ ~ {Duration:30,Tags:["giant_drill","giant_drill_3"]}

scoreboard players set @s attack_cooldown 30