#timer
scoreboard players add @s timer 1

#visuals
particle minecraft:wax_on ~ ~ ~ 1 1 1 0 4 force
particle minecraft:wax_off ~ ~ ~ 1 1 1 0 2 force
particle minecraft:end_rod ~ ~ ~ 1 1 1 0 1 force

#movement
execute if score @s timer matches 0..30 run tp @s ~ ~0.5 ~
execute if score @s timer matches 31..50 run tp @s ~ ~0.4 ~
execute if score @s timer matches 51..60 run tp @s ~ ~0.3 ~
execute if score @s timer matches 61..70 run tp @s ~ ~0.2 ~
execute if score @s timer matches 71..80 run tp @s ~ ~0.05 ~

#thunder
execute if score @s timer matches 80 summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:1000,total_steps:90,vertical:0,other_angle:0,particle_type:"minecraft:end_rod",speed:0.000000002,force:"force"}
execute if score @s timer matches 80 as @a[distance=..64] at @s facing entity @s eyes run playsound minecraft:block.beacon.deactivate master @s ^ ^ ^8 0.5

#shoot shockbolts
execute unless score @s timer matches 120.. run return 0
execute facing entity @a[distance=..64] feet run function roguecraft:ability/shockbolt/raycast_start {steps:320,level:1,damage:0.5,split_count:0}

#kill
kill @s
particle minecraft:end_rod ~ ~ ~ 1 1 1 1 50 force