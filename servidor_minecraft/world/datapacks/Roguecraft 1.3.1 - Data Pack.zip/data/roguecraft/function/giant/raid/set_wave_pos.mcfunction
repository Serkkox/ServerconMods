spreadplayers ~ ~ 0 32 false @e[type=minecraft:marker,tag=current_main,tag=raid_wave,distance=..256]
execute unless entity @e[type=minecraft:marker,tag=current_main,tag=raid_wave,distance=20..256] run return run function roguecraft:giant/raid/set_wave_pos

execute as @e[type=minecraft:marker,tag=current_main,tag=raid_wave,distance=20..256] at @s run function roguecraft:giant/raid/summon_wave with entity @s data