$execute unless score @s[tag=!hub] class matches 4 store result bossbar minecraft:mana_$(player_id) max run scoreboard players get @s mid_run_max_mana
$execute unless score @s[tag=!hub] class matches 4 store result bossbar minecraft:mana_$(player_id) value run scoreboard players get @s mana
$execute unless score @s[tag=!hub] class matches 4 run bossbar set minecraft:mana_$(player_id) name ["",{"score":{"name":"@s","objective":"mana"},"color":"aqua"},{"text":"/","color":"aqua"},{"score":{"name":"@s","objective":"mid_run_max_mana"},"color":"aqua"},{"text":" "},{"translate":"roguecraft.generic.mana","color":"aqua"}]
$execute unless score @s[tag=!hub] class matches 4 run bossbar set minecraft:mana_$(player_id) color blue

$execute if score @s[tag=!hub] class matches 4 store result bossbar minecraft:mana_$(player_id) max run scoreboard players get @s max_soul_charge
$execute if score @s[tag=!hub] class matches 4 store result bossbar minecraft:mana_$(player_id) value run scoreboard players get @s soul_charge
$execute if score @s[tag=!hub] class matches 4 run bossbar set minecraft:mana_$(player_id) name ["",{"score":{"name":"@s","objective":"soul_charge"},"color":"white"},{"text":"/","color":"white"},{"score":{"name":"@s","objective":"max_soul_charge"},"color":"white"},{"text":" "},{"translate":"roguecraft.generic.soul_charge","color":"white"}]
$execute if score @s[tag=!hub] class matches 4 run bossbar set minecraft:mana_$(player_id) color purple

$execute unless entity @s[tag=garden] if data storage roguecraft:master {run_active:0} run bossbar set minecraft:mana_$(player_id) players NONE

#class with mana
$execute if score @s class matches 0 run return run bossbar set minecraft:mana_$(player_id) players @s[tag=mana_$(player_id),tag=!hub,gamemode=!spectator]
$execute if score @s class matches 2 run return run bossbar set minecraft:mana_$(player_id) players @s[tag=mana_$(player_id),tag=!hub,gamemode=!spectator]
$execute if score @s class matches 3 run return run bossbar set minecraft:mana_$(player_id) players @s[tag=mana_$(player_id),tag=!hub,gamemode=!spectator]
$execute if score @s class matches 4 run return run bossbar set minecraft:mana_$(player_id) players @s[tag=mana_$(player_id),tag=!hub,gamemode=!spectator]
$execute if score @s class matches 5 run return run bossbar set minecraft:mana_$(player_id) players @s[tag=mana_$(player_id),tag=!hub,gamemode=!spectator]

#has ability
$execute unless score @s ability_1 matches -1 run return run bossbar set minecraft:mana_$(player_id) players @s[tag=mana_$(player_id),tag=!hub,gamemode=!spectator]
$execute unless score @s ability_2 matches -1 run return run bossbar set minecraft:mana_$(player_id) players @s[tag=mana_$(player_id),tag=!hub,gamemode=!spectator]
$execute unless score @s ability_3 matches -1 run return run bossbar set minecraft:mana_$(player_id) players @s[tag=mana_$(player_id),tag=!hub,gamemode=!spectator]
execute if score @s class matches 1 unless score @s ability_4 matches -1 run return 0

#remove bossbar
$bossbar set minecraft:mana_$(player_id) players NONE