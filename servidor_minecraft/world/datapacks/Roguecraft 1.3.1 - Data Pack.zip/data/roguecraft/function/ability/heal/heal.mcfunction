$effect give @s[type=!#minecraft:undead] minecraft:regeneration 1 $(result)
$effect give @s[type=#minecraft:undead] minecraft:poison 1 $(result)