#hit block
execute unless block ~ ~ ~ #roguecraft:pass_through run return run tag @s add shockbolt_split_immune

#presentation
particle minecraft:wax_on ~ ~ ~
particle minecraft:dust{scale:1,color:[1.0,0.8,0.25]} ~ ~ ~ 0.05 0.05 0.05 0 1

playsound minecraft:block.trial_spawner.spawn_mob player @a[tag=!current_main] ~ ~ ~ 0.025 2
playsound minecraft:entity.generic.explode player @a[tag=!current_main] ~ ~ ~ 0.01 1.5

#search
execute as @s[distance=..1] run tag @s add shockbolt_split_hit
execute as @s[distance=..1] run scoreboard players remove @a[tag=current_main] split_count 1
execute as @s[distance=..1] run return run tag @s add shockbolt_split_immune

#end
execute facing entity @s feet positioned ^ ^ ^0.2 run function roguecraft:ability/shockbolt/split/raycast_run