$damage @s $(shockbolt_self_damage) roguecraft:shockbolt at ^ ^ ^2
particle minecraft:wax_off ^ ^ ^1 0.25 0.5 0.25 100 50