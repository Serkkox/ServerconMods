$execute if score @s mana >= #roguecraft_master class_cost_$(class)_$(ability_index) run function roguecraft:ability/classes/$(target_function)

$execute unless score @s mana >= #roguecraft_master class_cost_$(class)_$(ability_index) as @s run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.ability_no_mana","italic":true,"color":"red"}
$execute unless score @s mana >= #roguecraft_master class_cost_$(class)_$(ability_index) as @s run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5

$execute if score @s mana >= #roguecraft_master class_cost_$(class)_$(ability_index) run scoreboard players operation @s mana -= #roguecraft_master class_cost_$(class)_$(ability_index)

function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/set_mana_bar"}