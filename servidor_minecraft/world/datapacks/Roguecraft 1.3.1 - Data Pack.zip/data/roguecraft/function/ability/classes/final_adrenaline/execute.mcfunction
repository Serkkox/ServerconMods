#decrease max by 20 every time
scoreboard players operation @s final_adrenaline_timer = @s final_adrenaline_timer_max
execute unless score @s final_adrenaline_timer matches ..1 run scoreboard players remove @s final_adrenaline_timer_max 20

execute store result score @s final_adrenaline_counter run random value 3..8

title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.use_ability","italic":true,"color":"white","with":[{"translate":"roguecraft.class_ability.final_adrenaline"}]}
function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/classes/final_adrenaline/apply_bossbar"}
tag @s add ability_bossbar

function roguecraft:ability/classes/final_adrenaline/give_modifiers

playsound minecraft:item.ominous_bottle.dispose master @s ~ ~ ~ 2 0.5
playsound minecraft:item.ominous_bottle.dispose master @s ~ ~ ~ 2 0.75
playsound minecraft:item.ominous_bottle.dispose master @s ~ ~ ~ 2 1
playsound minecraft:item.ominous_bottle.dispose master @s ~ ~ ~ 2 1.25
playsound minecraft:item.ominous_bottle.dispose master @s ~ ~ ~ 2 1.5
playsound minecraft:event.mob_effect.raid_omen master @s ~ ~ ~ 1 1.5
playsound minecraft:item.trident.thunder master @a ~ ~ ~ 2 1.1

particle minecraft:flame ~ ~1 ~ 0.5 0.5 0.5 0.3 30
particle minecraft:soul_fire_flame ~ ~1 ~ 0.5 0.5 0.5 0.4 30

#if timer is 0 : kill
execute if score @s final_adrenaline_timer matches ..1 run advancement grant @s only roguecraft:challenges/instant_regret
execute if score @s final_adrenaline_timer matches ..1 run return run damage @s[gamemode=!creative] 100000 roguecraft:final_adrenaline