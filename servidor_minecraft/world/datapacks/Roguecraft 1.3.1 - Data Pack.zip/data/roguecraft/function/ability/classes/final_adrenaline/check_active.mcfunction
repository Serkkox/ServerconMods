#yes, this is repetitive, but i am so done with this update at this point that i don't care
execute if score @s final_adrenaline_timer matches -2.. run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.class_ability.final_adrenaline_error_active","italic":true,"color":"red"}
execute if score @s final_adrenaline_timer matches -2.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5
execute if score @s final_adrenaline_timer matches -2.. run return run data modify storage roguecraft:master class_ability_success set value 0b

function roguecraft:ability/classes/final_adrenaline/execute