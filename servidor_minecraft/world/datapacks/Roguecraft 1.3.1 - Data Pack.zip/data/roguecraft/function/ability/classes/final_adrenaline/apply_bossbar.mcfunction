$bossbar set minecraft:final_adrenaline_$(player_id) max 300
#$execute if entity @s store result bossbar minecraft:final_adrenaline_$(player_id) max run scoreboard players get @s final_adrenaline_timer
$execute if entity @s store result bossbar minecraft:final_adrenaline_$(player_id) value run scoreboard players get @s final_adrenaline_timer
$bossbar set minecraft:final_adrenaline_$(player_id) players @s
$bossbar set minecraft:final_adrenaline_$(player_id) name {"translate":"roguecraft.bossbar.final_adrenaline","with":[{"score":{"name":"@s","objective":"final_adrenaline_counter"}}]}