scoreboard players set @s parry_timer 0

#set damage
function roguecraft:ability/magic_strength/multiply {multiplier:2.4}

#deal damage
execute at @s on attacker unless entity @s[type=minecraft:ghast] run function roguecraft:ability/spikes/damage with storage roguecraft:master magic_strength

#ghast check
function roguecraft:ability/spikes/ghast_check

playsound minecraft:block.anvil.land master @a ~ ~ ~ 0.75 1.5
playsound minecraft:entity.wither.break_block master @a ~ ~ ~ 0.75

scoreboard players remove @s mana 8
scoreboard players add @s soul_charge 1
scoreboard players operation @s mana += #roguecraft_master ability_cost_5_3
execute if score @s mana > @s mid_run_max_mana run scoreboard players operation @s mana = @s mid_run_max_mana

execute if entity @s[type=minecraft:player] run function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/set_mana_bar"}