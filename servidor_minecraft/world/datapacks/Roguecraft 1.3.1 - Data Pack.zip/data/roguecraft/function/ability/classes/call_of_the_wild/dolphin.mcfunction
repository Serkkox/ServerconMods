data modify entity @s GotFish set value true
particle minecraft:heart ~ ~ ~ 0.5 0.5 0.5 0 6