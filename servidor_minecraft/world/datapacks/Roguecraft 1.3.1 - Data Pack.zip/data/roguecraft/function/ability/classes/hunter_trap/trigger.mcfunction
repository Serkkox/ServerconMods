execute as @n[type=minecraft:player,distance=..1.5] if entity @s[gamemode=spectator] run return 0

tag @s add triggered
tag @s add current_main
$tag @e[nbt={UUID:$(armor_stand)}] add triggered
$tag @e[nbt={UUID:$(claw_1)}] add triggered
$tag @e[nbt={UUID:$(claw_2)}] add triggered
$tag @e[nbt={UUID:$(icon)}] add triggered
$tag @e[nbt={UUID:$(base)}] add triggered

$execute as @e[nbt={UUID:$(claw_1)},distance=..5] run data merge entity @s {interpolation_duration:1,teleport_duration:1,transformation:[1f,0f,0f,0f,0f,1f,0f,0.4751f,0f,0f,1f,0f,0f,0f,0f,1f],Rotation:[0.0f,-90.0f]}
$execute as @e[nbt={UUID:$(claw_2)},distance=..5] run data merge entity @s {interpolation_duration:1,teleport_duration:1,transformation:[1f,0f,0f,0f,0f,1f,0f,0.4751f,0f,0f,1f,0f,0f,0f,0f,1f],Rotation:[0.0f,90.0f]}

#set base
$data merge entity @e[type=minecraft:item_display,nbt={UUID:$(base)},limit=1,distance=..5] {teleport_duration:1,item:{components:{"minecraft:custom_model_data":520}},start_interpolation:-1,transformation:{left_rotation: [0.0f, 0.0f, 0.0f, 1.0f], right_rotation: [0.0f, 0.0f, 0.0f, 1.0f], scale: [1.0f, 1.0f, 1.0f], translation: [0.0f, 0.46875f, 0.0f]},interpolation_duration:8}

#set icon
$data merge entity @e[type=minecraft:item_display,nbt={UUID:$(icon)},limit=1,distance=..5] {teleport_duration:1,item:{components:{"minecraft:custom_model_data":522}},start_interpolation:-1,transformation:{left_rotation: [0.0f, 0.0f, 0.0f, 1.0f], right_rotation: [0.0f, 0.0f, 0.0f, 1.0f], scale: [1.0f, 1.0f, 1.0f], translation: [0.0f, 0.46875f, 0.0f]},interpolation_duration:8}

playsound minecraft:entity.wither.shoot master @a ~ ~ ~ 0.5 1.6
playsound minecraft:block.netherite_block.break master @a ~ ~ ~ 2 2
playsound minecraft:entity.wither.break_block master @a ~ ~ ~ 0.4 2

particle minecraft:crit ~ ~0.4 ~ 0.05 0.05 0.05 0.4 30

data modify storage roguecraft:master current_uuid set from entity @s data.owner
$execute unless entity @s[tag=proximity_mine_trap] as @e[type=!#roguecraft:hunter_trap_components,distance=..2.5] run function roguecraft:ability/classes/hunter_trap/$(type) with storage roguecraft:master
$execute if entity @s[tag=proximity_mine_trap] as @s run function roguecraft:ability/classes/hunter_trap/$(type) with storage roguecraft:master

tag @s remove current_main