kill @s
particle minecraft:soul_fire_flame ~ ~1 ~ 0.05 0.05 0.05 0.05 5 normal
playsound minecraft:block.beacon.deactivate master @a ~ ~ ~ 0.125 0.8
playsound minecraft:entity.blaze.shoot master @a ~ ~ ~ 0.1