execute at @s run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 1.5 1
execute at @s run playsound minecraft:block.enchantment_table.use master @a ~ ~ ~ 0.125

$title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.class.toggle_ability","color":"light_purple","with":[{"translate":"roguecraft.class_ability.$(class_ability_name)"}]}
$execute if entity @s[nbt={SelectedItem:{id:"minecraft:warped_fungus_on_a_stick",components:{"minecraft:custom_data":{ability_num:4}}}}] run item replace entity @s weapon.mainhand with minecraft:warped_fungus_on_a_stick[minecraft:custom_data={ability_num:4},minecraft:custom_name='{"translate":"roguecraft.class_ability.$(class_ability_name)","color":"light_purple"}']
$execute if entity @s[nbt={Inventory:[{id:"minecraft:warped_fungus_on_a_stick",Slot:-106b,components:{"minecraft:custom_data":{ability_num:4}}}]}] run item replace entity @s weapon.offhand with minecraft:warped_fungus_on_a_stick[minecraft:custom_data={ability_num:4},minecraft:custom_name='{"translate":"roguecraft.class_ability.$(class_ability_name)","color":"light_purple"}']

function roguecraft:upgrades/get_ability_cmd/class
execute if entity @s[nbt={SelectedItem:{id:"minecraft:warped_fungus_on_a_stick",components:{"minecraft:custom_data":{ability_num:4}}}}] run return run item modify entity @s weapon.mainhand roguecraft:set_ability_cmd
execute if entity @s[nbt={Inventory:[{id:"minecraft:warped_fungus_on_a_stick",Slot:-106b,components:{"minecraft:custom_data":{ability_num:4}}}]}] run return run item modify entity @s weapon.offhand roguecraft:set_ability_cmd