# +40% attack damage, +2 mana regeneration, +25% movement speed, +5 armor toughness, +50% block breaking speed, +25% entity interaction range, +15% attack speed, +25% step height, +10% jump height
attribute @s minecraft:attack_damage modifier remove roguecraft:final_adrenaline
attribute @s minecraft:movement_speed modifier remove roguecraft:final_adrenaline
attribute @s minecraft:armor_toughness modifier remove roguecraft:final_adrenaline
attribute @s minecraft:block_break_speed modifier remove roguecraft:final_adrenaline
attribute @s minecraft:entity_interaction_range modifier remove roguecraft:final_adrenaline
attribute @s minecraft:attack_speed modifier remove roguecraft:final_adrenaline
attribute @s minecraft:step_height modifier remove roguecraft:final_adrenaline
attribute @s minecraft:jump_strength modifier remove roguecraft:final_adrenaline