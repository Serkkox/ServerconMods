#set damage
function roguecraft:ability/magic_strength/multiply {multiplier:1.2}
function roguecraft:ability/magic_strength/round

#give effect
execute at @s positioned ~-3 ~-1.5 ~-3 as @e[dx=6,dy=4,dz=6] run function roguecraft:ability/levitate/give_effect with storage roguecraft:master magic_strength

#particles
particle minecraft:trial_spawner_detection_ominous ~ ~ ~ 2 0.1 2 0 50

#sound
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 2 1.5
playsound minecraft:entity.breeze.land master @a ~ ~ ~