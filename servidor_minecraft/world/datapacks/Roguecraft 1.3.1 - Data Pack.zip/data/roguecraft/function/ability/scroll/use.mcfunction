data remove storage roguecraft:master class_ability_success

data modify storage roguecraft:master scroll_used set value 1b
data modify storage roguecraft:master timer_stopped set value 0b
execute store result storage roguecraft:master mainhand_scroll byte 1 if data entity @s SelectedItem.components."minecraft:custom_data".scroll

execute if data storage roguecraft:master {mainhand_scroll:1b} if data entity @s {SelectedItem:{components:{"minecraft:custom_data":{class_scroll:true}}}} run return run function roguecraft:ability/scroll/class_use

execute if data storage roguecraft:master {mainhand_scroll:1b} run function roguecraft:ability/execute_2 with entity @s SelectedItem.components."minecraft:custom_data"
execute if data storage roguecraft:master {mainhand_scroll:0b} run function roguecraft:ability/execute_2 with entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data"

execute if data storage roguecraft:master {timer_stopped:1b} run return fail

execute if data storage roguecraft:master {mainhand_scroll:0b} if data entity @s Inventory[{Slot:-106b,components:{"minecraft:custom_data":{class_scroll:1b}}}] run function roguecraft:ability/scroll/class_use

execute if data storage roguecraft:master {class_ability_success:0b} run return 0

execute if data storage roguecraft:master {mainhand_scroll:1b} run item modify entity @s[gamemode=!creative] weapon.mainhand roguecraft:decrease
execute if data storage roguecraft:master {mainhand_scroll:0b} run item modify entity @s[gamemode=!creative] weapon.offhand roguecraft:decrease