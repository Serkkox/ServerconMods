data modify storage roguecraft:master timer_stopped set value 1b
$scoreboard players set @s $(type)_timer 1

playsound minecraft:block.beacon.deactivate master @s ~ ~ ~ 0.75 1
execute at @s run playsound minecraft:item.book.page_turn master @s ~ ~ ~ 1.5 1
$title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.cancel_ability","italic":true,"color":"blue","with":[{"translate":"roguecraft.ability.name.ability_$(type)_walker"}]}