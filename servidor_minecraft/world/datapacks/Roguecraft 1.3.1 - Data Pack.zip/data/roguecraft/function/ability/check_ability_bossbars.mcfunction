execute if entity @s[scores={liquid_timer=..-10,dirt_timer=..-10,final_adrenaline_timer=..-10}] run return run tag @s remove ability_bossbar

execute as @s[scores={liquid_timer=-10..}] run function roguecraft:ability/liquid_walker/tick
execute as @s[scores={dirt_timer=-10..}] run function roguecraft:ability/dirt_walker/tick
execute as @s[scores={final_adrenaline_timer=-10..}] run function roguecraft:ability/classes/final_adrenaline/tick