#set damage
function roguecraft:ability/magic_strength/multiply {multiplier:0.5}
function roguecraft:ability/magic_strength/round

#give effect
execute at @s positioned ~-2 ~-1 ~-2 as @e[dx=4,dy=3,dz=4] run function roguecraft:ability/levitate/give_effect with storage roguecraft:master magic_strength

#particles
particle minecraft:trial_spawner_detection_ominous ~ ~ ~ 1.75 0.1 1.75 0 50

#sound
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 2 1.5
playsound minecraft:entity.breeze.land master @a ~ ~ ~