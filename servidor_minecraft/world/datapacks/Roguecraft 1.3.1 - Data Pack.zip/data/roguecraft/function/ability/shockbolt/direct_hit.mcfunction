particle minecraft:end_rod ~ ~ ~ 0.25 0.25 0.25 0.15 30
execute at @s run playsound minecraft:entity.firework_rocket.blast hostile @s ~ ~ ~ 1
execute as @n[distance=..1,type=!#roguecraft:shockbolt_excluded,tag=!shockbolt_immune] run function roguecraft:ability/shockbolt/damage with storage roguecraft:master