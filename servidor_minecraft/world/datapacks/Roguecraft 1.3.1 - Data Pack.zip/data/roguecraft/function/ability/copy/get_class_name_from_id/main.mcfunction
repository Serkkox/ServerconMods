scoreboard players operation @s temp = @s ability_copied
scoreboard players operation @s temp -= 1000 int
execute store result storage roguecraft:master class_name_from_id.class_id int 1 run scoreboard players operation @s temp /= 100 int

function roguecraft:ability/copy/get_class_name_from_id/get_class_name with storage roguecraft:master class_name_from_id

scoreboard players operation @s temp = @s ability_copied
scoreboard players operation @s temp -= 1000 int
execute store result storage roguecraft:master class_name_from_id.class_ability_id int 1 run scoreboard players operation @s temp %= 100 int

function roguecraft:ability/copy/get_class_name_from_id/get_class_ability_name with storage roguecraft:master class_name_from_id

data modify storage roguecraft:master copy_ability.temp_name set from storage roguecraft:master class_name_from_id.class_ability_name