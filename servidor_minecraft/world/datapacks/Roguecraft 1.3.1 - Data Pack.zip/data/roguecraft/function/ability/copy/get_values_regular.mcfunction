#check walker
execute if score @s ability_copied matches 8 if score @s liquid_timer matches 20.. run return run function roguecraft:ability/cancel_walker {type:"liquid"}
execute if score @s ability_copied matches 11 if score @s dirt_timer matches 20.. run return run function roguecraft:ability/cancel_walker {type:"dirt"}

#get values
execute store result storage roguecraft:master copy_ability.temp_score_ability int 1 run scoreboard players get @s ability_copied
execute store result storage roguecraft:master copy_ability.temp_score_level int 1 run scoreboard players get @s ability_copy
function roguecraft:ability/copy/get_name with storage roguecraft:master copy_ability

function roguecraft:ability/check_mana with storage roguecraft:master copy_ability