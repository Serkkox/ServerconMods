#get class ability name
function roguecraft:ability/copy/get_class_name_from_id/main

#execute
function roguecraft:ability/classes/select_ability with storage roguecraft:master class_name_from_id