#start
scoreboard players remove @s steps 1
execute unless block ~ ~ ~ #roguecraft:pass_through run return run function roguecraft:ability/shockbolt/raycast_end

#presentation
particle minecraft:wax_on ~ ~ ~
particle minecraft:wax_off ~ ~ ~ 0.15 0.15 0.15 0 1
particle minecraft:dust{scale:1,color:[1.0,0.8,0.25]} ~ ~ ~ 0.15 0.15 0.15 0 1

playsound minecraft:block.trial_spawner.spawn_mob player @a[tag=!current_main] ~ ~ ~ 0.025 2
playsound minecraft:entity.generic.explode player @a[tag=!current_main] ~ ~ ~ 0.01 1.5

#search
execute at @e[distance=..1.5,type=!#roguecraft:shockbolt_excluded,tag=!shockbolt_immune] run function roguecraft:ability/shockbolt/direct_hit
execute if score @s split_count matches 1.. if score @s temp matches 2 as @e[distance=..2,type=!#roguecraft:shockbolt_excluded,tag=!shockbolt_split_immune] facing entity @s eyes run function roguecraft:ability/shockbolt/split/raycast_start
execute if score @s split_count matches 1.. if score @s temp matches 3 as @e[distance=..4,type=!#roguecraft:shockbolt_excluded,tag=!shockbolt_split_immune] facing entity @s eyes run function roguecraft:ability/shockbolt/split/raycast_start

#end
execute unless score @s steps matches ..0 positioned ^ ^ ^0.2 run return run function roguecraft:ability/shockbolt/raycast_run
function roguecraft:ability/shockbolt/raycast_end