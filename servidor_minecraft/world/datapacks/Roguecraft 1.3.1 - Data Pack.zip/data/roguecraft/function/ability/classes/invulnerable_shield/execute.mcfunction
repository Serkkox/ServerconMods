effect give @s minecraft:resistance 10 4 true
title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.use_ability","italic":true,"color":"gray","with":[{"translate":"roguecraft.class_ability.invulnerable_shield"}]}
playsound minecraft:item.trident.thunder master @a ~ ~ ~ 2 1.1
scoreboard players set @s invulnerable_shield_advancement_counter 0