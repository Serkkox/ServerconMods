gamemode survival
scoreboard players set @s true_gamemode 0

scoreboard players remove @s speed 1
scoreboard players remove @s jump_boost 1
scoreboard players remove @s resistance 1
scoreboard players remove @s[scores={class=3}] defense 50
scoreboard players remove @s[scores={class=4}] defense 10

execute store result storage roguecraft:master upgrades.defense int 1 run scoreboard players get @s defense
execute store result storage roguecraft:master upgrades.max_health int 1 run scoreboard players get @s current_health
execute store result storage roguecraft:master upgrades.speed int 1 run scoreboard players get @s speed
execute store result storage roguecraft:master upgrades.attack_damage int 1 run scoreboard players get @s attack_damage
execute store result storage roguecraft:master upgrades.jump_boost int 1 run scoreboard players get @s jump_boost
execute store result storage roguecraft:master upgrades.resistance int 1 run scoreboard players get @s resistance
execute store result storage roguecraft:master upgrades.step_height float 0.1 run scoreboard players get @s step_height
execute store result storage roguecraft:master upgrades.entity_reach int 1 run scoreboard players get @s entity_reach
execute store result storage roguecraft:master upgrades.block_reach float 0.1 run scoreboard players get @s block_reach
execute store result storage roguecraft:master upgrades.class int 1 run scoreboard players get @s class
scoreboard players remove @s current_strength 1
execute store result storage roguecraft:master upgrades.current_strength int 1 run scoreboard players get @s current_strength
scoreboard players add @s current_strength 1

scoreboard players add @s[scores={class=3}] defense 50
scoreboard players add @s[scores={class=4}] defense 10
scoreboard players add @s speed 1
scoreboard players add @s jump_boost 1
scoreboard players add @s resistance 1

function roguecraft:ability/classes/revive_apply with storage roguecraft:master upgrades