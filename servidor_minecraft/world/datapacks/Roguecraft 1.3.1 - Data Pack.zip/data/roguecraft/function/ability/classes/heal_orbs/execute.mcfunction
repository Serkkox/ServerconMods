tag @s add current_main
$data modify storage roguecraft:master healer_orb_type set value "$(type)"
execute as @a[tag=!current_main,gamemode=!spectator,distance=..160] run function roguecraft:ability/classes/heal_orbs/store_player_uuid
execute as @e[tag=tamed,distance=..160] run function roguecraft:ability/classes/heal_orbs/store_player_uuid
$function roguecraft:heal_orbs/$(type)
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 2 1.5
playsound minecraft:block.end_portal_frame.fill master @s ~ ~ ~ 0.75 2
tag @s remove current_main

$title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.use_ability","italic":true,"color":"red","with":[{"translate":"roguecraft.class_ability.$(type)"}]}