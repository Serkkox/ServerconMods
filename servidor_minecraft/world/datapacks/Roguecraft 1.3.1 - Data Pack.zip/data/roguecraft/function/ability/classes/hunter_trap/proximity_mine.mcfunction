#remove exploded trigger
tag @s remove proximity_mine_exploded

#explosion
summon minecraft:creeper ~ ~ ~ {Fuse:0s,attributes:[{base:0.001,id:"minecraft:scale"}],ExplosionRadius:2}

#trigger nearby mines
execute as @e[type=minecraft:marker,tag=proximity_mine_trap,tag=!triggered,tag=primed,distance=0.5..6] run tag @s add proximity_mine_exploded