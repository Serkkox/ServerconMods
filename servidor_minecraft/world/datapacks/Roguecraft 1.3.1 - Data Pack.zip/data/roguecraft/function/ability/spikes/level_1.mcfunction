playsound minecraft:block.anvil.land master @s ~ ~ ~ 0.75 1.25
execute as @s[type=!minecraft:player] run playsound minecraft:block.anvil.land master @a ~ ~ ~ 0.75 1.25
scoreboard players set @s parry_timer 20
scoreboard players set @s damage 0
effect give @s minecraft:resistance 1 4 true