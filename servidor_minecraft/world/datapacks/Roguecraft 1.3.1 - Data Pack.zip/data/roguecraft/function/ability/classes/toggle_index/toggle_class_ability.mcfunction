execute store result storage roguecraft:master class_ability_index byte 1 run scoreboard players add @s class_ability_index 1
function roguecraft:ability/classes/toggle_index/prevent_toggle_overflow with storage roguecraft:master
function roguecraft:ability/classes/toggle_index/get_class_ability_name with storage roguecraft:master
function roguecraft:ability/classes/toggle_index/tell_class_ability with storage roguecraft:master