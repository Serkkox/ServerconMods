#set strength
function roguecraft:ability/magic_strength/multiply {multiplier:0.4}
function roguecraft:ability/magic_strength/round
function roguecraft:ability/magic_strength/cap {cap:3}

#heal
function roguecraft:ability/heal/heal with storage roguecraft:master magic_strength

#presentation
particle minecraft:heart ~ ~1 ~ 0.5 0.5 0.5 1 4 normal @a
playsound minecraft:block.enchantment_table.use master @a ~ ~ ~ 2 1.5