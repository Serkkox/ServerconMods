setblock ~ ~ ~ minecraft:air destroy
data modify entity @n[type=minecraft:item,distance=..1.5] Age set value 1s