#resistance
effect give @s minecraft:resistance 1 3 true

#set explosion damage and summon creeper
function roguecraft:ability/magic_strength/multiply {multiplier:0.61}
function roguecraft:ability/magic_strength/round
function roguecraft:ability/explosion/summon_tnt with storage roguecraft:master magic_strength

#sounds
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 2 1.5
execute as @s[scores={parry_timer=1..}] run playsound minecraft:block.conduit.deactivate master @a ~ ~ ~ 2 1