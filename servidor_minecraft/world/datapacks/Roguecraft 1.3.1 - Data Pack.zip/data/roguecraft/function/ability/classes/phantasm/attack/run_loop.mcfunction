$execute at @a[tag=current_main_temp,limit=1] rotated $(phantasm_angle) -60 positioned ^ ^ ^5 run function roguecraft:ability/classes/phantasm/attack/spawn_phantasm with entity @s

#change values
execute store result storage roguecraft:master phantasm.active.phantasm_angle int 1 run scoreboard players operation #roguecraft_master phantasm_active_angle += #roguecraft_master phantasm_active_angle_inc
execute store result storage roguecraft:master phantasm.active.phantasms int 1 run scoreboard players remove #roguecraft_master phantasms 1

#tellraw @a {"score":{"name":"#roguecraft_master","objective":"phantasms"}}

#repeat loop
execute if score #roguecraft_master phantasms matches 1.. run function roguecraft:ability/classes/phantasm/attack/run_loop with storage roguecraft:master phantasm.active