#set values
execute store result storage roguecraft:master phantasm.active.phantasm_angle int 1 run scoreboard players operation #roguecraft_master phantasm_active_angle = #roguecraft_master phantasm_angle
execute store result storage roguecraft:master phantasm.active.phantasms int 1 run scoreboard players operation #roguecraft_master phantasms = @a[tag=current_main_temp,limit=1] phantasms

scoreboard players operation #roguecraft_master phantasm_active_angle_inc = 360 int
scoreboard players operation #roguecraft_master phantasm_active_angle_inc /= @a[tag=current_main_temp,limit=1] phantasms

#run loop
function roguecraft:ability/classes/phantasm/attack/run_loop with storage roguecraft:master phantasm.active