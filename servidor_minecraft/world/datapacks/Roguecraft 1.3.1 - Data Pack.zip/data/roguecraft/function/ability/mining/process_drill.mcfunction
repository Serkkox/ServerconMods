#tick
scoreboard players remove @s gigadrill_range_current 1
tp @s[scores={gigadrill_range_current=..0}] ~ -1000 ~
kill @s[scores={gigadrill_range_current=..0}]
tp @s[scores={gigadrill_range_current=1..}] ^ ^ ^0.5

#mine
execute at @s run function roguecraft:ability/mining/mine_core
execute at @s if entity @s[tag=extended_drill] run function roguecraft:ability/mining/mine_extension

#nice try advancement
execute in roguecraft:infinite_garden positioned 0 ~ 0 unless entity @s[distance=76..84] run return 0
advancement grant @a only roguecraft:infinite_garden/destroy_hub
tp @s ~ -1000 ~
kill @s