#remove max mana
scoreboard players operation @s mid_run_max_mana -= #roguecraft_master class_cost_4_1

#set soul charge to mana
function roguecraft:upgrades/set_max_soul_charge

#update mana bar
function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/set_mana_bar"}