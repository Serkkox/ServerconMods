tag @s add tamed
$data modify entity @s Trusted set value [$(current_uuid)]
particle minecraft:heart ~ ~ ~ 0.5 0.5 0.5 0 6