kill @s
$kill @e[type=minecraft:item_display,tag=hunter_trap,tag=$(type)_trap,nbt={UUID:$(claw_1)},limit=1,distance=..5]
$kill @e[type=minecraft:item_display,tag=hunter_trap,tag=$(type)_trap,nbt={UUID:$(claw_2)},limit=1,distance=..5]
$kill @e[type=minecraft:item_display,tag=hunter_trap,tag=$(type)_trap,nbt={UUID:$(icon)},limit=1,distance=..5]
$kill @e[type=minecraft:item_display,tag=hunter_trap,tag=$(type)_trap,nbt={UUID:$(base)},limit=1,distance=..5]