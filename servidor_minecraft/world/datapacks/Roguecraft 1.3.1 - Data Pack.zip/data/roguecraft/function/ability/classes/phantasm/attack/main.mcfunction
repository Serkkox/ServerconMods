#store amount of phantasms
execute store result storage roguecraft:master phantasm.amount int 1 run scoreboard players get @s phantasms
execute at @a[tag=current_main_temp] run function roguecraft:ability/classes/phantasm/attack/init_loop with storage roguecraft:master phantasm