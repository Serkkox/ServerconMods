#bossbar and timer stuff
scoreboard players remove @s liquid_timer 1
execute if score @s liquid_timer matches 0.. run function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/liquid_walker/update_bossbar"}

#break
execute if entity @s[gamemode=spectator] run return 0
execute if score @s liquid_timer matches ..0 run return 0

#place blocks
execute at @s store success storage roguecraft:master walker_success.snow byte 1 run fill ~1 ~-1 ~1 ~-1 ~-1 ~-1 minecraft:snow_block replace minecraft:powder_snow
execute at @s[predicate=!roguecraft:in_boat] store success storage roguecraft:master walker_success.water byte 1 run fill ~1 ~-1 ~1 ~-1 ~-1 ~-1 minecraft:ice replace minecraft:water
execute at @s store success storage roguecraft:master walker_success.lava byte 1 run fill ~1 ~-1 ~1 ~-1 ~-1 ~-1 minecraft:basalt replace minecraft:lava

execute at @s[predicate=roguecraft:in_boat] unless block ~ ~ ~ minecraft:water store success storage roguecraft:master walker_success.water byte 1 run fill ~2 ~ ~2 ~-2 ~ ~-2 minecraft:ice replace minecraft:water
execute at @s[predicate=roguecraft:in_boat] unless block ~ ~ ~ minecraft:water rotated ~ 0 positioned ^ ^ ^2 store success storage roguecraft:master walker_success.water byte 1 run fill ~2 ~ ~2 ~-2 ~ ~-2 minecraft:ice replace minecraft:water
execute at @s[predicate=roguecraft:in_boat] unless block ~ ~ ~ minecraft:water rotated ~ 0 positioned ^ ^ ^4 store success storage roguecraft:master walker_success.water byte 1 run fill ~2 ~ ~2 ~-2 ~ ~-2 minecraft:ice replace minecraft:water

execute at @s[predicate=roguecraft:in_boat] if block ~ ~ ~ minecraft:water store success storage roguecraft:master walker_success.water byte 1 run fill ~1 ~-1 ~1 ~-1 ~-1 ~-1 minecraft:ice replace minecraft:water

#sound
execute at @s if data storage roguecraft:master {walker_success:{snow:1b}} run playsound block.snow.place block @a ~ ~-1 ~ 0.8
execute at @s if data storage roguecraft:master {walker_success:{water:1b}} run playsound block.glass.place block @a ~ ~-1 ~ 0.5
execute at @s if data storage roguecraft:master {walker_success:{lava:1b}} run playsound block.basalt.place block @a ~ ~-1 ~ 0.8