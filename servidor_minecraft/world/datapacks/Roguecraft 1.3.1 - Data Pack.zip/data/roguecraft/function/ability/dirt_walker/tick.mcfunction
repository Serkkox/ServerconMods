#bossbar and timer stuff
scoreboard players remove @s dirt_timer 1
execute if score @s dirt_timer matches 0.. run function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/dirt_walker/update_bossbar"}

#break
execute if entity @s[gamemode=spectator] run return 0
execute if score @s dirt_timer matches ..0 run return 0

#place blocks
execute at @s store success storage roguecraft:master walker_success.air byte 1 run fill ~1 ~-1 ~1 ~-1 ~-1 ~-1 minecraft:dirt replace #minecraft:air

#sound
execute at @s if data storage roguecraft:master {walker_success:{air:1b}} run playsound block.gravel.place block @a ~ ~-1 ~ 0.4 0.75