execute if block ~ ~ ~ minecraft:lightning_rod run summon minecraft:lightning_bolt
execute if block ~ ~ ~ minecraft:decorated_pot run setblock ~ ~ ~ air destroy

execute as @e[tag=shockbolt_split_hit] run function roguecraft:ability/shockbolt/damage with storage roguecraft:master shockbolt_split

tag @e remove shockbolt_immune
tag @e remove shockbolt_split_immune
tag @s remove current_main