effect give @s minecraft:resistance 30
effect give @s minecraft:regeneration 30
effect give @s minecraft:strength 30
effect give @s minecraft:speed 30

particle minecraft:trial_spawner_detection ~ ~ ~ 0.5 0.5 0.5 0 6