#create main armor stand
execute at @s anchored eyes run summon minecraft:armor_stand ~ ~ ~ {Marker:true,Tags:["gigadrill","current_main"],attributes:[{id:"minecraft:scale",base:0.01}],Invisible:true,Silent:true,NoAI:true,Invulnerable:true,HandItems:[{},{}]}

#give "pickaxe" (actually just a button. i know, crazy i would lie here of all places. you didn't expect that one, did you. fooled again)
execute store result storage roguecraft:master gigadrill.fortune int 1 run scoreboard players get @s mid_run_pickaxe_fortune_level
execute if score @s fortune matches 1.. as @n[tag=current_main] run function roguecraft:ability/mining/give_pickaxe with storage roguecraft:master gigadrill
execute anchored eyes run tp @e[tag=current_main,distance=..2] ^ ^ ^ ~ ~

#set tool level
scoreboard players operation @e[type=minecraft:armor_stand,tag=gigadrill,tag=current_main,distance=..5] tool = @s tool

#set range
$function roguecraft:ability/magic_strength/multiply_by_storage_data {data:"gigadrill.level_$(level)"}
execute store result score @e[type=minecraft:armor_stand,tag=gigadrill,tag=current_main,distance=..5] gigadrill_range_current run data get storage roguecraft:master magic_strength.result
$execute unless score 2 int matches $(level).. run tag @e[type=minecraft:armor_stand,tag=gigadrill,tag=current_main,distance=..5] add extended_drill

tag @e[tag=current_main,distance=..10] remove current_main

#tag @s add current_main

#summon minecraft:marker ^1 ^1 ^0.7 {Tags:["gigadrill","current_main"]}
#summon minecraft:marker ^1 ^ ^0.7 {Tags:["gigadrill","current_main"]}
#summon minecraft:marker ^1 ^-1 ^0.7 {Tags:["gigadrill","current_main"]}
#summon minecraft:marker ^ ^1 ^0.7 {Tags:["gigadrill","current_main"]}
#summon minecraft:marker ^ ^ ^0.7 {Tags:["gigadrill","current_main"]}
#summon minecraft:marker ^ ^-1 ^0.7 {Tags:["gigadrill","current_main"]}
#summon minecraft:marker ^-1 ^1 ^0.7 {Tags:["gigadrill","current_main"]}
#summon minecraft:marker ^-1 ^ ^0.7 {Tags:["gigadrill","current_main"]}
#summon minecraft:marker ^-1 ^-1 ^0.7 {Tags:["gigadrill","current_main"]}

#$execute if score 3 int matches $(level) run summon marker ^2 ^-1 ^0.7 {Tags:["gigadrill","current_main"]}
#$execute if score 3 int matches $(level) run summon marker ^2 ^ ^0.7 {Tags:["gigadrill","current_main"]}
#$execute if score 3 int matches $(level) run summon marker ^2 ^1 ^0.7 {Tags:["gigadrill","current_main"]}
#$execute if score 3 int matches $(level) run summon marker ^-2 ^-1 ^0.7 {Tags:["gigadrill","current_main"]}
#$execute if score 3 int matches $(level) run summon marker ^-2 ^ ^0.7 {Tags:["gigadrill","current_main"]}
#$execute if score 3 int matches $(level) run summon marker ^-2 ^1 ^0.7 {Tags:["gigadrill","current_main"]}
#$execute if score 3 int matches $(level) run summon marker ^-1 ^2 ^0.7 {Tags:["gigadrill","current_main"]}
#$execute if score 3 int matches $(level) run summon marker ^ ^2 ^0.7 {Tags:["gigadrill","current_main"]}
#$execute if score 3 int matches $(level) run summon marker ^1 ^2 ^0.7 {Tags:["gigadrill","current_main"]}
#$execute if score 3 int matches $(level) run summon marker ^-1 ^-2 ^0.7 {Tags:["gigadrill","current_main"]}
#$execute if score 3 int matches $(level) run summon marker ^ ^-2 ^0.7 {Tags:["gigadrill","current_main"]}
#$execute if score 3 int matches $(level) run summon marker ^1 ^-2 ^0.7 {Tags:["gigadrill","current_main"]}

#execute as @e[type=minecraft:marker,tag=gigadrill,tag=current_main] at @s rotated as @a[tag=current_main,limit=1] run tp @s ~ ~ ~ ~ ~

#$execute store result score @e[type=minecraft:marker,tag=gigadrill,tag=current_main] gigadrill_range_current run data get storage roguecraft:master gigadrill.level_$(level)
#scoreboard players operation @e[type=minecraft:marker,tag=gigadrill,tag=current_main] tool = @a[tag=current_main] tool

#tag @e[tag=current_main] remove current_main