$execute store result storage roguecraft:master temp_score_level int 1 run scoreboard players get @s ability_$(name)
execute if data storage roguecraft:master {temp_score_level:0,scroll_used:1b} run data modify storage roguecraft:master temp_score_level set value 1
$data modify storage roguecraft:master temp_name set value "$(name)"

execute if data storage roguecraft:master {temp_name:"liquid_walker"} if score @s liquid_timer matches 20.. run return run function roguecraft:ability/cancel_walker {type:"liquid"}
execute if data storage roguecraft:master {temp_name:"dirt_walker"} if score @s dirt_timer matches 20.. run return run function roguecraft:ability/cancel_walker {type:"dirt"}
execute if data storage roguecraft:master {temp_name:"copy"} run return run function roguecraft:ability/copy/main

execute if data storage roguecraft:master {scroll_used:0b} run function roguecraft:ability/check_mana with storage roguecraft:master
execute if data storage roguecraft:master {scroll_used:1b} run function roguecraft:ability/scroll/execute with storage roguecraft:master