$summon minecraft:marker ~ ~ ~ {Tags:["phantasm","current_main_phantasm"],data:{UUID:$(UUID)}}
data modify entity @e[distance=..1,type=minecraft:marker,tag=current_main_phantasm,limit=1] data.owner set from entity @a[tag=current_main_temp,limit=1] UUID
tag @e[distance=..1] remove current_main_phantasm