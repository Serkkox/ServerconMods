$execute unless score @s class matches 4 if score @s mana >= #roguecraft_master ability_cost_$(temp_score_ability)_$(temp_score_level) run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.use_ability","italic":true,"color":"blue","with":[{"translate":"roguecraft.ability.name.ability_$(temp_name)"}]}
$execute if score @s class matches 4 if score @s soul_charge matches 1.. run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.use_ability","italic":true,"color":"blue","with":[{"translate":"roguecraft.ability.name.ability_$(temp_name)"}]}
$execute unless score @s class matches 4 if score @s mana >= #roguecraft_master ability_cost_$(temp_score_ability)_$(temp_score_level) run function roguecraft:ability/$(temp_name)/level_$(temp_score_level)

$execute if score @s class matches 4 if score @s soul_charge matches 1.. run function roguecraft:ability/$(temp_name)/level_$(temp_score_level)

$execute unless score @s class matches 4 unless score @s mana >= #roguecraft_master ability_cost_$(temp_score_ability)_$(temp_score_level) as @s run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.ability_no_mana","italic":true,"color":"red"}
execute if score @s class matches 4 unless score @s soul_charge matches 1.. as @s run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.ability_no_soul_charge","italic":true,"color":"red"}
$execute unless score @s class matches 4 unless score @s mana >= #roguecraft_master ability_cost_$(temp_score_ability)_$(temp_score_level) as @s run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5
execute if score @s class matches 4 unless score @s soul_charge matches 1.. as @s run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5

$execute unless score @s class matches 4 if score @s mana >= #roguecraft_master ability_cost_$(temp_score_ability)_$(temp_score_level) run scoreboard players operation @s mana -= #roguecraft_master ability_cost_$(temp_score_ability)_$(temp_score_level)
execute if score @s class matches 4 if score @s soul_charge matches 1.. run scoreboard players remove @s soul_charge 1

function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/set_mana_bar"}