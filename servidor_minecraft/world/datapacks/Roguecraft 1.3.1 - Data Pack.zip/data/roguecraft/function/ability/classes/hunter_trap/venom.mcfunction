execute as @e[type=!#roguecraft:hunter_trap_components,distance=..2] run damage @s 8 roguecraft:venom_trap

effect give @s[type=!#minecraft:undead] minecraft:poison 10 1
effect give @s[type=#minecraft:undead] minecraft:wither 10 1
effect give @s minecraft:slowness 10 1
effect give @s minecraft:weakness 10 0
effect give @s minecraft:mining_fatigue 10 0
effect give @s minecraft:nausea 10 0