particle minecraft:dust{color:[0.2,0.2,0.2],scale:1.5} ~ ~ ~ 0.3 0.3 0.3 1 3

execute if block ~ ~ ~ #roguecraft:container run return run function roguecraft:ability/mining/mine_container
execute if block ~ ~ ~ #minecraft:air run return 0

execute if score @s tool matches 0..2 unless block ~ ~ ~ #roguecraft:incorrect_for_stone_tool run return run function roguecraft:ability/mining/destory_block
execute if score @s tool matches 3 unless block ~ ~ ~ #roguecraft:incorrect_for_iron_tool run return run function roguecraft:ability/mining/destory_block
execute if score @s tool matches 4 unless block ~ ~ ~ #roguecraft:incorrect_for_diamond_tool run return run function roguecraft:ability/mining/destory_block
execute if score @s tool matches 5..6 unless block ~ ~ ~ #roguecraft:incorrect_for_netherite_tool run return run function roguecraft:ability/mining/destory_block