#set timer (base 80)
function roguecraft:ability/magic_strength/multiply {multiplier:8}
execute store result score @s liquid_timer run data get storage roguecraft:master magic_strength.result

#apply bossbar
tag @a[scores={liquid_timer=1..}] add apply_liquid_bar
tag @s add ability_bossbar
function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/liquid_walker/apply_bossbar"}
tag @a remove apply_liquid_bar

#sound
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 2 1.5