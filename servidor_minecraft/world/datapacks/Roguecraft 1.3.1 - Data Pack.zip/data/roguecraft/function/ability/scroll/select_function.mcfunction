data modify storage roguecraft:master class_ability_success set value 1b

$function $(function)

execute if data storage roguecraft:master {mainhand_scroll:1b,class_ability_success:1b} run item modify entity @s[gamemode=!creative] weapon.mainhand roguecraft:decrease
#execute if data storage roguecraft:master {mainhand_scroll:0b,class_ability_success:1b} run item modify entity @s[gamemode=!creative] weapon.offhand roguecraft:decrease