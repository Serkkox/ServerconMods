execute unless score @s current_health matches 9.. run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.class_ability.healer_error_no_health","italic":true,"color":"red"}
execute unless score @s current_health matches 9.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5
execute unless score @s current_health matches 9.. run data modify storage roguecraft:master class_ability_success set value 0b
execute if score @s current_health matches 9.. run function roguecraft:ability/classes/revitalize/revive