#bossbar and timer stuff
scoreboard players remove @s final_adrenaline_timer 1
execute if score @s final_adrenaline_timer matches -5.. run function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/classes/final_adrenaline/update_bossbar"}

#break
execute if entity @s[gamemode=spectator] run return 0

#particles
execute at @s run particle minecraft:trial_spawner_detection ~ ~ ~ 1 1 1 0 2

#remove modifiers
execute if score @s final_adrenaline_timer matches ..-1 run function roguecraft:ability/classes/final_adrenaline/remove_modifiers

#survived
execute if score @s final_adrenaline_timer matches -1 if score @s final_adrenaline_counter matches ..0 at @s run playsound minecraft:entity.zombie.infect master @s ~ ~ ~ 1 1

#sound 1
execute if score @s final_adrenaline_timer matches 40 if score @s final_adrenaline_counter matches ..0 at @s run playsound minecraft:entity.allay.item_thrown master @s ~ ~ ~ 1 1.5
execute if score @s final_adrenaline_timer matches 30 if score @s final_adrenaline_counter matches ..0 at @s run playsound minecraft:entity.allay.item_thrown master @s ~ ~ ~ 1 1.5
execute if score @s final_adrenaline_timer matches 20 if score @s final_adrenaline_counter matches ..0 at @s run playsound minecraft:entity.allay.item_thrown master @s ~ ~ ~ 1 1.5
execute if score @s final_adrenaline_timer matches 10 if score @s final_adrenaline_counter matches ..0 at @s run playsound minecraft:entity.allay.item_thrown master @s ~ ~ ~ 1 1.5
execute if score @s final_adrenaline_timer matches 0 if score @s final_adrenaline_counter matches ..0 at @s run playsound minecraft:entity.allay.item_thrown master @s ~ ~ ~ 1 1.5

#return in case the player is not in danger
execute if score @s final_adrenaline_timer matches 151.. run return 0
execute if score @s final_adrenaline_counter matches ..0 run return 0

#sound 2
execute if score @s final_adrenaline_timer matches 150 at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 1
execute if score @s final_adrenaline_timer matches 120 at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 1
execute if score @s final_adrenaline_timer matches 90 at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 1
execute if score @s final_adrenaline_timer matches 60 at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 1
execute if score @s final_adrenaline_timer matches 50 at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 1.05
execute if score @s final_adrenaline_timer matches 40 at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 1.1
execute if score @s final_adrenaline_timer matches 30 at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 1.15
execute if score @s final_adrenaline_timer matches 20 at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 1.2
execute if score @s final_adrenaline_timer matches 10 at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 1.25
execute if score @s final_adrenaline_timer matches 0 at @s run playsound minecraft:entity.warden.heartbeat master @s ~ ~ ~ 1 1.25

#killlllllll
execute if score @s final_adrenaline_timer matches -2 if score @s final_adrenaline_counter matches 1.. at @s run playsound minecraft:block.beacon.deactivate master @s ~ ~ ~
execute if score @s final_adrenaline_timer matches ..-2 if score @s final_adrenaline_counter matches 1.. run damage @s[scores={parry_timer=..0},gamemode=!creative] 100000 roguecraft:final_adrenaline
execute if score @s final_adrenaline_timer matches ..-2 if score @s final_adrenaline_counter matches 1.. run damage @s[scores={parry_timer=1..},gamemode=!creative] 100000 roguecraft:final_adrenaline_parry