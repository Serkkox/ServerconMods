#check if scroll isn't already selected
$execute if score @s ability_copied matches $(temp_score_ability) unless score @s ability_copied matches 100.. run return run function roguecraft:ability/copy/get_values_regular
#$execute if score @s ability_copied matches $(temp_score_ability) if score @s ability_copied matches 100.. run return run function roguecraft:ability/copy/get_values_class

#process scroll
execute if data entity @s Inventory[{Slot:-106b,components:{"minecraft:custom_data":{class_scroll:1b}}}] run return run function roguecraft:ability/copy/process_class
function roguecraft:ability/copy/process_regular