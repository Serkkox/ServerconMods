#add tags for immunity
tag @s add shockbolt_immune
tag @s add current_main
tag @s add shockbolt_split_immune

#make similar mobs immune
execute if entity @s[type=minecraft:player] run tag @a[distance=..64] add shockbolt_split_immune
execute if entity @s[type=!minecraft:player] run tag @e[type=!minecraft:player,distance=..64] add shockbolt_immune
execute if entity @s[type=!minecraft:player] run tag @e[type=!minecraft:player,distance=..64] add shockbolt_split_immune

#init scores
$scoreboard players set @s split_count $(split_count)
$scoreboard players set @s steps $(steps)
$scoreboard players set @s temp $(level)

#set damage 
$function roguecraft:ability/magic_strength/multiply {multiplier:$(damage)}
data modify storage roguecraft:master shockbolt_damage set from storage roguecraft:master magic_strength.result

execute store result storage roguecraft:master shockbolt_damage_water int 1.5 run data get storage roguecraft:master shockbolt_damage

execute store result storage roguecraft:master shockbolt_split.shockbolt_damage int 0.33 run data get storage roguecraft:master shockbolt_damage
execute store result storage roguecraft:master shockbolt_split.shockbolt_damage_water int 0.33 run data get storage roguecraft:master shockbolt_damage_water

execute store result storage roguecraft:master shockbolt_self_damage int 0.25 run data get storage roguecraft:master shockbolt_damage

playsound minecraft:block.trial_spawner.spawn_mob player @s ~ ~ ~ 0.5 2
playsound minecraft:entity.generic.explode player @s ~ ~ ~ 0.2 1.5
particle minecraft:wax_on ^ ^0.2 ^1 0.25 0.5 0.25 100 30

execute if block ~ ~ ~ minecraft:water run function roguecraft:ability/shockbolt/self_damage with storage roguecraft:master

execute if predicate {"condition":"minecraft:entity_properties","entity":"this","predicate":{"flags":{"is_swimming":true}}} run return run execute positioned ~ ~0.4 ~ run function roguecraft:ability/shockbolt/raycast_run
execute positioned ~ ~1.3 ~ run function roguecraft:ability/shockbolt/raycast_run