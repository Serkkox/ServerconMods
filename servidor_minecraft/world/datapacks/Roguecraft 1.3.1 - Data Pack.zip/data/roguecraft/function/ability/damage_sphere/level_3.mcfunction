#set damage
function roguecraft:ability/magic_strength/multiply {multiplier:1.0}

#deal damage
tag @s add current_main
execute at @s as @e[type=!minecraft:item,distance=0.1..8] run function roguecraft:ability/damage_sphere/damage with storage roguecraft:master magic_strength
tag @s remove current_main

#sound
playsound minecraft:entity.shulker.shoot master @a ~ ~ ~ 2 0.8
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 2 1.5

#particles
particle minecraft:end_rod ~ ~ ~ 0 0 0 1 80 normal

execute positioned ~ ~1 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:1000,total_steps:90,vertical:0,other_angle:0,particle_type:"minecraft:crit",speed:0.0000000065,force:"normal"}
execute positioned ~ ~1 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:1000,total_steps:90,vertical:0,other_angle:45,particle_type:"minecraft:crit",speed:0.0000000065,force:"normal"}
execute positioned ~ ~1 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:1000,total_steps:90,vertical:0,other_angle:-45,particle_type:"minecraft:crit",speed:0.0000000065,force:"normal"}

execute positioned ~ ~1 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:1000,total_steps:90,vertical:1,other_angle:0,particle_type:"minecraft:crit",speed:0.0000000065,force:"normal"}
execute positioned ~ ~1 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:1000,total_steps:90,vertical:1,other_angle:45,particle_type:"minecraft:crit",speed:0.0000000065,force:"normal"}
execute positioned ~ ~1 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:1000,total_steps:90,vertical:1,other_angle:90,particle_type:"minecraft:crit",speed:0.0000000065,force:"normal"}
execute positioned ~ ~1 ~ summon minecraft:marker run function roguecraft:particles/ring/init {start_angle:1000,total_steps:90,vertical:1,other_angle:135,particle_type:"minecraft:crit",speed:0.0000000065,force:"normal"}