data modify storage roguecraft:master current_uuid set from entity @s UUID
function roguecraft:ability/classes/heal_orbs/create_orb with storage roguecraft:master