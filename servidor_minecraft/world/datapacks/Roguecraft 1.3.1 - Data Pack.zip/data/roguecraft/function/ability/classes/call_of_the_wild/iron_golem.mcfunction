tag @s add tamed
data modify entity @s PlayerCreated set value true
particle minecraft:heart ~ ~ ~ 0.5 0.5 0.5 0 6