execute if score @s mid_run_max_mana >= #roguecraft_master class_cost_4_1 run return run function roguecraft:ability/classes/phantasm/summon/check_count

execute if score @s class matches 4 run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.ability_no_max_soul_charge","italic":true,"color":"red"}
execute unless score @s class matches 4 run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.ability_no_max_mana","italic":true,"color":"red"}
playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5
data modify storage roguecraft:master class_ability_success set value 0b