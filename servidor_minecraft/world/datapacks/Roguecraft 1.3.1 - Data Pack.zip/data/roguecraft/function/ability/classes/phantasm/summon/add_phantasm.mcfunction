function roguecraft:ability/classes/phantasm/remove_max_soul_charge

scoreboard players add @s phantasms 1
title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.use_ability","italic":true,"color":"dark_purple","with":[{"translate":"roguecraft.class_ability.phantasm"}]}
playsound minecraft:block.beacon.deactivate master @a ~ ~ ~ 0.125 0.8
playsound minecraft:entity.blaze.shoot master @a ~ ~ ~ 0.1