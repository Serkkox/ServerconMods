$execute as @a[nbt={UUID:$(owner)}] run damage @e[tag=current_main,limit=1,distance=..1] 2 roguecraft:phantasm
function roguecraft:ability/classes/phantasm/kill