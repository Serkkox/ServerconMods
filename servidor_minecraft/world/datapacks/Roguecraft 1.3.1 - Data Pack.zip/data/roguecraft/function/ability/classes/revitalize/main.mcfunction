execute store result score @s current_health run attribute @s minecraft:max_health base get
execute unless entity @p[gamemode=spectator] run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.class_ability.healer_error_all_alive","italic":true,"color":"red"}
execute unless entity @p[gamemode=spectator] run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5
execute unless entity @p[gamemode=spectator] run data modify storage roguecraft:master class_ability_success set value 0b
execute if entity @p[gamemode=spectator] run function roguecraft:ability/classes/revitalize/check_success