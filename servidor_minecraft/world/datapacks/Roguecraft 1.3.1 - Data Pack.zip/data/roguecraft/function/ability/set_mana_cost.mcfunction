#explosion
scoreboard players set #roguecraft_master ability_cost_0_1 40
scoreboard players set #roguecraft_master ability_cost_0_2 50
scoreboard players set #roguecraft_master ability_cost_0_3 60
#heal
scoreboard players set #roguecraft_master ability_cost_1_1 40
scoreboard players set #roguecraft_master ability_cost_1_2 35
scoreboard players set #roguecraft_master ability_cost_1_3 30
#mine
scoreboard players set #roguecraft_master ability_cost_2_1 15
scoreboard players set #roguecraft_master ability_cost_2_2 20
scoreboard players set #roguecraft_master ability_cost_2_3 25
#damage
scoreboard players set #roguecraft_master ability_cost_3_1 30
scoreboard players set #roguecraft_master ability_cost_3_2 28
scoreboard players set #roguecraft_master ability_cost_3_3 25
#arrow
scoreboard players set #roguecraft_master ability_cost_4_1 12
scoreboard players set #roguecraft_master ability_cost_4_2 9
scoreboard players set #roguecraft_master ability_cost_4_3 5
#parry
scoreboard players set #roguecraft_master ability_cost_5_1 40
scoreboard players set #roguecraft_master ability_cost_5_2 35
scoreboard players set #roguecraft_master ability_cost_5_3 30
#fireball
scoreboard players set #roguecraft_master ability_cost_6_1 25
scoreboard players set #roguecraft_master ability_cost_6_2 20
scoreboard players set #roguecraft_master ability_cost_6_3 15
#levitate
scoreboard players set #roguecraft_master ability_cost_7_1 40
scoreboard players set #roguecraft_master ability_cost_7_2 38
scoreboard players set #roguecraft_master ability_cost_7_3 35
#liquid walker
scoreboard players set #roguecraft_master ability_cost_8_1 40
scoreboard players set #roguecraft_master ability_cost_8_2 32
scoreboard players set #roguecraft_master ability_cost_8_3 25
#dirt walker
scoreboard players set #roguecraft_master ability_cost_11_1 80
scoreboard players set #roguecraft_master ability_cost_11_2 80
scoreboard players set #roguecraft_master ability_cost_11_3 80
#shockbolt
scoreboard players set #roguecraft_master ability_cost_12_1 15
scoreboard players set #roguecraft_master ability_cost_12_2 20
scoreboard players set #roguecraft_master ability_cost_12_3 25
#copy
scoreboard players set #roguecraft_master ability_cost_13_1 0
scoreboard players set #roguecraft_master ability_cost_13_2 0
scoreboard players set #roguecraft_master ability_cost_13_3 0

##class abilities
#invulnerable shield
scoreboard players set #roguecraft_master class_cost_0_0 140
#aggravate
scoreboard players set #roguecraft_master class_cost_0_1 20
#multiheal
scoreboard players set #roguecraft_master class_cost_2_0 50
#invigorate
scoreboard players set #roguecraft_master class_cost_2_0 50
#cleanse
scoreboard players set #roguecraft_master class_cost_2_1 35
#revive
scoreboard players set #roguecraft_master class_cost_2_2 40
#final adrenaline
scoreboard players set #roguecraft_master class_cost_3_1 50
#phantasm
scoreboard players set #roguecraft_master class_cost_4_1 30
#call of the wild
scoreboard players set #roguecraft_master class_cost_5_0 70
#venom trap
scoreboard players set #roguecraft_master class_cost_5_1 20
#leech trap
scoreboard players set #roguecraft_master class_cost_5_2 15
#stun trap
scoreboard players set #roguecraft_master class_cost_5_3 30
#proximity mine (unused)
scoreboard players set #roguecraft_master class_cost_5_4 40

#health
scoreboard players set #roguecraft_master revitalize_health 8
scoreboard players set #roguecraft_master adrenaline_health 6