#set timer (base 130)
function roguecraft:ability/magic_strength/multiply {multiplier:13}
execute store result score @s dirt_timer run data get storage roguecraft:master magic_strength.result

#apply bossbar
tag @a[scores={dirt_timer=1..}] add apply_dirt_bar
tag @s add ability_bossbar
function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/dirt_walker/apply_bossbar"}
tag @a remove apply_dirt_bar

#sound
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 2 1.5