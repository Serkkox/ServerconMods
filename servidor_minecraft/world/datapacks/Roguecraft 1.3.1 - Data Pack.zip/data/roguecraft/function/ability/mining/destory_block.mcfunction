loot spawn ~ ~ ~ mine ~ ~ ~ mainhand
data modify entity @n[type=minecraft:item,distance=..0.0001] Age set value 1s

setblock ~ ~ ~ minecraft:air destroy
execute as @e[type=minecraft:item,distance=..1] if data entity @s {Age:0s} unless data entity @s Thrower run kill @s