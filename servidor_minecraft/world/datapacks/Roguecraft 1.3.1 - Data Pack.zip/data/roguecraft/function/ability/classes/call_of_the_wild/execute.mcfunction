function roguecraft:ability/classes/call_of_the_wild/particles

playsound minecraft:entity.wolf.growl master @a ~ ~ ~ 0.5
playsound minecraft:entity.parrot.ambient master @a ~ ~ ~ 0.5
playsound minecraft:entity.hoglin.ambient master @a ~ ~ ~ 0.5
playsound minecraft:entity.horse.ambient master @a ~ ~ ~ 0.5
playsound minecraft:entity.warden.roar master @a ~ ~ ~ 1
playsound minecraft:item.trident.thunder master @a ~ ~ ~ 2 1.1

data modify storage roguecraft:master current_uuid set from entity @s UUID
execute as @e[type=#roguecraft:tameable,distance=..8] at @s unless data entity @s Owner run function roguecraft:ability/classes/call_of_the_wild/tame with storage roguecraft:master
execute as @e[type=minecraft:allay,distance=..8] at @s unless data entity @s Brain.memories."minecraft:liked_player".value run function roguecraft:ability/classes/call_of_the_wild/allay with storage roguecraft:master
execute as @e[type=minecraft:fox,distance=..8] at @s unless data entity @s Trusted[0] run function roguecraft:ability/classes/call_of_the_wild/fox with storage roguecraft:master
execute as @e[type=minecraft:axolotl,distance=..8] at @s unless data entity @s {FromBucket:true} run function roguecraft:ability/classes/call_of_the_wild/axolotl
execute as @e[type=minecraft:iron_golem,distance=..8] at @s unless data entity @s {PlayerCreated:true} run function roguecraft:ability/classes/call_of_the_wild/iron_golem
execute as @e[type=minecraft:dolphin,distance=..8] at @s unless data entity @s {GotFish:true} run function roguecraft:ability/classes/call_of_the_wild/dolphin

execute as @e[type=#roguecraft:tameable_all,distance=..8] at @s run function roguecraft:ability/classes/call_of_the_wild/buff
execute as @a[name="mePenguh",distance=0.1..8] at @s run function roguecraft:ability/classes/call_of_the_wild/buff

title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.use_ability","italic":true,"color":"dark_green","with":[{"translate":"roguecraft.class_ability.call_of_the_wild"}]}