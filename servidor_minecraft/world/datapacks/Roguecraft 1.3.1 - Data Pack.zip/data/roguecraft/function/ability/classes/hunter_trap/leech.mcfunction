execute as @e[type=!#roguecraft:hunter_trap_components,distance=..2] run damage @s 6 roguecraft:leech_trap
data modify storage roguecraft:master healer_orb_type set value "leech"
$execute as @a[tag=!current_main,distance=..128,nbt={UUID:$(current_uuid)},limit=1] run function roguecraft:ability/classes/heal_orbs/store_player_uuid