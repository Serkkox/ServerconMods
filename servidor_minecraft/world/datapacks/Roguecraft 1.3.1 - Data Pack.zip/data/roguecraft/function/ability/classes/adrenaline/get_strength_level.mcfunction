scoreboard players add #roguecraft_master temp_health 1
execute store result storage roguecraft:master temp_score_level int 1 run scoreboard players get #roguecraft_master temp_health
function roguecraft:ability/classes/adrenaline/set_strength with storage roguecraft:master