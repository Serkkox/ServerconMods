#get direction
execute as @s in minecraft:overworld positioned 0.0 0.0 0.0 rotated as @s run summon minecraft:marker ^ ^ ^16 {Tags:["fireball"]}
execute as @e[type=minecraft:marker,tag=fireball] run execute store result entity @s data.X double 0.00625 run data get entity @s Pos[0] 6
execute as @e[type=minecraft:marker,tag=fireball] run execute store result entity @s data.Y double 0.00625 run data get entity @s Pos[1] 6
execute as @e[type=minecraft:marker,tag=fireball] run execute store result entity @s data.Z double 0.00625 run data get entity @s Pos[2] 6

#sound
execute at @s run playsound minecraft:entity.blaze.shoot master @a ~ ~ ~

#set strength
function roguecraft:ability/magic_strength/multiply {multiplier:0.275}

#spawn fireball
function roguecraft:ability/fireball/spawn with storage roguecraft:master magic_strength

#set direction
data modify entity @e[type=minecraft:fireball,tag=current_fireball,limit=1] Motion[0] set from entity @e[type=minecraft:marker,tag=fireball,limit=1] data.X
data modify entity @e[type=minecraft:fireball,tag=current_fireball,limit=1] Motion[1] set from entity @e[type=minecraft:marker,tag=fireball,limit=1] data.Y
data modify entity @e[type=minecraft:fireball,tag=current_fireball,limit=1] Motion[2] set from entity @e[type=minecraft:marker,tag=fireball,limit=1] data.Z

#remove temp stuff
tag @e[type=minecraft:fireball,tag=current_fireball] remove current_fireball
kill @e[type=minecraft:marker,tag=fireball]