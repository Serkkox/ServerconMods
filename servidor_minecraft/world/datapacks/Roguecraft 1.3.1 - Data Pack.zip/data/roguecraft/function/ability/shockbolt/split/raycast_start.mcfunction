scoreboard players set #shockbolt_split steps 30
function roguecraft:ability/shockbolt/split/raycast_run