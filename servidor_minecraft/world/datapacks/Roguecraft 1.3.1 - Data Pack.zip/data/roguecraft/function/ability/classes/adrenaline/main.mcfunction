execute store result score @s current_health run attribute @s minecraft:max_health base get
execute unless score @s current_health matches 7.. run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.class_ability.glass_cannon_error","italic":true,"color":"red"}
execute unless score @s current_health matches 7.. run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5
execute unless score @s current_health matches 7.. run data modify storage roguecraft:master class_ability_success set value 0b
execute if score @s current_health matches 7.. run function roguecraft:ability/classes/adrenaline/use