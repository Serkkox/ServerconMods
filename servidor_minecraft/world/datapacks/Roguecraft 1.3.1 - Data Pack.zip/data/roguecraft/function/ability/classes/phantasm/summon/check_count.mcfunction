execute if score @s phantasms matches ..2 run return run function roguecraft:ability/classes/phantasm/summon/add_phantasm

title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.ability_phantasm_max","italic":true,"color":"red"}
playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5
data modify storage roguecraft:master class_ability_success set value 0b