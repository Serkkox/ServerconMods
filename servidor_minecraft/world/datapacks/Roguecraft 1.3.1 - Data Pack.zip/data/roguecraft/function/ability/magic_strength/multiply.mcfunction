function roguecraft:ability/magic_strength/get

$execute store result storage roguecraft:master magic_strength.result double $(multiplier) run scoreboard players get #roguecraft_master magic_strength