$execute at @s if block ~ ~ ~ minecraft:water run damage @s $(shockbolt_damage_water) roguecraft:shockbolt by @n[tag=current_main,distance=..48]
$execute at @s unless block ~ ~ ~ minecraft:water run damage @s $(shockbolt_damage) roguecraft:shockbolt by @n[tag=current_main,distance=..48]

#execute if predicate {"condition": "minecraft:weather_check","raining": true} if score @e[tag=current_main,limit=1] temp matches 3 run summon minecraft:lightning_bolt

tag @s add shockbolt_immune
tag @s remove shockbolt_split_hit