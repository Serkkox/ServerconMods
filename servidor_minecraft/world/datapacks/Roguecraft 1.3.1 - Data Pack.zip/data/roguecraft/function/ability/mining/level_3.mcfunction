execute at @s anchored eyes run function roguecraft:ability/mining/create_drill {level:3}
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 2 1.5