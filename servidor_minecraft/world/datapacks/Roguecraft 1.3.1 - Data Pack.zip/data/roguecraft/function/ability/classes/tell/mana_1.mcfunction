execute store result storage roguecraft:master class_index byte 1 run scoreboard players get @s class
execute store result storage roguecraft:master class_ability_index byte 1 run scoreboard players get @s class_ability_index
function roguecraft:ability/classes/get_true_class_index with storage roguecraft:master
function roguecraft:ability/classes/toggle_index/get_class_ability_name with storage roguecraft:master
execute store result storage roguecraft:master class_index byte 1 run scoreboard players get @s class
function roguecraft:ability/classes/tell/mana_2 with storage roguecraft:master