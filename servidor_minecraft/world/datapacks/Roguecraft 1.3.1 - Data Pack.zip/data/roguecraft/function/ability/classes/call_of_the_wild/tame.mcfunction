tag @s add tamed
$data modify entity @s Owner set value $(current_uuid)
data modify entity @s Tame set value true
particle minecraft:heart ~ ~ ~ 0.5 0.5 0.5 0 6