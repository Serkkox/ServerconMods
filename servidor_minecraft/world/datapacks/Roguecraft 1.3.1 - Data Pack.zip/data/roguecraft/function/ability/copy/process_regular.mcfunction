#process scroll
execute store result score @s ability_copied run data get entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data".temp_score_ability
item modify entity @s weapon.offhand roguecraft:decrease

#get name
execute store result storage roguecraft:master copy_ability.temp_score_ability int 1 run scoreboard players get @s ability_copied
function roguecraft:ability/copy/get_name with storage roguecraft:master copy_ability

#get book
function roguecraft:upgrades/get_ability_cmd/copy_regular
item modify entity @s weapon.mainhand roguecraft:set_ability_cmd

#presentation
function roguecraft:ability/copy/tell_copy_regular with storage roguecraft:master copy_ability
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 1 1.25