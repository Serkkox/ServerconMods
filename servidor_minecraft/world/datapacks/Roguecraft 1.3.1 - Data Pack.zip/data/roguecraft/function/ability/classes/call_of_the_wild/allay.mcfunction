tag @s add tamed
$data modify entity @s Brain.memories."minecraft:liked_player".value set value $(current_uuid)
particle minecraft:heart ~ ~ ~ 0.5 0.5 0.5 0 6