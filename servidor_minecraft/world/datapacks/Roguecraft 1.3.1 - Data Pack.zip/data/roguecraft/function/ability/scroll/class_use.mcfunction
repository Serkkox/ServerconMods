execute as @s unless score @s class matches 4 run scoreboard players set @s soul_charge 5

execute store result storage roguecraft:master mainhand_scroll byte 1 if data entity @s SelectedItem.components."minecraft:custom_data".class_scroll

execute if data storage roguecraft:master {mainhand_scroll:1b} run data modify storage roguecraft:master scroll_data set from entity @s SelectedItem.components."minecraft:custom_data"
execute if data storage roguecraft:master {mainhand_scroll:0b} run data modify storage roguecraft:master scroll_data set from entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data"

function roguecraft:ability/scroll/select_function with storage roguecraft:master scroll_data