execute positioned ^2 ^-1 ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill
execute positioned ^2 ^ ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill
execute positioned ^2 ^1 ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill
execute positioned ^-2 ^-1 ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill
execute positioned ^-2 ^ ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill
execute positioned ^-2 ^1 ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill
execute positioned ^-1 ^2 ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill
execute positioned ^ ^2 ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill
execute positioned ^1 ^2 ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill
execute positioned ^-1 ^-2 ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill
execute positioned ^ ^-2 ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill
execute positioned ^1 ^-2 ^0.7 run function roguecraft:ability/mining/mine with storage roguecraft:master gigadrill












