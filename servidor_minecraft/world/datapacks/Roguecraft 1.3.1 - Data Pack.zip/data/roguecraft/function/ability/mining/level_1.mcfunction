function roguecraft:ability/mining/create_drill {level:1}
playsound minecraft:block.enchantment_table.use master @s ~ ~ ~ 2 1.5