$summon minecraft:marker ~ ~ ~ {Tags:["hunter_trap","$(type)_trap","current_main_0","current_main"],data:{type:$(type)}}
$summon minecraft:armor_stand ~ ~ ~ {Tags:["hunter_trap","$(type)_trap","current_main_1","current_main"],Invisible:1b,Invulnerable:1b,Silent:1b,attributes:[{id:"minecraft:scale",base:0.01}]}
$summon minecraft:item_display ~ ~ ~ {Tags:["hunter_trap","$(type)_trap","current_main_2","current_main"],item:{components:{"minecraft:custom_model_data":500},count:1b,id:"minecraft:totem_of_undying"},teleport_duration:2,transformation:[1f,0f,0f,0f,0f,1f,0f,0.4751f,0f,0f,1f,0f,0f,0f,0f,1f],Rotation:[0.0f,-90.0f]}
$summon minecraft:item_display ~ ~ ~ {Tags:["hunter_trap","$(type)_trap","current_main_3","current_main"],item:{components:{"minecraft:custom_model_data":501},count:1b,id:"minecraft:totem_of_undying"},teleport_duration:2,transformation:[1f,0f,0f,0f,0f,1f,0f,0.4751f,0f,0f,1f,0f,0f,0f,0f,1f],Rotation:[0.0f,90.0f]}
$summon minecraft:item_display ~ ~ ~ {Tags:["hunter_trap","$(type)_trap","current_main_4","current_main"],item:{components:{"minecraft:custom_model_data":520},count:1b,id:"minecraft:totem_of_undying"},teleport_duration:2,transformation:[1f,0f,0f,0f,0f,1f,0f,0.4751f,0f,0f,1f,0f,0f,0f,0f,1f]}
$summon minecraft:item_display ~ ~ ~ {Tags:["hunter_trap","$(type)_trap","current_main_5","current_main"],item:{components:{"minecraft:custom_model_data":522},count:1b,id:"minecraft:totem_of_undying"},teleport_duration:2,billboard:"vertical",transformation:[0.1f,0f,0f,0f,0f,0.1f,0f,0.0f,0f,0f,0.1f,0f,0f,0f,0f,1f]}
#[-1f,0f,0f,0f,0f,-1f,0f,0f,0f,0f,-1f,0f,0f,0f,0f,1f]

$title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.use_ability","italic":true,"color":"dark_green","with":[{"translate":"roguecraft.class_ability.$(type)_trap"}]}
playsound minecraft:block.tripwire.attach master @a ~ ~ ~ 1 0.8
playsound minecraft:item.crossbow.loading_end master @a ~ ~ ~ 1 1

data modify entity @e[type=minecraft:marker,tag=current_main_0,distance=..1,limit=1] data.armor_stand set from entity @e[type=minecraft:armor_stand,tag=current_main_1,distance=..1,limit=1] UUID
data modify entity @e[type=minecraft:marker,tag=current_main_0,distance=..1,limit=1] data.claw_1 set from entity @e[type=minecraft:item_display,tag=current_main_2,distance=..1,limit=1] UUID
data modify entity @e[type=minecraft:marker,tag=current_main_0,distance=..1,limit=1] data.claw_2 set from entity @e[type=minecraft:item_display,tag=current_main_3,distance=..1,limit=1] UUID
data modify entity @e[type=minecraft:marker,tag=current_main_0,distance=..1,limit=1] data.base set from entity @e[type=minecraft:item_display,tag=current_main_4,distance=..1,limit=1] UUID
data modify entity @e[type=minecraft:marker,tag=current_main_0,distance=..1,limit=1] data.icon set from entity @e[type=minecraft:item_display,tag=current_main_5,distance=..1,limit=1] UUID
data modify entity @e[type=minecraft:marker,tag=current_main_0,distance=..1,limit=1] data.owner set from entity @s UUID

scoreboard players set @e[tag=current_main] timer 20

tag @e[tag=current_main] remove current_main
tag @e[tag=current_main_0,distance=..1] remove current_main_0
tag @e[tag=current_main_1,distance=..1] remove current_main_1
tag @e[tag=current_main_2,distance=..1] remove current_main_2
tag @e[tag=current_main_3,distance=..1] remove current_main_3
tag @e[tag=current_main_4,distance=..1] remove current_main_4
tag @e[tag=current_main_5,distance=..1] remove current_main_5