execute as @e[type=!#roguecraft:hunter_trap_components,distance=..2] run damage @s 4 roguecraft:stun_trap

effect give @a[distance=..2] slowness 4 6
execute as @a[distance=..2] run attribute @s minecraft:jump_strength modifier add roguecraft:stun_jump -10 add_multiplied_total

execute as @e[type=!#roguecraft:hunter_trap_components,distance=..2] unless data entity @s {NoAI:1b} run tag @s add stunned
scoreboard players set @e[type=!#roguecraft:hunter_trap_components,distance=..2,tag=stunned] stun_timer 80
execute as @e[type=!#roguecraft:hunter_trap_components,type=!player,distance=..2,tag=stunned] run data modify entity @s NoAI set value 1b
execute as @e[type=!#roguecraft:hunter_trap_components,type=!player,distance=..2,tag=stunned] run data modify entity @s Pos[1] set from entity @e[type=minecraft:marker,tag=current_main,limit=1] Pos[1]