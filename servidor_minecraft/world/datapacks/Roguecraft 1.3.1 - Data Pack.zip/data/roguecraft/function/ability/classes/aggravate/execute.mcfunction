particle minecraft:trial_omen ~ ~ ~ 1 1 1 0 15
execute as @e[distance=..32,type=!minecraft:item,type=!minecraft:player,type=!minecraft:end_crystal,tag=!tamed] run damage @s 1 minecraft:generic_kill by @p
title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.use_ability","italic":true,"color":"gray","with":[{"translate":"roguecraft.class_ability.aggravate"}]}
playsound minecraft:item.trident.thunder master @a ~ ~ ~ 2 1.1