# +40% attack damage, +2 mana regeneration, +25% movement speed, +5 armor toughness, +50% block breaking speed, +25% entity interaction range, +15% attack speed, +25% step height, +10% jump height, +20% safe fall distance
attribute @s minecraft:attack_damage modifier add roguecraft:final_adrenaline 1.4 add_multiplied_total
attribute @s minecraft:movement_speed modifier add roguecraft:final_adrenaline 1.25 add_multiplied_total
attribute @s minecraft:armor_toughness modifier add roguecraft:final_adrenaline 1.05 add_multiplied_total
attribute @s minecraft:block_break_speed modifier add roguecraft:final_adrenaline 1.5 add_multiplied_total
attribute @s minecraft:entity_interaction_range modifier add roguecraft:final_adrenaline 1.25 add_multiplied_total
attribute @s minecraft:attack_speed modifier add roguecraft:final_adrenaline 1.15 add_multiplied_total
attribute @s minecraft:step_height modifier add roguecraft:final_adrenaline 1.25 add_multiplied_total
attribute @s minecraft:jump_strength modifier add roguecraft:final_adrenaline 1.05 add_multiplied_total
attribute @s minecraft:safe_fall_distance modifier add roguecraft:final_adrenaline 1.2 add_multiplied_total