#set strength
function roguecraft:ability/magic_strength/multiply {multiplier:0.5}
function roguecraft:ability/magic_strength/round
function roguecraft:ability/magic_strength/cap {cap:4}

#heal
function roguecraft:ability/heal/heal with storage roguecraft:master magic_strength

effect give @s[type=#minecraft:undead] minecraft:instant_damage
effect give @s[type=!#minecraft:undead] minecraft:instant_health

#presentation
particle minecraft:heart ~ ~1 ~ 0.5 0.5 0.5 1 10 normal @a
playsound minecraft:block.enchantment_table.use master @a ~ ~ ~ 2 1.5