execute if data entity @s Inventory[{Slot:-106b,components:{"minecraft:custom_data":{scroll:true}}}] run return run function roguecraft:ability/copy/copy with entity @s Inventory[{Slot:-106b}].components."minecraft:custom_data"

execute if score @s ability_copied matches 0..99 run return run function roguecraft:ability/copy/get_values_regular
#execute if score @s ability_copied matches 100.. run return run function roguecraft:ability/copy/get_values_class

title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.ability_no_copy","italic":true,"color":"red"}
playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5