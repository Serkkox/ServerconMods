execute at @p[gamemode=spectator] run particle minecraft:heart ~ ~1 ~ 0.5 0.5 0.5 1 10 normal @a
execute at @s run particle minecraft:heart ~ ~1 ~ 0.5 0.5 0.5 1 10 normal @a
execute at @s run playsound minecraft:item.trident.thunder master @s ~ ~ ~ 0.7 1.1
execute as @p[gamemode=spectator] at @s run playsound minecraft:item.trident.thunder master @s ~ ~ ~ 0.7 1.1
execute at @s run tp @p[gamemode=spectator] @s

title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.use_ability","italic":true,"color":"red","with":[{"translate":"roguecraft.class_ability.revitalize"}]}
tellraw @a[tag=!hub,tag=!garden] {"translate":"roguecraft.chat_messages.revive","color":"green","with":[{"selector":"@p[gamemode=spectator]"}]}

execute if score @p[gamemode=spectator] entry_x matches 40000000 run scoreboard players operation @p[gamemode=spectator] entry_x = @s entry_x
execute if score @p[gamemode=spectator] entry_z matches 40000000 run scoreboard players operation @p[gamemode=spectator] entry_z = @s entry_z
execute as @p[gamemode=spectator] run function roguecraft:ability/classes/revive_init

execute store result score #roguecraft_master temp_health run attribute @s minecraft:max_health base get
scoreboard players operation #roguecraft_master temp_health -= #roguecraft_master revitalize_health
execute store result storage roguecraft:master temp_health int 1 run scoreboard players get #roguecraft_master temp_health
function roguecraft:ability/classes/remove_health with storage roguecraft:master

execute store result score @s current_health run attribute @s minecraft:max_health base get