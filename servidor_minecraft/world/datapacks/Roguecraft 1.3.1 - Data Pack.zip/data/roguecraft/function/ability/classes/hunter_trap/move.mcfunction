execute at @s if predicate roguecraft:in_void run function roguecraft:ability/classes/hunter_trap/kill with entity @s data

$tp @s @e[type=minecraft:armor_stand,tag=hunter_trap,tag=$(type)_trap,nbt={UUID:$(armor_stand)},limit=1]
$execute at @s run tp @e[type=minecraft:item_display,tag=hunter_trap,tag=$(type)_trap,nbt={UUID:$(claw_1)},limit=1,distance=..5] ~ ~ ~
$execute at @s run tp @e[type=minecraft:item_display,tag=hunter_trap,tag=$(type)_trap,nbt={UUID:$(claw_2)},limit=1,distance=..5] ~ ~ ~
$execute at @s run tp @e[type=minecraft:item_display,tag=hunter_trap,tag=$(type)_trap,nbt={UUID:$(icon)},limit=1,distance=..5] ~ ~ ~
$execute at @s run tp @e[type=minecraft:item_display,tag=hunter_trap,tag=$(type)_trap,nbt={UUID:$(base)},limit=1,distance=..5] ~ ~ ~