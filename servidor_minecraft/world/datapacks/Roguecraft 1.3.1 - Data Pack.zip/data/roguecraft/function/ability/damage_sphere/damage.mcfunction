#deal damage by damage multiplied by magic strength
$damage @s $(result) roguecraft:damage_sphere by @n[distance=..20,tag=current_main] from @n[distance=..20,tag=current_main]