particle minecraft:flame ~ ~1 ~ 0.5 0.5 0.5 0.3 30
particle minecraft:soul_fire_flame ~ ~1 ~ 0.5 0.5 0.5 0.4 30
scoreboard players set @s adrenaline_advancement_timer 60
playsound minecraft:entity.zombie_villager.cure master @s ~ ~ ~ 0.2 2
playsound minecraft:block.glass.break master @a ~ ~ ~ 0.5 1

execute store result score @s current_health run attribute @s minecraft:max_health base get
execute store result score #roguecraft_master temp_health run attribute @s minecraft:max_health base get
scoreboard players operation #roguecraft_master temp_health -= #roguecraft_master adrenaline_health
execute store result storage roguecraft:master temp_health int 1 run scoreboard players get #roguecraft_master temp_health
function roguecraft:ability/classes/remove_health with storage roguecraft:master
execute store result score @s current_health run attribute @s minecraft:max_health base get

data modify storage roguecraft:master temp_score_level set value 0
scoreboard players set #roguecraft_master temp_health 0
function roguecraft:ability/classes/adrenaline/set_strength with storage roguecraft:master

scoreboard players add #roguecraft_master temp_health 1
title @s[scores={toggle_ability_feedback=0}] actionbar ["",{"translate":"roguecraft.chat_messages.use_ability","italic":true,"color":"white","with":[{"translate":"roguecraft.class_ability.adrenaline"}]},{"text":" (","color":"white","italic":true},{"translate":"roguecraft.generic.strength","italic":true,"color":"white"},{"text":" "},{"score":{"name":"#roguecraft_master","objective":"temp_health"},"color":"white"},{"text":")","italic":true,"color":"white"}]
execute store result score @s current_strength run scoreboard players get #roguecraft_master temp_health