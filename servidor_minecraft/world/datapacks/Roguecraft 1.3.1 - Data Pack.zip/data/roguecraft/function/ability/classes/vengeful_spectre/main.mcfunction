execute unless score @s class matches 4 run scoreboard players set @s soul_charge 5
execute if score @s soul_charge matches 1.. if entity @n[distance=1.5..16,type=!#roguecraft:reaper_excluded,tag=!tamed] run function roguecraft:ability/classes/vengeful_spectre/summon_spectre

execute unless score @s soul_charge matches 1.. as @s run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.ability_no_soul_charge","italic":true,"color":"red"}
execute unless score @s soul_charge matches 1.. as @s run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5
execute unless score @s soul_charge matches 1.. as @s run data modify storage roguecraft:master class_ability_success set value 0b

execute if score @s soul_charge matches 1.. unless entity @n[distance=..16,type=!#roguecraft:reaper_excluded,tag=!tamed] as @s run title @s[scores={toggle_ability_feedback=0}] actionbar {"translate":"roguecraft.chat_messages.ability_no_entity_nearby","italic":true,"color":"red"}
execute if score @s soul_charge matches 1.. unless entity @n[distance=..16,type=!#roguecraft:reaper_excluded,tag=!tamed] as @s run playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5
execute if score @s soul_charge matches 1.. unless entity @n[distance=..16,type=!#roguecraft:reaper_excluded,tag=!tamed] as @s run data modify storage roguecraft:master class_ability_success set value 0b

execute if score @s soul_charge matches 1.. if entity @n[distance=..16,type=!#roguecraft:reaper_excluded,tag=!tamed] run scoreboard players set @s soul_charge 0

execute if score @s class matches 4 run function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/set_mana_bar"}