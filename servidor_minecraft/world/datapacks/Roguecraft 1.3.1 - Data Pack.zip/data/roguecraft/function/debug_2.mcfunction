
#execute if loaded 900000 ~ 9900002 run tell @a "test"
#forceload remove 900000 9900002

fill ~ ~ ~ ~ ~ ~5 air
tp @s ~ ~1 ~