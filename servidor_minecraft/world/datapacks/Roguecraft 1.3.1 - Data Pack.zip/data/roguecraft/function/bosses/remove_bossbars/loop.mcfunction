#set to storage
execute store result storage roguecraft:master boss_id int 1 run scoreboard players get #roguecraft_master boss_id

#remove bossbar
$bossbar remove roguecraft:boss_$(boss_id)

#check if bossbars are exhausted, if so, end loop
execute if score #roguecraft_master boss_id matches 0 run return 0
scoreboard players remove #roguecraft_master boss_id 1

#loop
function roguecraft:bosses/remove_bossbars/loop with storage roguecraft:master