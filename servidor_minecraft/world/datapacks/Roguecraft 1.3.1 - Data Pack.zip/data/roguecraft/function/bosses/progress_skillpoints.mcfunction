$scoreboard players add @s skillpoints $(skillpoints)
$tellraw @s {"translate":"roguecraft.skillpoint.main","bold":true,"italic":false,"color":"aqua","with":[{"translate":"roguecraft.skillpoint.boss_phase"},"$(skillpoints)",{"score":{"name":"@s","objective":"skillpoints"}}]}
#$tellraw @s {"translate":"$(string)","bold":true,"italic":true,"color":"aqua","with":["$(skillpoints)",{"score":{"name":"@s","objective":"skillpoints"}}]}

execute at @s run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1 1.25