#set base
$scoreboard players set @s $(score)_health $(base)
$scoreboard players operation @s $(score)_health *= @s boss_health_scaling
$scoreboard players operation @s $(score)_health /= 10 int

#add per player
$scoreboard players set @s $(score)_health_per_player 50
$scoreboard players operation @s $(score)_health_per_player *= @s boss_health_scaling
$scoreboard players operation @s $(score)_health_per_player /= 10 int

#actually add per player
$execute at $(players) run scoreboard players operation @s $(score)_health += @s $(score)_health_per_player

#cap at 1024 bc minecraft is stupid. jeb, you absolute baffoon, i will become back my money. i know that you personally added this to make my life harder. i can already hear it in my head "you know that monocode guy? he's gonna make a data pack in like 5 years, let's completely fuck him over". well, jokes on you, i can just cap the damage... anyways, can you tell that i'm writing this at like 2am?
$execute if score @s $(score)_health matches 1025.. run scoreboard players set @s $(score)_health 1024

#calculate_half_health
$execute if score 1 int matches $(half_health) run scoreboard players operation @s $(score)_half_health = @s $(score)_health
$execute if score 1 int matches $(half_health) run scoreboard players operation @s $(score)_half_health /= 2 int

#calculate_quarter_health
$execute if score 1 int matches $(quarter_health) run scoreboard players operation @s $(score)_quarter_0_health = @s $(score)_health
$execute if score 1 int matches $(quarter_health) run scoreboard players operation @s $(score)_quarter_0_health /= 4 int

$execute if score 1 int matches $(quarter_health) run scoreboard players operation @s $(score)_quarter_1_health = @s $(score)_quarter_0_health
$execute if score 1 int matches $(quarter_health) run scoreboard players operation @s $(score)_quarter_1_health *= 2 int

$execute if score 1 int matches $(quarter_health) run scoreboard players operation @s $(score)_quarter_2_health = @s $(score)_quarter_0_health
$execute if score 1 int matches $(quarter_health) run scoreboard players operation @s $(score)_quarter_2_health *= 3 int