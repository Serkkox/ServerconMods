$execute store result score @s random run random value 0..$(roll_max)
$execute if score @s random matches 0 run function roguecraft:$(boss_name)/attacks/select