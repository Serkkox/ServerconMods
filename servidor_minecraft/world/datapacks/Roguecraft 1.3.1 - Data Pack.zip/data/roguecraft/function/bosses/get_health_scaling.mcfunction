#get boss kill count
scoreboard players set @s count 0
execute if data storage roguecraft:master {bosses_defeated:{corpus:1b}} run scoreboard players add @s count 1
#execute if data storage roguecraft:master {bosses_defeated:{sol:1b}} run scoreboard players add @s count 1
execute if data storage roguecraft:master {bosses_defeated:{custos:1b}} run scoreboard players add @s count 1
#execute if data storage roguecraft:master {bosses_defeated:{aqua:1b}} run scoreboard players add @s count 1
execute if data storage roguecraft:master {bosses_defeated:{tyrannus:1b}} run scoreboard players add @s count 1
#execute if data storage roguecraft:master {bosses_defeated:{anima:1b}} run scoreboard players add @s count 1
#execute if data storage roguecraft:master {bosses_defeated:{fatum:1b}} run scoreboard players add @s count 1

$execute if score @s count matches 0 run return run execute store result score @s boss_health_scaling run data get storage roguecraft:master boss_health_scaling.$(boss)[0] 10
$execute if score @s count matches 1 run return run execute store result score @s boss_health_scaling run data get storage roguecraft:master boss_health_scaling.$(boss)[1] 10
$execute if score @s count matches 2 run return run execute store result score @s boss_health_scaling run data get storage roguecraft:master boss_health_scaling.$(boss)[2] 10
$execute if score @s count matches 3 run return run execute store result score @s boss_health_scaling run data get storage roguecraft:master boss_health_scaling.$(boss)[3] 10
$execute if score @s count matches 3 run return run execute store result score @s boss_health_scaling run data get storage roguecraft:master boss_health_scaling.$(boss)[4] 10
$execute if score @s count matches 3 run return run execute store result score @s boss_health_scaling run data get storage roguecraft:master boss_health_scaling.$(boss)[5] 10
$execute if score @s count matches 3 run return run execute store result score @s boss_health_scaling run data get storage roguecraft:master boss_health_scaling.$(boss)[6] 10
$execute if score @s count matches 3 run return run execute store result score @s boss_health_scaling run data get storage roguecraft:master boss_health_scaling.$(boss)[7] 10