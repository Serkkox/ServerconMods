#execute unless score #roguecraft_master beam_amount > #roguecraft_master beam_max run function roguecraft:infinite_garden/prepare_marker_1
function roguecraft:infinite_garden/prepare_beam_1

execute if entity @s[tag=hub,tag=init_player] run advancement grant @s only roguecraft:infinite_garden/infinite_garden_void
execute if entity @s[tag=garden,tag=init_player] run advancement grant @s only roguecraft:infinite_garden/infinite_garden_void

scoreboard players set @s phantasms 0
scoreboard players set @s ability_copied -1
effect clear @s
attribute @s minecraft:armor base set 0
attribute @s minecraft:max_health base set 20
attribute @s minecraft:movement_speed base set 0.1
attribute @s minecraft:attack_damage base set 1
attribute @s minecraft:attack_speed base set 4
attribute @s minecraft:block_interaction_range base set 4.5
attribute @s minecraft:entity_interaction_range base set 3
attribute @s minecraft:step_height base set 0.6
function roguecraft:ability/classes/final_adrenaline/remove_modifiers

execute in roguecraft:infinite_garden run tp @s[tag=init_player] 0 63 0 90 0
execute in roguecraft:infinite_garden run tp @s[tag=!init_player] 0 5000 0 90 0

gamemode adventure @s
scoreboard players set @s true_gamemode 2

effect give @s minecraft:resistance infinite 4 true
effect give @s minecraft:speed infinite 7 true
effect give @s minecraft:saturation infinite 0 true

title @s subtitle ""
$execute unless score @s run_number < #roguecraft_master run_number run title @s[tag=!garden,tag=!hub] title $(message)
$execute unless score @s run_number < #roguecraft_master run_number in roguecraft:infinite_garden run playsound $(sound)

tag @s add hub
team join not_ready @s
tag @s remove victory
tag @s remove raid_start
scoreboard players set @s deaths 0

function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/set_mana_bar"}
execute as @s run function roguecraft:infinite_garden/hub/set_inventory

advancement grant @s only roguecraft:challenges/root

xp set @s 0 levels
xp set @s 0 points
scoreboard players set @s level_current 0
scoreboard players set @s level_max 0

scoreboard players set @s dirt_timer 0
scoreboard players set @s liquid_timer 0

scoreboard players reset @s return_to_hub
scoreboard players reset @s stronghold_location
scoreboard players reset @s restart_run

function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/dirt_walker/disable_bossbar"}
function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/liquid_walker/disable_bossbar"}
function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/classes/final_adrenaline/disable_bossbar"}