#executed as master marker

execute if score #roguecraft_master region_dir matches 1 run scoreboard players add #roguecraft_master region_counter_max 1
execute if score #roguecraft_master region_dir matches 3 run scoreboard players add #roguecraft_master region_counter_max 1
scoreboard players operation #roguecraft_master region_counter = #roguecraft_master region_counter_max

scoreboard players add #roguecraft_master region_dir 1
execute if score #roguecraft_master region_dir matches 4.. run scoreboard players set #roguecraft_master region_dir 0