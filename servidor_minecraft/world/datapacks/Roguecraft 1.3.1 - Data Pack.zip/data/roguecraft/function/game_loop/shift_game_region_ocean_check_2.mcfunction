$forceload add $(X) $(Z)
$execute unless loaded $(X) ~ $(Z) run return run schedule function roguecraft:game_loop/shift_game_region_ocean_check_1 1s

$execute if biome $(X) ~ $(Z) #minecraft:is_ocean run return run function roguecraft:game_loop/shift_game_region
function roguecraft:game_loop/remove_shift_game_region_forceload with storage roguecraft:master Region.temp