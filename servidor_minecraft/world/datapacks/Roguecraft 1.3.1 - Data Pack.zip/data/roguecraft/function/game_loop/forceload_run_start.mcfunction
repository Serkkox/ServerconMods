$execute in minecraft:overworld run setworldspawn $(X) ~ $(Z)
$execute in minecraft:overworld run forceload add $(X) $(Z)