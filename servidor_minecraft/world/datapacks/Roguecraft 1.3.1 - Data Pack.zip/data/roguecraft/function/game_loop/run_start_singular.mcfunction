function roguecraft:game_loop/tp_to_run_spawn with storage roguecraft:master Region
#execute if data storage roguecraft:master {success:0b} run return 0

execute if data storage roguecraft:master {sp_loss:1} run scoreboard players set @s skillpoints 0

scoreboard players set @s smelt_iron 0
scoreboard players set @s lava_bucket 0
scoreboard players set @s obsidian 0
scoreboard players set @s enter_nether 0
scoreboard players set @s find_fortress 0
scoreboard players set @s obtain_blaze_rod 0
scoreboard players set @s enter_end 0
scoreboard players set @s wildfire_defeated 0

scoreboard players set @s ability_copied -1

scoreboard players set @s final_adrenaline_timer_max 300
scoreboard players set @s final_adrenaline_timer -300

execute store result score @s run_number run scoreboard players get #roguecraft_master run_number

scoreboard players set @s entry_x 40000000
scoreboard players set @s entry_z 40000000

gamemode survival @s
scoreboard players set @s true_gamemode 0

#advancement revoke @s only minecraft:story/smelt_iron
#advancement revoke @s only minecraft:story/lava_bucket
#advancement revoke @s only minecraft:story/form_obsidian
#advancement revoke @s only minecraft:story/enter_the_nether
#advancement revoke @s only minecraft:nether/find_fortress
#advancement revoke @s only minecraft:nether/obtain_blaze_rod
#advancement revoke @s only minecraft:story/enter_the_end

advancement grant @a only roguecraft:progression/root

recipe give @s roguecraft:skillpoint_1
recipe give @s roguecraft:skillpoint_2
recipe give @s roguecraft:skillpoint_3
recipe give @s roguecraft:skillpoint_mob_1
recipe give @s roguecraft:skillpoint_mob_2
recipe give @s roguecraft:skillpoint_mob_3
recipe give @s minecraft:blast_furnace
recipe give @s minecraft:shield

xp set @s 0 levels
xp set @s 0 points
tag @s remove hub
tag @s remove garden
tag @s remove victory
tag @s remove infinite_garden
tag @s remove garden_items
tag @s remove run_start_non_ticked

data modify storage roguecraft:master start set value 0
tag @s remove ready
tag @s remove end
team leave @s[team=ready]
team leave @s[team=not_ready]
function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/set_mana_bar"}
function roguecraft:upgrades/select_compass_route
execute at @s run spawnpoint @s ~ ~ ~
advancement revoke @s only roguecraft:triggers/use_compass

execute if entity @s[tag=join] run title @s subtitle ""
execute if entity @s[tag=join] run title @s title {"translate":"roguecraft.bossbar.run","with":[{"score":{"name":"#roguecraft_master","objective":"run_number"},"bold":true,"color":"green"}],"bold":true,"color":"green"}

execute at @s run playsound minecraft:block.beacon.power_select master @s ~ ~ ~ 1 2

bossbar set minecraft:difficulty players @a[tag=!hub,tag=!garden]

tag @s remove restart
tag @s remove current_main
tag @s remove restart_all
tag @s remove hub
tag @s remove garden
tag @s remove join
tag @s remove ready_final

scoreboard players enable @a stronghold_location
scoreboard players enable @a toggle_ability_feedback
scoreboard players enable @a restart_run
scoreboard players reset @a hub_tp

clear @s
effect clear @s

function roguecraft:upgrades/init