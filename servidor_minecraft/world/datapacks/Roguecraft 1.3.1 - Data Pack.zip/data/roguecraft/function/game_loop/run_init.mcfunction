data modify storage roguecraft:master start set value 0
data remove storage roguecraft:master stronghold
data modify storage roguecraft:master stronghold_spawned set value 0b
data modify storage roguecraft:master stronghold_generated set value 0b
data modify storage roguecraft:master end set value 0
data modify storage roguecraft:master end_generation_list set value ["c3","c2","d3","c4","b3","b2","d2","d4","b4","d1","c1","b1","a2","a3","a4","b5","c5","d5","e4","e3","e2","e1","a1","a5","e1"]
data modify storage roguecraft:master run_active set value 1
data modify storage roguecraft:master end_cleared set value 0
data modify storage roguecraft:master bedrock_platform_left set value 0
data modify storage roguecraft:master lil_guy_spawned set value 0b
data modify storage roguecraft:master previous_blue_moon set value 0b
data modify storage roguecraft:master sleep set value 0b
scoreboard players set #roguecraft_master blaze_rods 0

execute in minecraft:overworld run forceload remove all
execute in minecraft:overworld run forceload add 1 1 -1 -1

$execute in minecraft:overworld positioned $(X) 320 $(Z) positioned over motion_blocking_no_leaves summon minecraft:marker run function roguecraft:game_loop/start_platform

time set 48000
weather clear
title @a[tag=ready_final] subtitle {"translate":"roguecraft.bossbar.wait"}
title @a[tag=ready_final] title {"translate":"roguecraft.bossbar.run","with":[{"score":{"name":"#roguecraft_master","objective":"run_number"}}],"bold":true,"color":"green"}

#set encountered bosses
data modify storage roguecraft:master bosses_encountered.corpus set value 0b
data modify storage roguecraft:master bosses_encountered.custos set value 0b
data modify storage roguecraft:master bosses_encountered.tyrannus set value 0b

function roguecraft:misc/set_gamerule {gamerule:"playersSleepingPercentage",value:"1"}
function roguecraft:misc/set_gamerule {gamerule:"doDaylightCycle",value:"true"}

function roguecraft:game_loop/shift_game_region
execute in minecraft:the_nether run forceload add 0 0 -1 -1

bossbar set minecraft:difficulty players @a[tag=ready_final]
bossbar set minecraft:difficulty name {"translate":"roguecraft.bossbar.difficulty_level","with":["1"]}
scoreboard players set #roguecraft_master difficulty 0
scoreboard players set #roguecraft_master difficulty_level 1
scoreboard players set #roguecraft_master single_run_timer 0
execute if data storage roguecraft:master {single_run_display:1b} run scoreboard players set single_run_timer speedrun_timer 0

execute as @a[tag=hub,tag=!garden] run function roguecraft:infinite_garden/hub/set_inventory

tag @a remove ready_final