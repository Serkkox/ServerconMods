tp @s ~ ~1 ~
execute at @s run function roguecraft:game_loop/start_platform