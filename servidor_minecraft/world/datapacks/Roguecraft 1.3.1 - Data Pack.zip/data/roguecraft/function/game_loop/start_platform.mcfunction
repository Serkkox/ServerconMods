execute positioned ~ -64 ~ if entity @s[distance=..0.1] run return run function roguecraft:game_loop/start_platform_void

#start platform
summon minecraft:item_display ~ ~0.5 ~ {view_range: 10.0f, brightness: {block: 15, sky: 15}, item: {components: {"minecraft:custom_model_data": 600, "minecraft:custom_name": '{"color":"yellow","italic":false,"text":"item/start_platform"}'}, count: 1, id: "minecraft:totem_of_undying"}, transformation: {left_rotation: [0.0f, 0.0f, 0.0f, 1.0f], right_rotation: [0.0f, 0.0f, 0.0f, 1.0f], scale: [1.0f, 1.0f, 1.0f], translation: [0.0f, 0.0f, 0.0f]}}
fill ~-1 ~-1 ~-1 ~1 ~-1 ~1 minecraft:barrier
fill ~-1 ~ ~-1 ~1 ~1 ~1 minecraft:air
setworldspawn ~ ~ ~
summon minecraft:interaction ~ ~-0.5 ~ {width:4,height:3,Tags:["bedrock_blocker"]}

tp @a[tag=ready_final] ~ ~ ~
tp @a[tag=!hub,tag=!garden] ~ ~ ~
#playsound minecraft:block.beacon.power_select master @a[tag=ready_final] ~ ~ ~ 1 2