scoreboard players remove #roguecraft_master region_counter 1
execute if score #roguecraft_master region_counter matches ..0 run function roguecraft:game_loop/change_region_dir

execute if score #roguecraft_master region_dir matches 0 run scoreboard players remove #roguecraft_master region_x 100000
execute if score #roguecraft_master region_dir matches 1 run scoreboard players remove #roguecraft_master region_z 100000
execute if score #roguecraft_master region_dir matches 2 run scoreboard players add #roguecraft_master region_x 100000
execute if score #roguecraft_master region_dir matches 3 run scoreboard players add #roguecraft_master region_z 100000

function roguecraft:game_loop/remove_shift_game_region_forceload with storage roguecraft:master temp

execute store result storage roguecraft:master Region.temp.X int 1 run scoreboard players get #roguecraft_master region_x
execute store result storage roguecraft:master Region.temp.Z int 1 run scoreboard players get #roguecraft_master region_z

schedule function roguecraft:game_loop/shift_game_region_ocean_check_1 1s