tag @a[tag=hub,tag=!garden] add ready_final
execute store result storage roguecraft:master Region.X int 1 run scoreboard players get #roguecraft_master region_x
execute store result storage roguecraft:master Region.Z int 1 run scoreboard players get #roguecraft_master region_z
scoreboard players add #roguecraft_master run_number 1

function roguecraft:game_loop/forceload_run_start with storage roguecraft:master Region

data modify storage roguecraft:master start set value 1
data modify storage roguecraft:master bosses_checked set value 0b
scoreboard players set #roguecraft_master difficulty_val_max 450

execute as @a[tag=!garden] run function roguecraft:infinite_garden/hub/set_inventory

schedule clear roguecraft:second
schedule clear roguecraft:half_second
schedule clear roguecraft:three_second
schedule clear roguecraft:shops/switch_shop_text
schedule clear roguecraft:quarter_hour
function roguecraft:second
function roguecraft:half_second
function roguecraft:three_second
function roguecraft:shops/switch_shop_text
schedule function roguecraft:quarter_hour 900s

#reset boss deaths
data modify storage roguecraft:master mid_run_bosses_defeated.corpus set value 0b
data modify storage roguecraft:master mid_run_bosses_defeated.tyrannus set value 0b

#tick unlocks
execute in roguecraft:infinite_garden positioned 0 63 0 as @e[type=minecraft:marker,tag=unlock,distance=..128] at @s run function roguecraft:infinite_garden/hub/tick_unlock

function roguecraft:game_loop/forceload_init with storage roguecraft:master Region
function roguecraft:misc/mob_essence_cap/set

schedule function roguecraft:countdown/countdown_5 1s append
schedule function roguecraft:countdown/countdown_4 2s append
schedule function roguecraft:countdown/countdown_3 3s append
schedule function roguecraft:countdown/countdown_2 4s append
schedule function roguecraft:countdown/countdown_1 5s append
schedule function roguecraft:game_loop/run_start_2 6s replace

function roguecraft:infinite_garden/hub/seal/waterlog_fix