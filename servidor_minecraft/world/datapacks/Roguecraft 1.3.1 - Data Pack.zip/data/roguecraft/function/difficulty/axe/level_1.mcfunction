data modify entity @s HandItems set value [{},{}]
data modify entity @s ArmorItems set value [{},{},{},{}]