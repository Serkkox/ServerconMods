execute if score #roguecraft_master random_difficulty_max matches 4..5 run function roguecraft:difficulty/explode/level_4
execute if score #roguecraft_master random_difficulty_max matches 6..7 run function roguecraft:difficulty/explode/level_6
execute if score #roguecraft_master random_difficulty_max matches 8.. run function roguecraft:difficulty/explode/level_8