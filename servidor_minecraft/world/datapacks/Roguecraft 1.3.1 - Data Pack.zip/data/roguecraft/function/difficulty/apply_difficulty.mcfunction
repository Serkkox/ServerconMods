tag @s add buffed

scoreboard players operation #roguecraft_master random_difficulty_max = #roguecraft_master difficulty_level
$execute unless score #roguecraft_master difficulty_level matches 1 store result score #roguecraft_master random_difficulty_max run random value 1..$(difficulty)
#$execute store result score #roguecraft_master random_difficulty run random value 1..$(difficulty)
#execute if score #roguecraft_master random_difficulty > #roguecraft_master random_difficulty_max run scoreboard players operation #roguecraft_master random_difficulty_max = #roguecraft_master random_difficulty

execute as @s[type=#roguecraft:difficulty/difficulty_sword] run function roguecraft:difficulty/sword/check_level
execute as @s[type=#roguecraft:difficulty/difficulty_axe] run function roguecraft:difficulty/axe/check_level
execute as @s[type=#roguecraft:difficulty/difficulty_bow] run function roguecraft:difficulty/bow/check_level
execute as @s[type=#roguecraft:difficulty/difficulty_explode] run function roguecraft:difficulty/explode/check_level
execute as @s[type=#roguecraft:difficulty/difficulty_effect] run function roguecraft:difficulty/effect/check_level
execute as @s[type=#roguecraft:difficulty/difficulty_scroll] run function roguecraft:difficulty/scroll/check_level