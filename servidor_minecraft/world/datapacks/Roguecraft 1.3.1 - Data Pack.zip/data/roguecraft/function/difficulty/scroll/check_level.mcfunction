scoreboard players set @s magic_strength 10

#blue moon
execute store result storage roguecraft:master random byte 1 run random value 0..5
execute if data storage roguecraft:master {blue_moon:1b} run function roguecraft:difficulty/scroll/increase_by_random with storage roguecraft:master

execute if score #roguecraft_master random_difficulty_max matches 1 run return 0

item replace entity @s weapon.offhand with minecraft:warped_fungus_on_a_stick
data modify entity @s HandDropChances set value [0.0f,0.0f]
data modify entity @s ArmorDropChances set value [0.000f,0.000f,0.000f,0.000f]

execute store result storage roguecraft:master scroll_rng byte 1 run random value 0..4
execute if score #roguecraft_master random_difficulty_max matches 7.. if data storage roguecraft:master {scroll_rng:0b} run return run function roguecraft:difficulty/scroll/explosion

execute store result score @s random run random value 1..3
execute if score #roguecraft_master random_difficulty_max matches ..7 if score @s random matches 3 run scoreboard players set @s random 2
execute if score #roguecraft_master random_difficulty_max matches ..4 if score @s random matches 2.. run scoreboard players set @s random 1
scoreboard players operation @s ability_spikes = @s random
execute store result entity @s HandItems[1].components."minecraft:custom_data".level byte 1 run scoreboard players get @s random

execute store result storage roguecraft:master scroll_rng byte 1 run random value 0..4
execute if data storage roguecraft:master {scroll_rng:0b} run data modify entity @s HandItems[1].components merge value {"minecraft:custom_data":{type:"heal","scroll":true,"temp_score_ability":1b},"minecraft:max_stack_size":64,"!max_damage":{},"minecraft:custom_model_data":501,"minecraft:custom_name":'{"translate":"roguecraft.item.scroll","italic":false,"color":"aqua","with":[{"translate":"roguecraft.ability.name.ability_heal"}]}'}
execute if data storage roguecraft:master {scroll_rng:1b} run data modify entity @s HandItems[1].components merge value {"minecraft:custom_data":{type:"damage_sphere","scroll":true,"temp_score_ability":3b},"minecraft:max_stack_size":64,"!max_damage":{},"minecraft:custom_model_data":503,"minecraft:custom_name":'{"translate":"roguecraft.item.scroll","italic":false,"color":"aqua","with":[{"translate":"roguecraft.ability.name.ability_damage_sphere"}]}'}
execute if data storage roguecraft:master {scroll_rng:2b} run data modify entity @s HandItems[1].components merge value {"minecraft:custom_data":{type:"shockbolt","scroll":true,"temp_score_ability":12b},"minecraft:max_stack_size":64,"!max_damage":{},"minecraft:custom_model_data":522,"minecraft:custom_name":'{"translate":"roguecraft.item.scroll","italic":false,"color":"aqua","with":[{"translate":"roguecraft.ability.name.ability_shockbolt"}]}'}
execute if data storage roguecraft:master {scroll_rng:3b} run data modify entity @s HandItems[1].components merge value {"minecraft:custom_data":{type:"arrow_wave","scroll":true,"temp_score_ability":4b},"minecraft:max_stack_size":64,"!max_damage":{},"minecraft:custom_model_data":504,"minecraft:custom_name":'{"translate":"roguecraft.item.scroll","italic":false,"color":"aqua","with":[{"translate":"roguecraft.ability.name.ability_arrow_wave"}]}'}
execute if data storage roguecraft:master {scroll_rng:4b} run data modify entity @s HandItems[1].components merge value {"minecraft:custom_data":{type:"spikes","scroll":true,"temp_score_ability":5b},"minecraft:max_stack_size":64,"!max_damage":{},"minecraft:custom_model_data":505,"minecraft:custom_name":'{"translate":"roguecraft.item.scroll","italic":false,"color":"aqua","with":[{"translate":"roguecraft.ability.name.ability_spikes"}]}'}

#turn to book
execute if score #roguecraft_master random_difficulty_max matches 7.. run function roguecraft:difficulty/scroll/book with entity @s HandItems[1].components."minecraft:custom_data"