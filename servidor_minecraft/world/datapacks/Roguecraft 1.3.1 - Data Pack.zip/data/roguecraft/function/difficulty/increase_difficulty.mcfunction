execute in roguecraft:infinite_garden run scoreboard players set #roguecraft_master difficulty 0
execute in roguecraft:infinite_garden run scoreboard players add #roguecraft_master difficulty_level 1
execute in roguecraft:infinite_garden if score #roguecraft_master difficulty_level matches 11.. as @a[tag=!garden,tag=!hub] unless data entity @s {active_effects:[{id:"minecraft:health_boost"}]} run function roguecraft:difficulty/decrease_health_1
execute in roguecraft:infinite_garden if score #roguecraft_master difficulty_level matches 11.. as @a[tag=!garden,tag=!hub] if data entity @s {active_effects:[{id:"minecraft:health_boost"}]} run function roguecraft:difficulty/decrease_health_boost
execute as @a[tag=!garden,tag=!hub] at @s run playsound minecraft:entity.wither.spawn voice @s ~ ~ ~ 0.075 1.25

bossbar set minecraft:difficulty name {"translate":"roguecraft.bossbar.difficulty_level","with":[{"score":{"name":"#roguecraft_master","objective":"difficulty_level"}}]}
bossbar set minecraft:difficulty value 0
tellraw @a[tag=!hub,tag=!garden] {"translate":"roguecraft.chat_messages.difficulty_increase","with":[{"score":{"name":"#roguecraft_master","objective":"difficulty_level"}}],"bold":true,"color":"red"}

execute if score #roguecraft_master difficulty_level matches 20.. run advancement grant @a[advancements={roguecraft:challenges/difficulty_20=false},gamemode=!spectator,tag=!garden,tag=!hub] only roguecraft:challenges/difficulty_20