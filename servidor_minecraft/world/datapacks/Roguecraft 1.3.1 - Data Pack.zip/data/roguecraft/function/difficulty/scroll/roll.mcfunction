execute store result storage roguecraft:master scroll_rng byte 1 run random value 0..2
execute if score @s has_book matches 1 store result storage roguecraft:master scroll_rng byte 1 run random value 0..5
execute if data storage roguecraft:master {scroll_rng:0b} run function roguecraft:difficulty/scroll/check_use