#chance
data modify storage roguecraft:master random set value 0b
execute if score #roguecraft_master random_difficulty_max matches 5..6 store result storage roguecraft:master random byte 1 run random value 0..5
execute if score #roguecraft_master random_difficulty_max matches 7..8 store result storage roguecraft:master random byte 1 run random value 0..3
execute if score #roguecraft_master random_difficulty_max matches 9..10 store result storage roguecraft:master random byte 1 run random value 0..1
execute if score #roguecraft_master random_difficulty_max matches 11.. run data modify storage roguecraft:master random set value 1b

execute unless data storage roguecraft:master {random:1b} run return 0

#set scores
$scoreboard players set @s ability_1 $(temp_score_ability)
$scoreboard players set @s ability_$(type) $(level)

#get cmd
function roguecraft:upgrades/get_ability_cmd/regular {number:1}

#set to book 
item modify entity @s weapon.offhand roguecraft:set_ability_cmd
scoreboard players set @s has_book 1