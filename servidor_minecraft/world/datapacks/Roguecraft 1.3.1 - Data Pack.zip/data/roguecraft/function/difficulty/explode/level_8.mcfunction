execute at @s if dimension minecraft:the_end run return 0

data modify entity @s powered set value 1b
data modify entity @s ExplosionRadius set value 4
data modify entity @s Fuse set value 15s