execute at @s if dimension minecraft:the_end run return 0
data modify entity @s powered set value 1b