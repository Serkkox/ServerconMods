execute store result score @s random run random value 1..3
execute if score #roguecraft_master random_difficulty_max matches ..7 if score @s random matches 3 run scoreboard players set @s random 2
execute if score #roguecraft_master random_difficulty_max matches ..4 if score @s random matches 2.. run scoreboard players set @s random 1
execute store result entity @s HandItems[1].components."minecraft:custom_data".level byte 1 run scoreboard players get @s random

data modify entity @s HandItems[1].components merge value {"minecraft:custom_data":{type:"explosion","scroll":true,"temp_score_ability":0b},"minecraft:max_stack_size":64,"!max_damage":{},"minecraft:custom_model_data":500,"minecraft:custom_name":'{"translate":"roguecraft.item.scroll","italic":false,"color":"aqua","with":[{"translate":"roguecraft.ability.name.ability_explosion"}]}'}

#turn to book
function roguecraft:difficulty/scroll/book with entity @s HandItems[1].components."minecraft:custom_data"