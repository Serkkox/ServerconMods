#execute
$function roguecraft:ability/$(type)/level_$(level)

#replace only if not book
execute unless score @s has_book matches 1 run item replace entity @s weapon.offhand with air