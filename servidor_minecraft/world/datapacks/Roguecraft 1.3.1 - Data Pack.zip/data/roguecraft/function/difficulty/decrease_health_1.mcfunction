execute store result score #roguecraft_master temp_health run attribute @s minecraft:max_health base get

execute at @s[gamemode=!creative] if score #roguecraft_master temp_health matches 3.. run playsound minecraft:entity.generic.hurt player @a ~ ~ ~

execute if score #roguecraft_master temp_health matches 5.. run scoreboard players remove #roguecraft_master temp_health 2
execute if score #roguecraft_master temp_health matches 3.. run scoreboard players remove #roguecraft_master temp_health 2

execute store result storage roguecraft:master temp_score int 1 run scoreboard players get #roguecraft_master temp_health
function roguecraft:difficulty/decrease_health_2 with storage roguecraft:master