data modify entity @n[type=minecraft:marker] data.status set value 1b
data modify storage roguecraft:master bosses_checked set value 0b
data modify storage roguecraft:master bosses_defeated.corpus set value 0b
data modify storage roguecraft:master bosses_defeated.custos set value 0b
data modify storage roguecraft:master bosses_defeated.tyrannus set value 0b
data modify entity @n[type=minecraft:item_display] item.id set value "minecraft:warped_fungus_on_a_stick"