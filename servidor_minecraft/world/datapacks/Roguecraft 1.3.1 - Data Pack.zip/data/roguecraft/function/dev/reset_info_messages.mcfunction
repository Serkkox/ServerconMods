tag @s remove info_classes
tag @s remove info_ability
tag @s remove info_loadout
tag @s remove info_sp_loss
tag @s remove info_skill_gem
tag @s remove info_lodestone_compass
tag @s remove info_use_ability
tag @s remove info_skillpoint

scoreboard players set @s enderchest_used 0