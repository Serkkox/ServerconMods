advancement revoke @s everything
advancement grant @s only roguecraft:roguecraft/root

tag @s remove garden_entered

scoreboard players set @s defense 0
scoreboard players set @s armor_toughness 0
scoreboard players set @s max_health 5
scoreboard players set @s speed 0
scoreboard players set @s knockback_resistance 0
scoreboard players set @s attack_damage 1
scoreboard players set @s water_breathing 0
scoreboard players set @s dolphins_grace 0
scoreboard players set @s fire_resistance 0
scoreboard players set @s haste 0
scoreboard players set @s jump_boost 0
scoreboard players set @s night_vision 0
scoreboard players set @s regeneration 0
scoreboard players set @s resistance 0
scoreboard players set @s armor 0
scoreboard players set @s protection 0
scoreboard players set @s aqua_affinity 0
scoreboard players set @s respiration 0
scoreboard players set @s feather_falling 0
scoreboard players set @s thorns 0
scoreboard players set @s swift_sneak 0
scoreboard players set @s tool 0
scoreboard players set @s efficiency 0
scoreboard players set @s fortune 0
scoreboard players set @s sword 0
scoreboard players set @s sharpness 0
scoreboard players set @s looting 0
scoreboard players set @s sweeping 0
scoreboard players set @s bow 0
scoreboard players set @s arrows 0
scoreboard players set @s power 0
scoreboard players set @s punch 0
scoreboard players set @s flame 0
scoreboard players set @s infinity 0
scoreboard players set @s food 0
scoreboard players set @s golden_apple 0
scoreboard players set @s enchanted_golden_apple 0
scoreboard players set @s flint_and_steel 0
scoreboard players set @s bucket 0
scoreboard players set @s pearls 0
scoreboard players set @s cobblestone 0
scoreboard players set @s wood 0
scoreboard players set @s bed 0
scoreboard players set @s compass 0
scoreboard players set @s mana 100
scoreboard players set @s max_mana 100
scoreboard players set @s magic_strength 8
scoreboard players set @s mana_regen 2
scoreboard players set @s mage_mana_regen 0
scoreboard players set @s soul_charge 0
scoreboard players set @s max_soul_charge 10
scoreboard players set @s soul_charge_calc_temp 0
scoreboard players set @s multishot 0
scoreboard players set @s piercing 0
scoreboard players set @s step_height 6
scoreboard players set @s entity_reach 3
scoreboard players set @s block_reach 45
scoreboard players set @s soul_speed 0
scoreboard players set @s prefered_compass_route -1

scoreboard players set @s dummy_upgrade 0

scoreboard players set @s shops_completed 0

scoreboard players set @s class_tank 0
scoreboard players set @s class_mage 0
scoreboard players set @s class_healer 0
scoreboard players set @s class_glass_cannon 0
scoreboard players set @s class_reaper 0
scoreboard players set @s class_hunter 0

scoreboard players set @s ability_1 -1
scoreboard players set @s ability_2 -1
scoreboard players set @s ability_3 -1
scoreboard players set @s ability_4 -1
scoreboard players set @s class -1

scoreboard players set @s ability_explosion 0
scoreboard players set @s ability_mining 0
scoreboard players set @s ability_heal 0
scoreboard players set @s ability_damage_sphere 0
scoreboard players set @s ability_arrow_wave 0
scoreboard players set @s ability_liquid_walker 0
scoreboard players set @s ability_dirt_walker 0
scoreboard players set @s ability_levitate 0
scoreboard players set @s ability_fireball 0
scoreboard players set @s ability_spikes 0
scoreboard players set @s ability_shockbolt 0
scoreboard players set @s ability_copy 0

scoreboard players set @s dirt_timer 0
scoreboard players set @s liquid_timer 0

function roguecraft:infinite_garden/hub/ender_chest/reset
function roguecraft:infinite_garden/hub/check_inventory