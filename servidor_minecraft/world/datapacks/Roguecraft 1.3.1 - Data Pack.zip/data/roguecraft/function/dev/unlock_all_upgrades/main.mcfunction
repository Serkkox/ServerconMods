execute at @e[tag=shop] run function roguecraft:dev/unlock_all_upgrades/get_upgrade_name

scoreboard players set @s shops_completed 0
execute at @e[tag=shop] run scoreboard players add @s shops_completed 1