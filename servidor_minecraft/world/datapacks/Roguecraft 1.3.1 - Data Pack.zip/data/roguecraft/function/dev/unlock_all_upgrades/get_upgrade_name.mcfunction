data modify storage roguecraft:master dev.upgrade_name set from entity @n[tag=shop] data.upgrade
function roguecraft:dev/unlock_all_upgrades/grant_upgrade with storage roguecraft:master dev