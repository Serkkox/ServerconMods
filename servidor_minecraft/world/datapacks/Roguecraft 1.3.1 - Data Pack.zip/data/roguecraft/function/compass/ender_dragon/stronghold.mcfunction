data modify storage roguecraft:master compass.x set from storage roguecraft:master Region.X
data modify storage roguecraft:master compass.z set from storage roguecraft:master Region.Z
data modify storage roguecraft:master compass.name set value '{"translate":"roguecraft.compass.stronghold"}'
data modify storage roguecraft:master compass.dimension set value "minecraft:overworld"
function roguecraft:compass/set_compass with storage roguecraft:master compass