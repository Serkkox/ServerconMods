#prevent execution for the next few ticks
advancement revoke @s only roguecraft:triggers/use_compass

#check if delay has expired
execute if score @s compass_delay matches 1.. run return 0

#set delay
scoreboard players set @s compass_delay 4

#check hand
execute if items entity @s weapon.offhand minecraft:compass[minecraft:lodestone_tracker,minecraft:food] run data modify storage roguecraft:master compass.slot set value "weapon.offhand"
execute if items entity @s weapon.mainhand minecraft:compass[minecraft:lodestone_tracker,minecraft:food] run data modify storage roguecraft:master compass.slot set value "weapon.mainhand"

#change route
execute if score @s compass_route matches 2 run scoreboard players set @s compass_route 6
execute if score @s compass_route matches 0 run scoreboard players set @s compass_route 2
execute if score @s compass_route matches 6 run scoreboard players set @s compass_route 0

#feedback
playsound minecraft:ui.button.click master @s ~ ~ ~ 2 2

execute if score @s compass_route matches 0 run title @s actionbar {"translate":"roguecraft.chat_messages.change_compass_target","color":"yellow","with":[{"translate":"roguecraft.compass_target.giant","color":"gold","bold":true}]}
execute if score @s compass_route matches 2 run title @s actionbar {"translate":"roguecraft.chat_messages.change_compass_target","color":"yellow","with":[{"translate":"roguecraft.compass_target.wildfire_dragon","color":"gold","bold":true}]}

#change route
function roguecraft:compass/check_route

#execute if score @s compass_route matches 5 run scoreboard players set @s compass_route 6
#execute if score @s compass_route matches 4 run scoreboard players set @s compass_route 5
#execute if score @s compass_route matches 3 run scoreboard players set @s compass_route 4
#execute if score @s compass_route matches 2 run scoreboard players set @s compass_route 3
#execute if score @s compass_route matches 1 run scoreboard players set @s compass_route 2
#execute if score @s compass_route matches 0 run scoreboard players set @s compass_route 1
#execute if score @s compass_route matches 6 run scoreboard players set @s compass_route 0