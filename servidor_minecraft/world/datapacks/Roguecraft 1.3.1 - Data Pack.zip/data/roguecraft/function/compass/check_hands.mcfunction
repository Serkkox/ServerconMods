execute unless data entity @s {SelectedItem:{id:"minecraft:compass"}} unless data entity @s {Inventory:[{id:"minecraft:compass",Slot:-106b}]} run return fail
execute if data entity @s {SelectedItem:{id:"minecraft:compass"}} run data modify storage roguecraft:master compass.slot set value "weapon.mainhand"
execute if data entity @s {Inventory:[{id:"minecraft:compass",Slot:-106b}]} run data modify storage roguecraft:master compass.slot set value "weapon.offhand"
function roguecraft:compass/check_route