execute in minecraft:the_nether run summon minecraft:armor_stand 0 0 0 {Tags:["structure_stand"],Invulnerable:1b,Marker:1b}
execute in minecraft:the_nether run loot replace entity @e[type=minecraft:armor_stand,tag=structure_stand,limit=1] weapon.mainhand fish roguecraft:explorer_map/fortess ~ ~ ~
data modify storage roguecraft:master compass.x set from entity @e[type=minecraft:armor_stand,tag=structure_stand,limit=1] HandItems[0].components."minecraft:map_decorations".+.x
data modify storage roguecraft:master compass.z set from entity @e[type=minecraft:armor_stand,tag=structure_stand,limit=1] HandItems[0].components."minecraft:map_decorations".+.z
kill @e[type=minecraft:armor_stand,tag=structure_stand]

data modify storage roguecraft:master compass.name set value '{"translate":"roguecraft.compass.fortress"}'
data modify storage roguecraft:master compass.dimension set value "minecraft:the_nether"
function roguecraft:compass/set_compass with storage roguecraft:master compass