data modify storage roguecraft:master compass.name set value '{"translate":"roguecraft.compass.nether"}'
function roguecraft:compass/set_compass_no_target with storage roguecraft:master compass