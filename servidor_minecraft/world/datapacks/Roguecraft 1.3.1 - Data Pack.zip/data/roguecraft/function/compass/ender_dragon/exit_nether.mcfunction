execute store result storage roguecraft:master compass.x int 1 run scoreboard players get @s entry_x
execute store result storage roguecraft:master compass.z int 1 run scoreboard players get @s entry_z
data modify storage roguecraft:master compass.name set value '{"translate":"roguecraft.compass.entry"}'
data modify storage roguecraft:master compass.dimension set value "minecraft:the_nether"
function roguecraft:compass/set_compass with storage roguecraft:master compass