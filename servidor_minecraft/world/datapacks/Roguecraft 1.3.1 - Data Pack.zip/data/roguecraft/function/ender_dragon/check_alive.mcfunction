schedule clear roguecraft:ender_dragon/check_alive

#check if dragon has spawned to begin with
execute if score #roguecraft_master.ender_dragon dragon_health matches 1000 run function custom_ender_dragon:summon_dragon
execute if score #roguecraft_master.ender_dragon dragon_health matches 1000 run return run execute at @e[type=minecraft:ender_dragon] run summon minecraft:lightning_bolt

#if dead
schedule function roguecraft:ender_dragon/death 6s append