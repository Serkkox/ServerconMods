schedule clear roguecraft:ender_dragon/death
schedule clear roguecraft:ender_dragon/check_alive

#store death
data modify storage roguecraft:master mid_run_bosses_defeated.tyrannus set value 1b

execute as @a[tag=!garden,tag=!hub,gamemode=spectator] run function custom_ender_dragon:check_spreadplayers {distance:30}

gamemode survival @a[tag=!garden,tag=!hub]
scoreboard players set @a[tag=!garden,tag=!hub] true_gamemode 0

effect give @a[tag=!garden,tag=!hub] minecraft:resistance infinite 4 true
effect give @a[tag=!garden,tag=!hub] minecraft:saturation infinite 0 true

data modify storage roguecraft:master end set value 0b
tag @a[tag=!garden,tag=!hub] add victory
tag @a remove end

function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/set_mana_bar"}

schedule function roguecraft:ender_dragon/spawn_main 3t append