$item replace entity @s $(slot_name) with minecraft:$(material)$(scan_type)[minecraft:unbreakable={},minecraft:custom_data={starter_items:{}}]
$item modify entity @s $(slot_name) roguecraft:enchant_$(scan_type)
$item modify entity @s $(slot_name) roguecraft:set_equipment_custom_data

execute if data storage roguecraft:master {equipment_upgrades:{scan_type:"boots"}} run data modify storage roguecraft:master equipment_upgrades.destination_slot set value "armor.feet"
execute if data storage roguecraft:master {equipment_upgrades:{scan_type:"chestplate"}} run data modify storage roguecraft:master equipment_upgrades.destination_slot set value "armor.chest"
execute if data storage roguecraft:master {equipment_upgrades:{scan_type:"leggings"}} run data modify storage roguecraft:master equipment_upgrades.destination_slot set value "armor.legs"
execute if data storage roguecraft:master {equipment_upgrades:{scan_type:"helmet"}} run data modify storage roguecraft:master equipment_upgrades.destination_slot set value "armor.head"

tag @s remove equipment_upgrade