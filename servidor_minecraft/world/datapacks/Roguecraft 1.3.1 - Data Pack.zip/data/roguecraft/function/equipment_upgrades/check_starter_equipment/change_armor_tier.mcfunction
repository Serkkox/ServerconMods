#$say armor $(slot_name)
#$item replace entity @s $(slot_name) with minecraft:air

$execute if score @s mid_run_$(type)_level matches 1 run item replace entity @s $(slot_name) with minecraft:leather_$(type)
$execute if score @s mid_run_$(type)_level matches 2 run item replace entity @s $(slot_name) with minecraft:golden_$(type)
$execute if score @s mid_run_$(type)_level matches 3 run item replace entity @s $(slot_name) with minecraft:chainmail_$(type)
$execute if score @s mid_run_$(type)_level matches 4 run item replace entity @s $(slot_name) with minecraft:iron_$(type)
$execute if score @s mid_run_$(type)_level matches 5 run item replace entity @s $(slot_name) with minecraft:diamond_$(type)
$execute if score @s mid_run_$(type)_level matches 6 run item replace entity @s $(slot_name) with minecraft:netherite_$(type)

$item modify entity @s $(slot_name) {function: "set_components", components: $(components)}