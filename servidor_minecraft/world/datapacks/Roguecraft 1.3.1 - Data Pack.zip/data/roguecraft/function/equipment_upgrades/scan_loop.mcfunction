#say what you want about my code quality, but this function is clean as fuck; update from a few months later, what even is most of this system. this is awful. fuck you, mono from a few months ago. for that, i curse you to work on this update several months more than anticipated
$data modify storage roguecraft:master current_item set from entity @s Inventory[{Slot:$(scan_index)b,id:"$(scan_item)"}]
$execute if data entity @s Inventory[{Slot:$(scan_index)b,id:"$(scan_item)"}] unless data storage roguecraft:master current_item.components."minecraft:custom_data" run function roguecraft:equipment_upgrades/found/$(scan_type)

execute store result storage roguecraft:master equipment_upgrades.scan_index int 1 run scoreboard players add @s scan_index 1
execute if score @s scan_index matches 36 store result storage roguecraft:master equipment_upgrades.scan_index int 1 run scoreboard players set @s scan_index 100
execute if score @s scan_index matches 104.. store result storage roguecraft:master equipment_upgrades.scan_index int 1 run scoreboard players set @s scan_index -106
execute unless score @s scan_index matches -105..-1 run return run function roguecraft:equipment_upgrades/scan_loop with storage roguecraft:master equipment_upgrades