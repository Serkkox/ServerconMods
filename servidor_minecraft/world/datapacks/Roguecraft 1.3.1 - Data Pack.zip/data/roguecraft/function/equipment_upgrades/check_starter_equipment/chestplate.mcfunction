data modify storage roguecraft:master equipment_upgrades.current_item.type set value "chestplate"

function roguecraft:equipment_upgrades/check_starter_equipment/armor with storage roguecraft:master equipment_upgrades.current_item