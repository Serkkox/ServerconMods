#return
$execute if score @s mid_run_$(scan_type)_level matches $(scan_tier).. run return fail
$execute if score @s mid_run_$(scan_type)_level matches 0 run data modify storage roguecraft:master equipment_upgrades.new_equipment set value 1b

#increase level
$scoreboard players set @s mid_run_$(scan_type)_level $(scan_tier)

#golden weapon
execute if data storage roguecraft:master {equipment_upgrades:{scan_type:"sword"}} as @s[scores={golden_scythe=589000069}] at @s run return run function roguecraft:equipment_upgrades/golden_weapon with storage roguecraft:master equipment_upgrades

#text
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"tool"}} run tellraw @s {"translate":"roguecraft.equipment_upgrades.equipment","color":"green","with":[{"translate":"roguecraft.equipment_upgrades.$(scan_type)"},{"translate":"roguecraft.equipment_upgrades.tool_tier_$(previous_tier)"},{"translate":"roguecraft.equipment_upgrades.tool_tier_$(scan_tier)"}]}
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"armor"}} run tellraw @s {"translate":"roguecraft.equipment_upgrades.equipment","color":"green","with":[{"translate":"roguecraft.equipment_upgrades.$(scan_type)"},{"translate":"roguecraft.equipment_upgrades.armor_tier_$(previous_tier)"},{"translate":"roguecraft.equipment_upgrades.armor_tier_$(scan_tier)"}]}
execute if data storage roguecraft:master {equipment_upgrades:{general_type:"bow"}} run tellraw @s {"translate":"roguecraft.equipment_upgrades.acquire_bow","color":"green"}

function roguecraft:info_messages/tell {type:"mid_run_upgrades"}

scoreboard players set @s mid_run_unapplied_changes 1
$scoreboard players set @s mid_run_unapplied_$(scan_type) 1
data modify storage roguecraft:master equipment_upgrades.change set value 1b
data modify storage roguecraft:master global_equipment_change set value 1b