#$say bow $(slot_name)
#$item replace entity @s $(slot_name) with minecraft:air

$execute if score @s mid_run_$(type)_level matches 1 run item replace entity @s $(slot_name) with minecraft:$(material)bow

$item modify entity @s $(slot_name) {function: "set_components", components: $(components)}