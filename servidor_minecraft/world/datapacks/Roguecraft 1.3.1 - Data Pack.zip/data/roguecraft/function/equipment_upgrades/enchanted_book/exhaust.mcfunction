$execute unless items entity @s container.$(scan_index) run return 0

$item modify entity @s container.$(scan_index) roguecraft:decrease
execute at @s run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 1 1
xp add @s 15