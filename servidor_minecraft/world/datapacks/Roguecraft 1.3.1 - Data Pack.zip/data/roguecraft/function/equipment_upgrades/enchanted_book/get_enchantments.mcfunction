#get enchantments
$data modify storage roguecraft:master equipment_upgrades merge from entity @s Inventory[{Slot:$(scan_index)b}].components."minecraft:stored_enchantments".levels

#apply
#power
execute if data storage roguecraft:master equipment_upgrades."minecraft:power" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "power"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"power"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"power",sword:0,weapon:0,tool:0,bow:1,armor:0,boots:0,leggings:0,helmet:0}
#punch
execute if data storage roguecraft:master equipment_upgrades."minecraft:punch" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "punch"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"punch"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"punch",sword:0,weapon:0,tool:0,bow:1,armor:0,boots:0,leggings:0,helmet:0}
#flame
execute if data storage roguecraft:master equipmen_upgrades."minecraft:flame" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "flame"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"flame"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"flame",sword:0,weapon:0,tool:0,bow:1,armor:0,boots:0,leggings:0,helmet:0}
#infinity
execute if data storage roguecraft:master equipment_upgrades."minecraft:infinity" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "infinity"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"infinity"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"infinity",sword:0,weapon:0,tool:0,bow:1,armor:0,boots:0,leggings:0,helmet:0}
#piercing
execute if data storage roguecraft:master equipment_upgrades."minecraft:piercing" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "piercing"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"piercing"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"piercing",sword:0,weapon:0,tool:0,bow:1,armor:0,boots:0,leggings:0,helmet:0}
#multishot
execute if data storage roguecraft:master equipment_upgrades."minecraft:multishot" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "multishot"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"multishot"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"multishot",sword:0,weapon:0,tool:0,bow:1,armor:0,boots:0,leggings:0,helmet:0}
#protection
execute if data storage roguecraft:master equipment_upgrades."minecraft:protection" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "protection"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"protection"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"protection",sword:0,weapon:0,tool:0,bow:0,armor:1,boots:0,leggings:0,helmet:0}
#fire_protection
execute if data storage roguecraft:master equipment_upgrades."minecraft:fire_protection" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "fire_protection"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"fire_protection"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"fire_protection",sword:0,weapon:0,tool:0,bow:0,armor:1,boots:0,leggings:0,helmet:0}
#blast_protection
execute if data storage roguecraft:master equipment_upgrades."minecraft:blast_protection" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "blast_protection"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"blast_protection"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"blast_protection",sword:0,weapon:0,tool:0,bow:0,armor:1,boots:0,leggings:0,helmet:0}
#projectile_protection
execute if data storage roguecraft:master equipment_upgrades."minecraft:projectile_protection" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "projectile_protection"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"projectile_protection"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"projectile_protection",sword:0,weapon:0,tool:0,bow:0,armor:1,boots:0,leggings:0,helmet:0}
#thorns
execute if data storage roguecraft:master equipment_upgrades."minecraft:thorns" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "thorns"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"thorns"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"thorns",sword:0,weapon:0,tool:0,bow:0,armor:1,boots:0,leggings:0,helmet:0}
#respiration
execute if data storage roguecraft:master equipment_upgrades."minecraft:respiration" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "respiration"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"respiration"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"respiration",sword:0,weapon:0,tool:0,bow:0,armor:0,boots:0,leggings:0,helmet:1}
#aqua_affinity
execute if data storage roguecraft:master equipment_upgrades."minecraft:aqua_affinity" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "aqua_affinity"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"aqua_affinity"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"aqua_affinity",sword:0,weapon:0,tool:0,bow:0,armor:0,boots:0,leggings:0,helmet:1}
#swift_sneak
execute if data storage roguecraft:master equipment_upgrades."minecraft:swift_sneak" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "swift_sneak"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"swift_sneak"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"swift_sneak",sword:0,weapon:0,tool:0,bow:0,armor:0,boots:0,leggings:1,helmet:0}
#feather_falling
execute if data storage roguecraft:master equipment_upgrades."minecraft:feather_falling" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "feather_falling"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"feather_falling"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"feather_falling",sword:0,weapon:0,tool:0,bow:0,armor:0,boots:1,leggings:0,helmet:0}
#soul_speed
execute if data storage roguecraft:master equipment_upgrades."minecraft:soul_speed" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "soul_speed"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"soul_speed"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"soul_speed",sword:0,weapon:0,tool:0,bow:0,armor:0,boots:1,leggings:0,helmet:0}
#depth_strider
execute if data storage roguecraft:master equipment_upgrades."minecraft:depth_strider" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "depth_strider"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"depth_strider"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"depth_strider",sword:0,weapon:0,tool:0,bow:0,armor:0,boots:1,leggings:0,helmet:0}
#efficiency
execute if data storage roguecraft:master equipment_upgrades."minecraft:efficiency" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "efficiency"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"efficiency"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"efficiency",sword:0,weapon:0,tool:1,bow:0,armor:0,boots:0,leggings:0,helmet:0}
#fortune
execute if data storage roguecraft:master equipment_upgrades."minecraft:fortune" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "fortune"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"fortune"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"fortune",sword:0,weapon:0,tool:1,bow:0,armor:0,boots:0,leggings:0,helmet:0}
#sharpness
execute if data storage roguecraft:master equipment_upgrades."minecraft:sharpness" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "sharpness"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"sharpness"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"sharpness",sword:0,weapon:1,tool:0,bow:0,armor:0,boots:0,leggings:0,helmet:0}
#smite
execute if data storage roguecraft:master equipment_upgrades."minecraft:smite" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "smite"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"smite"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"smite",sword:0,weapon:1,tool:0,bow:0,armor:0,boots:0,leggings:0,helmet:0}
#bane_of_arthropods
execute if data storage roguecraft:master equipment_upgrades."minecraft:bane_of_arthropods" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "bane_of_arthropods"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"bane_of_arthropods"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"bane_of_arthropods",sword:0,weapon:1,tool:0,bow:0,armor:0,boots:0,leggings:0,helmet:0}
#fire_aspect
execute if data storage roguecraft:master equipment_upgrades."minecraft:fire_aspect" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "fire_aspect"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"fire_aspect"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"fire_aspect",sword:0,weapon:1,tool:0,bow:0,armor:0,boots:0,leggings:0,helmet:0}
#looting
execute if data storage roguecraft:master equipment_upgrades."minecraft:looting" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "looting"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"looting"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"looting",sword:0,weapon:1,tool:0,bow:0,armor:0,boots:0,leggings:0,helmet:0}
#sweeping_edge
execute if data storage roguecraft:master equipment_upgrades."minecraft:sweeping_edge" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "sweeping_edge"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"sweeping_edge"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"sweeping_edge",sword:1,weapon:0,tool:0,bow:0,armor:0,boots:0,leggings:0,helmet:0}
#knockback
execute if data storage roguecraft:master equipment_upgrades."minecraft:knockback" run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "knockback"
execute if data storage roguecraft:master {equipment_upgrades:{current_enchantment:"knockback"}} run function roguecraft:equipment_upgrades/enchanted_book/get_enchantment_pieces {enchantment:"knockback",sword:0,weapon:1,tool:0,bow:0,armor:0,boots:0,leggings:0,helmet:0}