$execute unless entity @s[nbt={UUID:$(uuid)}] run return fail

execute unless data storage roguecraft:master equipment_upgrades.current_item.components run data modify storage roguecraft:master equipment_upgrades.current_item.components set value {}

$execute if score @s scan_index matches ..35 run data modify storage roguecraft:master equipment_upgrades.current_item.slot_name set value "container.$(Slot)"
execute if score @s scan_index matches -106 run data modify storage roguecraft:master equipment_upgrades.current_item.slot_name set value "weapon.offhand"
execute if score @s scan_index matches 100 run data modify storage roguecraft:master equipment_upgrades.current_item.slot_name set value "armor.feet"
execute if score @s scan_index matches 101 run data modify storage roguecraft:master equipment_upgrades.current_item.slot_name set value "armor.legs"
execute if score @s scan_index matches 102 run data modify storage roguecraft:master equipment_upgrades.current_item.slot_name set value "armor.chest"
execute if score @s scan_index matches 103 run data modify storage roguecraft:master equipment_upgrades.current_item.slot_name set value "armor.head"

execute if score @s mid_run_unapplied_sword matches 1 run function roguecraft:equipment_upgrades/check_starter_equipment/sword with storage roguecraft:master equipment_upgrades.current_item
execute if score @s mid_run_unapplied_pickaxe matches 1 run function roguecraft:equipment_upgrades/check_starter_equipment/pickaxe with storage roguecraft:master equipment_upgrades.current_item
execute if score @s mid_run_unapplied_axe matches 1 run function roguecraft:equipment_upgrades/check_starter_equipment/axe with storage roguecraft:master equipment_upgrades.current_item
execute if score @s mid_run_unapplied_shovel matches 1 run function roguecraft:equipment_upgrades/check_starter_equipment/shovel with storage roguecraft:master equipment_upgrades.current_item
execute if score @s mid_run_unapplied_hoe matches 1 run function roguecraft:equipment_upgrades/check_starter_equipment/hoe with storage roguecraft:master equipment_upgrades.current_item
execute if score @s mid_run_unapplied_bow matches 1 run function roguecraft:equipment_upgrades/check_starter_equipment/bow with storage roguecraft:master equipment_upgrades.current_item
execute if score @s mid_run_unapplied_boots matches 1 run function roguecraft:equipment_upgrades/check_starter_equipment/boots with storage roguecraft:master equipment_upgrades.current_item
execute if score @s mid_run_unapplied_leggings matches 1 run function roguecraft:equipment_upgrades/check_starter_equipment/leggings with storage roguecraft:master equipment_upgrades.current_item
execute if score @s mid_run_unapplied_chestplate matches 1 run function roguecraft:equipment_upgrades/check_starter_equipment/chestplate with storage roguecraft:master equipment_upgrades.current_item
execute if score @s mid_run_unapplied_helmet matches 1 run function roguecraft:equipment_upgrades/check_starter_equipment/helmet with storage roguecraft:master equipment_upgrades.current_item

execute unless score @s mid_run_unapplied_axe matches 1 unless score @s mid_run_unapplied_boots matches 1 unless score @s mid_run_unapplied_bow matches 1 unless score @s mid_run_unapplied_chestplate matches 1 unless score @s mid_run_unapplied_helmet matches 1 unless score @s mid_run_unapplied_hoe matches 1 unless score @s mid_run_unapplied_leggings matches 1 unless score @s mid_run_unapplied_pickaxe matches 1 unless score @s mid_run_unapplied_shovel matches 1 unless score @s mid_run_unapplied_sword matches 1 run scoreboard players set @s mid_run_unapplied_changes 0

#info message for missing item
schedule function roguecraft:info_messages/missing_equipment_upgrade_init 1t