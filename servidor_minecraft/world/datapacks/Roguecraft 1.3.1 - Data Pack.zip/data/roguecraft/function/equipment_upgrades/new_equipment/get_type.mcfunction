data modify storage roguecraft:master equipment_upgrades.change set value 0b
data modify storage roguecraft:master equipment_upgrades.material set value ""

$execute if score @s scan_index matches ..35 run data modify storage roguecraft:master equipment_upgrades.slot_name set value "container.$(scan_index)"
execute if score @s scan_index matches 99 run data modify storage roguecraft:master equipment_upgrades.slot_name set value "weapon.offhand"
execute if score @s scan_index matches 100 run data modify storage roguecraft:master equipment_upgrades.slot_name set value "armor.feet"
execute if score @s scan_index matches 101 run data modify storage roguecraft:master equipment_upgrades.slot_name set value "armor.legs"
execute if score @s scan_index matches 102 run data modify storage roguecraft:master equipment_upgrades.slot_name set value "armor.chest"
execute if score @s scan_index matches 103 run data modify storage roguecraft:master equipment_upgrades.slot_name set value "armor.head"

$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"tool"}} as @s[scores={mid_run_$(scan_type)_level=1}] run data modify storage roguecraft:master equipment_upgrades.material set value wooden_
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"tool"}} as @s[scores={mid_run_$(scan_type)_level=2}] run data modify storage roguecraft:master equipment_upgrades.material set value golden_
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"tool"}} as @s[scores={mid_run_$(scan_type)_level=3}] run data modify storage roguecraft:master equipment_upgrades.material set value stone_
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"tool"}} as @s[scores={mid_run_$(scan_type)_level=4}] run data modify storage roguecraft:master equipment_upgrades.material set value iron_
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"tool"}} as @s[scores={mid_run_$(scan_type)_level=5}] run data modify storage roguecraft:master equipment_upgrades.material set value diamond_
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"tool"}} as @s[scores={mid_run_$(scan_type)_level=6..}] run data modify storage roguecraft:master equipment_upgrades.material set value netherite_

$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"armor"}} as @s[scores={mid_run_$(scan_type)_level=1}] run data modify storage roguecraft:master equipment_upgrades.material set value leather_
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"armor"}} as @s[scores={mid_run_$(scan_type)_level=2}] run data modify storage roguecraft:master equipment_upgrades.material set value golden_
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"armor"}} as @s[scores={mid_run_$(scan_type)_level=3}] run data modify storage roguecraft:master equipment_upgrades.material set value chainmail_
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"armor"}} as @s[scores={mid_run_$(scan_type)_level=4}] run data modify storage roguecraft:master equipment_upgrades.material set value iron_
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"armor"}} as @s[scores={mid_run_$(scan_type)_level=5}] run data modify storage roguecraft:master equipment_upgrades.material set value diamond_
$execute if data storage roguecraft:master {equipment_upgrades:{general_type:"armor"}} as @s[scores={mid_run_$(scan_type)_level=6}] run data modify storage roguecraft:master equipment_upgrades.material set value netherite_

execute if data storage roguecraft:master {equipment_upgrades:{general_type:"bow"}} if score @s class matches 5 run data modify storage roguecraft:master equipment_upgrades.material set value "cross"

execute unless data storage roguecraft:master {equipment_upgrades:{general_type:"armor"}} run function roguecraft:equipment_upgrades/new_equipment/set_item with storage roguecraft:master equipment_upgrades
execute if data storage roguecraft:master {equipment_upgrades:{general_type:"armor"}} run function roguecraft:equipment_upgrades/new_equipment/set_armor with storage roguecraft:master equipment_upgrades