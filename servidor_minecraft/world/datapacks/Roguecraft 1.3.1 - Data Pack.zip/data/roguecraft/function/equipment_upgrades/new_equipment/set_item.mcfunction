$item replace entity @s $(slot_name) with minecraft:$(material)$(scan_type)[minecraft:unbreakable={},minecraft:custom_data={starter_items:{}}]
$item modify entity @s $(slot_name) roguecraft:enchant_$(scan_type)
$item modify entity @s $(slot_name) roguecraft:set_equipment_custom_data

tag @s remove equipment_upgrade