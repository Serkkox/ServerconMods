#sword
data modify storage roguecraft:master equipment_upgrades.current_piece set value "sword"
function roguecraft:equipment_upgrades/enchanted_book/apply/apply with storage roguecraft:master equipment_upgrades

#axe
data modify storage roguecraft:master equipment_upgrades.current_piece set value "axe"
function roguecraft:equipment_upgrades/enchanted_book/apply/apply with storage roguecraft:master equipment_upgrades