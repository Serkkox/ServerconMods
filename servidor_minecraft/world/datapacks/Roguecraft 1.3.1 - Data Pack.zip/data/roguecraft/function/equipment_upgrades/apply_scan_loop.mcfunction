data modify storage roguecraft:master equipment_upgrades.current_item set value {}
data remove storage roguecraft:master equipment_upgrades.new_equipment
$data modify storage roguecraft:master equipment_upgrades.current_item set from entity @s Inventory[{Slot:$(scan_index)b}]

execute if data storage roguecraft:master equipment_upgrades.current_item.components."minecraft:custom_data".starter_items run data modify storage roguecraft:master equipment_upgrades.current_item.uuid set from storage roguecraft:master equipment_upgrades.current_item.components."minecraft:custom_data".uuid
execute if data storage roguecraft:master equipment_upgrades.current_item.components."minecraft:custom_data".starter_items run function roguecraft:equipment_upgrades/check_starter_equipment/main with storage roguecraft:master equipment_upgrades.current_item

execute store result storage roguecraft:master equipment_upgrades.scan_index int 1 run scoreboard players add @s scan_index 1
execute if score @s scan_index matches 36 store result storage roguecraft:master equipment_upgrades.scan_index int 1 run scoreboard players set @s scan_index 100
execute if score @s scan_index matches 104.. store result storage roguecraft:master equipment_upgrades.scan_index int 1 run scoreboard players set @s scan_index -106

execute unless score @s mid_run_unapplied_changes matches 1 run return 1
execute unless score @s scan_index matches -105..-1 run return run function roguecraft:equipment_upgrades/apply_scan_loop with storage roguecraft:master equipment_upgrades