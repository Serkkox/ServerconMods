#tag exists so it only happens on ticks, subticks mess with things
tag @s remove equipment_upgrade

#fallbacks
execute if score #roguecraft_master difficulty matches 0 if score #roguecraft_master difficulty_level matches 1 run return run advancement revoke @s only roguecraft:triggers/equipment_upgrades
execute unless entity @s[tag=!garden,tag=!hub] run return run advancement revoke @s only roguecraft:triggers/equipment_upgrades

#check if there are items without custom data
execute if items entity @s container.* #roguecraft:equipment_upgrades[!minecraft:custom_data] run function roguecraft:equipment_upgrades/get_items

#play sound if equipment changed
execute at @s if data storage roguecraft:master {global_equipment_change:1b} run playsound minecraft:block.anvil.place master @a ~ ~ ~ 0.5 2
data remove storage roguecraft:master global_equipment_change

#apply changes
execute if score @s mid_run_unapplied_changes matches 1 if items entity @s container.* #roguecraft:equipment_upgrades[minecraft:custom_data] run function roguecraft:equipment_upgrades/apply_scan_init

#remove advancement
advancement revoke @s only roguecraft:triggers/equipment_upgrades