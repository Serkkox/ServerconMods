$execute unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:leather_$(type)"}}} unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:golden_$(type)"}}} unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:chainmail_$(type)"}}} unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:iron_$(type)"}}} unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:diamond_$(type)"}}} unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:netherite_$(type)"}}} run return fail

function roguecraft:equipment_upgrades/check_starter_equipment/change_armor_tier with storage roguecraft:master equipment_upgrades.current_item
$item modify entity @s $(slot_name) roguecraft:enchant_$(type)
$item modify entity @s $(slot_name) roguecraft:set_equipment_custom_data

$scoreboard players set @s mid_run_unapplied_$(type) 0
tag @s add update_inventory