#return
$execute if score @s mid_run_$(scan_type)_$(current_enchantment)_level matches $(current_level).. run return fail

#text
$tellraw @s {"translate":"roguecraft.equipment_upgrades.enchantment","color":"green","with":[{"translate":"roguecraft.equipment_upgrades.$(scan_type)"},{"translate":"enchantment.minecraft.$(current_enchantment)"},{"score":{"name":"@s","objective":"mid_run_$(scan_type)_$(current_enchantment)_level"}},"$(current_level)"]}

function roguecraft:info_messages/tell {type:"mid_run_upgrades"}

#advancement
advancement grant @s only minecraft:story/enchant_item

#set score
$scoreboard players set @s mid_run_$(scan_type)_$(current_enchantment)_level $(current_level)

#changes
scoreboard players set @s mid_run_unapplied_changes 1
$scoreboard players set @s mid_run_unapplied_$(scan_type) 1
data modify storage roguecraft:master equipment_upgrades.change set value 1b
data modify storage roguecraft:master global_equipment_change set value 1b