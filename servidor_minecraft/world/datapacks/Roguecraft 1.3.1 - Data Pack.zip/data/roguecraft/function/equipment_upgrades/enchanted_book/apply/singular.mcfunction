#piece
$data modify storage roguecraft:master equipment_upgrades.current_piece set value "$(type)"
function roguecraft:equipment_upgrades/enchanted_book/apply/apply with storage roguecraft:master equipment_upgrades