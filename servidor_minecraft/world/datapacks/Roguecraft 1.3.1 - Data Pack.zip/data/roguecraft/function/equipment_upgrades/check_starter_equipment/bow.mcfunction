data modify storage roguecraft:master equipment_upgrades.current_item.type set value "bow"

function roguecraft:equipment_upgrades/check_starter_equipment/bows with storage roguecraft:master equipment_upgrades.current_item