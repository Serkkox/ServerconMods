#tellraw @a {"storage":"roguecraft:master","nbt":"equipment_upgrades.current_item"}
$execute unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:wooden_$(type)"}}} unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:golden_$(type)"}}} unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:stone_$(type)"}}} unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:iron_$(type)"}}} unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:diamond_$(type)"}}} unless data storage roguecraft:master {equipment_upgrades:{current_item:{id:"minecraft:netherite_$(type)"}}} run return fail

#data modify storage roguecraft:master_copy equipment_upgrades set from storage roguecraft:master equipment_upgrades

function roguecraft:equipment_upgrades/check_starter_equipment/change_tool_tier with storage roguecraft:master equipment_upgrades.current_item
$item modify entity @s $(slot_name) roguecraft:enchant_$(type)
$item modify entity @s $(slot_name) roguecraft:set_equipment_custom_data

$scoreboard players set @s mid_run_unapplied_$(type) 0
tag @s add update_inventory