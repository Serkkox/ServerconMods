#scan_item,scan_type,scan_tier
#{equipment_upgrades:{\
power:0b,\
punch:0b,\
flame:0b,\
infinity:0b,\
piercing:0b,\
multishot:0b,\
protection:0b,\
fire_protection:0b,\
blast_protection:0b,\
projectile_protection:0b,\
thorns:0b,\
respiration:0b,\
aqua_affinity:0b,\
swift_sneak:0b,\
feather_falling:0b,\
soul_speed:0b,\
depth_strider:0b,\
efficiency:1b,\
fortune:1b,\
sharpness:1b,\
smite:1b,\
bane_of_arthropods:1b,\
fire_aspect:1b,\
looting:1b,\
sweeping_edge:0b,\
knockback:1b\
#}}
$data modify storage roguecraft:master equipment_upgrades merge from entity @s Inventory[{Slot:$(scan_index)b}].components."minecraft:enchantments".levels

#tellraw @a {"storage":"roguecraft:master","nbt":"equipment_upgrades"}

#power
execute if data storage roguecraft:master {equipment_upgrades:{power:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "power"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#punch
execute if data storage roguecraft:master {equipment_upgrades:{punch:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "punch"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#flame
execute if data storage roguecraft:master {equipmen_upgrades:{flame:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "flame"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#infinity
execute if data storage roguecraft:master {equipment_upgrades:{infinity:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "infinity"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#piercing
execute if data storage roguecraft:master {equipment_upgrades:{piercing:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "piercing"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#multishot
execute if data storage roguecraft:master {equipment_upgrades:{multishot:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "multishot"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#protection
execute if data storage roguecraft:master {equipment_upgrades:{protection:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "protection"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#fire_protection
execute if data storage roguecraft:master {equipment_upgrades:{fire_protection:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "fire_protection"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#blast_protection
execute if data storage roguecraft:master {equipment_upgrades:{blast_protection:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "blast_protection"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#projectile_protection
execute if data storage roguecraft:master {equipment_upgrades:{projectile_protection:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "projectile_protection"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#thorns
execute if data storage roguecraft:master {equipment_upgrades:{thorns:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "thorns"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#respiration
execute if data storage roguecraft:master {equipment_upgrades:{respiration:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "respiration"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#aqua_affinity
execute if data storage roguecraft:master {equipment_upgrades:{aqua_affinity:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "aqua_affinity"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#swift_sneak
execute if data storage roguecraft:master {equipment_upgrades:{swift_sneak:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "swift_sneak"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#feather_falling
execute if data storage roguecraft:master {equipment_upgrades:{feather_falling:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "feather_falling"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#soul_speed
execute if data storage roguecraft:master {equipment_upgrades:{soul_speed:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "soul_speed"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#depth_strider
execute if data storage roguecraft:master {equipment_upgrades:{depth_strider:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "depth_strider"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#efficiency
execute if data storage roguecraft:master {equipment_upgrades:{efficiency:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "efficiency"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#fortune
execute if data storage roguecraft:master {equipment_upgrades:{fortune:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "fortune"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#sharpness
execute if data storage roguecraft:master {equipment_upgrades:{sharpness:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "sharpness"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#smite
execute if data storage roguecraft:master {equipment_upgrades:{smite:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "smite"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#bane_of_arthropods
execute if data storage roguecraft:master {equipment_upgrades:{bane_of_arthropods:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "bane_of_arthropods"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#fire_aspect
execute if data storage roguecraft:master {equipment_upgrades:{fire_aspect:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "fire_aspect"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#looting
execute if data storage roguecraft:master {equipment_upgrades:{looting:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "looting"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#sweeping_edge
execute if data storage roguecraft:master {equipment_upgrades:{sweeping_edge:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "sweeping_edge"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades
#knockback
execute if data storage roguecraft:master {equipment_upgrades:{knockback:1b}} run data modify storage roguecraft:master equipment_upgrades.current_enchantment set value "knockback"
execute if data storage roguecraft:master equipment_upgrades.current_enchantment run function roguecraft:equipment_upgrades/get_enchantment_level with storage roguecraft:master equipment_upgrades