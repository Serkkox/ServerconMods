execute store result storage roguecraft:master equipment_upgrades.scan_index int 1 run scoreboard players set @s scan_index 0

function roguecraft:equipment_upgrades/apply_scan_loop with storage roguecraft:master equipment_upgrades