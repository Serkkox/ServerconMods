data remove storage roguecraft:master equipment_upgrades

execute store result storage roguecraft:master equipment_upgrades.scan_index int 1 run scoreboard players set @s scan_index 0
$data modify storage roguecraft:master equipment_upgrades.scan_item set value "$(item)"
$data modify storage roguecraft:master equipment_upgrades.scan_type set value "$(type)"
$data modify storage roguecraft:master equipment_upgrades.scan_tier set value $(tier)

function roguecraft:equipment_upgrades/scan_loop with storage roguecraft:master equipment_upgrades