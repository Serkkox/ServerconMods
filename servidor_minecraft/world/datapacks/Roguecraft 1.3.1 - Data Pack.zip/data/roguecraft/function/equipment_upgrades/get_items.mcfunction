#this function is sponsered by visual studio code's ability to select and edit multiple lines at the same time

#bow
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:bow[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:bow",type:"bow",tier:1}

#crossbow
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:crossbow[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:crossbow",type:"bow",tier:1}

#chainmail_boots
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:chainmail_boots[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:chainmail_boots",type:"boots",tier:3}

#chainmail_chestplate
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:chainmail_chestplate[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:chainmail_chestplate",type:"chestplate",tier:3}

#chainmail_helmet
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:chainmail_helmet[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:chainmail_helmet",type:"helmet",tier:3}

#chainmail_leggings
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:chainmail_leggings[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:chainmail_leggings",type:"leggings",tier:3}

#diamond_axe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:diamond_axe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:diamond_axe",type:"axe",tier:5}

#diamond_boots
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:diamond_boots[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:diamond_boots",type:"boots",tier:5}

#diamond_chestplate
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:diamond_chestplate[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:diamond_chestplate",type:"chestplate",tier:5}

#diamond_helmet
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:diamond_helmet[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:diamond_helmet",type:"helmet",tier:5}

#diamond_hoe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:diamond_hoe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:diamond_hoe",type:"hoe",tier:5}

#diamond_leggings
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:diamond_leggings[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:diamond_leggings",type:"leggings",tier:5}

#diamond_pickaxe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:diamond_pickaxe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:diamond_pickaxe",type:"pickaxe",tier:5}

#diamond_shovel
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:diamond_shovel[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:diamond_shovel",type:"shovel",tier:5}

#diamond_sword
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:diamond_sword[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:diamond_sword",type:"sword",tier:5}

#golden_axe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:golden_axe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:golden_axe",type:"axe",tier:2}

#golden_boots
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:golden_boots[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:golden_boots",type:"boots",tier:2}

#golden_chestplate
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:golden_chestplate[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:golden_chestplate",type:"chestplate",tier:2}

#golden_helmet
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:golden_helmet[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:golden_helmet",type:"helmet",tier:2}

#golden_hoe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:golden_hoe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:golden_hoe",type:"hoe",tier:2}

#golden_leggings
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:golden_leggings[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:golden_leggings",type:"leggings",tier:2}

#golden_pickaxe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:golden_pickaxe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:golden_pickaxe",type:"pickaxe",tier:2}

#golden_shovel
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:golden_shovel[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:golden_shovel",type:"shovel",tier:2}

#golden_sword
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:golden_sword[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:golden_sword",type:"sword",tier:2}

#iron_axe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:iron_axe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:iron_axe",type:"axe",tier:4}

#iron_boots
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:iron_boots[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:iron_boots",type:"boots",tier:4}

#iron_chestplate
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:iron_chestplate[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:iron_chestplate",type:"chestplate",tier:4}

#iron_helmet
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:iron_helmet[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:iron_helmet",type:"helmet",tier:4}

#iron_hoe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:iron_hoe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:iron_hoe",type:"hoe",tier:4}

#iron_leggings
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:iron_leggings[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:iron_leggings",type:"leggings",tier:4}

#iron_pickaxe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:iron_pickaxe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:iron_pickaxe",type:"pickaxe",tier:4}

#iron_shovel
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:iron_shovel[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:iron_shovel",type:"shovel",tier:4}

#iron_sword
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:iron_sword[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:iron_sword",type:"sword",tier:4}

#leather_boots
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:leather_boots[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:leather_boots",type:"boots",tier:1}

#leather_chestplate
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:leather_chestplate[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:leather_chestplate",type:"chestplate",tier:1}

#leather_helmet
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:leather_helmet[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:leather_helmet",type:"helmet",tier:1}

#leather_leggings
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:leather_leggings[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:leather_leggings",type:"leggings",tier:1}

#netherite_axe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:netherite_axe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:netherite_axe",type:"axe",tier:6}

#netherite_boots
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:netherite_boots[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:netherite_boots",type:"boots",tier:6}

#netherite_chestplate
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:netherite_chestplate[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:netherite_chestplate",type:"chestplate",tier:6}

#netherite_helmet
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:netherite_helmet[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:netherite_helmet",type:"helmet",tier:6}

#netherite_hoe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:netherite_hoe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:netherite_hoe",type:"hoe",tier:6}

#netherite_leggings
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:netherite_leggings[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:netherite_leggings",type:"leggings",tier:6}

#netherite_pickaxe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:netherite_pickaxe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:netherite_pickaxe",type:"pickaxe",tier:6}

#netherite_shovel
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:netherite_shovel[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:netherite_shovel",type:"shovel",tier:6}

#netherite_sword
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:netherite_sword[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:netherite_sword",type:"sword",tier:6}

#stone_axe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:stone_axe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:stone_axe",type:"axe",tier:3}

#stone_hoe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:stone_hoe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:stone_hoe",type:"hoe",tier:3}

#stone_pickaxe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:stone_pickaxe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:stone_pickaxe",type:"pickaxe",tier:3}

#stone_shovel
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:stone_shovel[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:stone_shovel",type:"shovel",tier:3}

#stone_sword
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:stone_sword[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:stone_sword",type:"sword",tier:3}

#wooden_axe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:wooden_axe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:wooden_axe",type:"axe",tier:1}

#wooden_hoe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:wooden_hoe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:wooden_hoe",type:"hoe",tier:1}

#wooden_pickaxe
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:wooden_pickaxe[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:wooden_pickaxe",type:"pickaxe",tier:1}

#wooden_shovel
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:wooden_shovel[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:wooden_shovel",type:"shovel",tier:1}

#wooden_sword
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:wooden_sword[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:wooden_sword",type:"sword",tier:1}

#enchanted_book
execute store success storage roguecraft:master success byte 1 run clear @s minecraft:enchanted_book[!minecraft:custom_data] 0
execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/scan_init {item:"minecraft:enchanted_book",type:"enchanted_book",tier:0}


#execute if data storage roguecraft:master {success:1b} run function roguecraft:equipment_upgrades/get_items
#minecraft:bow
#minecraft:crossbow
#minecraft:chainmail_boots
#minecraft:chainmail_chestplate
#minecraft:chainmail_helmet
#minecraft:chainmail_leggings
#minecraft:diamond_axe
#minecraft:diamond_boots
#minecraft:diamond_chestplate
#minecraft:diamond_helmet
#minecraft:diamond_hoe
#minecraft:diamond_leggings
#minecraft:diamond_pickaxe
#minecraft:diamond_shovel
#minecraft:diamond_sword
#minecraft:golden_axe
#minecraft:golden_boots
#minecraft:golden_chestplate
#minecraft:golden_helmet
#minecraft:golden_hoe
#minecraft:golden_leggings
#minecraft:golden_pickaxe
#minecraft:golden_shovel
#minecraft:golden_sword
#minecraft:iron_axe
#minecraft:iron_boots
#minecraft:iron_chestplate
#minecraft:iron_helmet
#minecraft:iron_hoe
#minecraft:iron_leggings
#minecraft:iron_pickaxe
#minecraft:iron_shovel
#minecraft:iron_sword
#minecraft:leather_boots
#minecraft:leather_chestplate
#minecraft:leather_helmet
#minecraft:leather_leggings
#minecraft:netherite_axe
#minecraft:netherite_boots
#minecraft:netherite_chestplate
#minecraft:netherite_helmet
#minecraft:netherite_hoe
#minecraft:netherite_leggings
#minecraft:netherite_pickaxe
#minecraft:netherite_shovel
#minecraft:netherite_sword
#minecraft:stone_axe
#minecraft:stone_hoe
#minecraft:stone_pickaxe
#minecraft:stone_shovel
#minecraft:stone_sword
#minecraft:wooden_axe
#minecraft:wooden_hoe
#minecraft:wooden_pickaxe
#minecraft:wooden_shovel
#minecraft:wooden_sword