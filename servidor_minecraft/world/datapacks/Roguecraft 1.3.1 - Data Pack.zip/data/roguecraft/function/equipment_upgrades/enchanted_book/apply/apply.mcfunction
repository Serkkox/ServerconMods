#check if level is higher
$execute if score @s mid_run_$(current_piece)_$(current_book_enchantment)_level matches $(current_book_level).. run return 0

#presentation
$tellraw @s {"translate":"roguecraft.equipment_upgrades.enchantment","color":"green","with":[{"translate":"roguecraft.equipment_upgrades.$(current_piece)"},{"translate":"enchantment.minecraft.$(current_enchantment)"},{"score":{"name":"@s","objective":"mid_run_$(current_piece)_$(current_enchantment)_level"}},"$(current_book_level)"]}
data modify storage roguecraft:master global_equipment_change set value 1b

function roguecraft:info_messages/tell {type:"mid_run_upgrades"}

#advancement
advancement grant @s only minecraft:story/enchant_item

#set value
$scoreboard players set @s mid_run_$(current_piece)_$(current_enchantment)_level $(current_book_level)
$scoreboard players set @s mid_run_unapplied_$(current_piece) 1
scoreboard players set @s mid_run_unapplied_changes 1

data modify storage roguecraft:master equipment_upgrades.book_success set value 1b