## Set mid run upgrades scores
# tools
scoreboard players operation @s mid_run_sword_level = @s tool
scoreboard players operation @s mid_run_pickaxe_level = @s tool
scoreboard players set @s[scores={tool=..2}] mid_run_pickaxe_level 2
scoreboard players operation @s mid_run_axe_level = @s tool
scoreboard players operation @s mid_run_shovel_level = @s tool
scoreboard players operation @s mid_run_hoe_level = @s tool
scoreboard players operation @s mid_run_bow_level = @s bow

execute if score @s mid_run_sword_level matches 2.. run scoreboard players add @s mid_run_sword_level 1
execute if score @s mid_run_pickaxe_level matches 2.. run scoreboard players add @s mid_run_pickaxe_level 1
execute if score @s mid_run_axe_level matches 2.. run scoreboard players add @s mid_run_axe_level 1
execute if score @s mid_run_shovel_level matches 2.. run scoreboard players add @s mid_run_shovel_level 1
execute if score @s mid_run_hoe_level matches 2.. run scoreboard players add @s mid_run_hoe_level 1

#execute if score @s tool matches 

# armor
scoreboard players operation @s mid_run_helmet_level = @s armor
scoreboard players operation @s mid_run_chestplate_level = @s armor
scoreboard players operation @s mid_run_leggings_level = @s armor
scoreboard players operation @s mid_run_boots_level = @s armor
# sword
scoreboard players operation @s mid_run_sword_sharpness_level = @s sharpness
scoreboard players set @s mid_run_sword_smite_level 0
scoreboard players set @s mid_run_sword_bane_of_arthropods_level 0
scoreboard players set @s mid_run_sword_fire_aspect_level 0
scoreboard players operation @s mid_run_sword_looting_level = @s looting
scoreboard players operation @s mid_run_sword_sweeping_edge_level = @s sweeping
scoreboard players set @s mid_run_sword_knockback_level 0
#pickaxe
scoreboard players operation @s mid_run_pickaxe_efficiency_level = @s efficiency
scoreboard players operation @s mid_run_pickaxe_fortune_level = @s fortune
# axe
scoreboard players operation @s mid_run_axe_sharpness_level = @s sharpness
scoreboard players set @s mid_run_axe_smite_level 0
scoreboard players set @s mid_run_axe_bane_of_arthropods_level 0
scoreboard players set @s mid_run_axe_fire_aspect_level 0
scoreboard players operation @s mid_run_axe_looting_level = @s looting
scoreboard players set @s mid_run_axe_knockback_level 0
scoreboard players operation @s mid_run_axe_efficiency_level = @s efficiency
scoreboard players operation @s mid_run_axe_fortune_level = @s fortune
# shovel
scoreboard players operation @s mid_run_shovel_efficiency_level = @s efficiency
scoreboard players operation @s mid_run_shovel_fortune_level = @s fortune
# hoe
scoreboard players operation @s mid_run_hoe_efficiency_level = @s efficiency
scoreboard players operation @s mid_run_hoe_fortune_level = @s fortune
# bow
scoreboard players operation @s mid_run_bow_power_level = @s power
scoreboard players operation @s mid_run_bow_punch_level = @s punch
scoreboard players operation @s mid_run_bow_flame_level = @s flame
scoreboard players operation @s mid_run_bow_infinity_level = @s infinity
scoreboard players operation @s mid_run_bow_piercing_level = @s piercing
scoreboard players operation @s mid_run_bow_multishot_level = @s multishot
# helmet
scoreboard players operation @s mid_run_helmet_protection_level = @s protection
scoreboard players set @s mid_run_helmet_fire_protection_level 0
scoreboard players set @s mid_run_helmet_blast_protection_level 0
scoreboard players set @s mid_run_helmet_projectile_protection_level 0
scoreboard players operation @s mid_run_helmet_thorns_level = @s thorns
scoreboard players operation @s mid_run_helmet_respiration_level = @s respiration
scoreboard players operation @s mid_run_helmet_aqua_affinity_level = @s aqua_affinity
# chestplate
scoreboard players operation @s mid_run_chestplate_protection_level = @s protection
scoreboard players set @s mid_run_chestplate_fire_protection_level 0
scoreboard players set @s mid_run_chestplate_blast_protection_level 0
scoreboard players set @s mid_run_chestplate_projectile_protection_level 0
scoreboard players operation @s mid_run_chestplate_thorns_level = @s thorns
# leggings
scoreboard players operation @s mid_run_leggings_protection_level = @s protection
scoreboard players set @s mid_run_leggings_fire_protection_level 0
scoreboard players set @s mid_run_leggings_blast_protection_level 0
scoreboard players set @s mid_run_leggings_projectile_protection_level 0
scoreboard players operation @s mid_run_leggings_thorns_level = @s thorns
scoreboard players operation @s mid_run_leggings_swift_sneak_level = @s swift_sneak
# boots
scoreboard players operation @s mid_run_boots_protection_level = @s protection
scoreboard players set @s mid_run_boots_fire_protection_level 0
scoreboard players set @s mid_run_boots_blast_protection_level 0
scoreboard players set @s mid_run_boots_projectile_protection_level 0
scoreboard players operation @s mid_run_boots_thorns_level = @s thorns
scoreboard players operation @s mid_run_boots_feather_falling_level = @s feather_falling
scoreboard players operation @s mid_run_boots_soul_speed_level = @s soul_speed
scoreboard players set @s mid_run_boots_depth_strider_level 0

# unapplied
scoreboard players set @s mid_run_unapplied_changes 0
scoreboard players set @s mid_run_unapplied_sword 0
scoreboard players set @s mid_run_unapplied_pickaxe 0
scoreboard players set @s mid_run_unapplied_axe 0
scoreboard players set @s mid_run_unapplied_shovel 0
scoreboard players set @s mid_run_unapplied_hoe 0
scoreboard players set @s mid_run_unapplied_bow 0
scoreboard players set @s mid_run_unapplied_boots 0
scoreboard players set @s mid_run_unapplied_leggings 0
scoreboard players set @s mid_run_unapplied_chestplate 0
scoreboard players set @s mid_run_unapplied_helmet 0

# reset if not in loadout
execute unless items entity @s enderchest.* minecraft:totem_of_undying[minecraft:custom_model_data=900005] run scoreboard players set @s mid_run_sword_level 0
execute unless items entity @s enderchest.* minecraft:totem_of_undying[minecraft:custom_model_data=900003] run scoreboard players set @s mid_run_pickaxe_level 0
execute unless items entity @s enderchest.* minecraft:totem_of_undying[minecraft:custom_model_data=900001] run scoreboard players set @s mid_run_axe_level 0
execute unless items entity @s enderchest.* minecraft:totem_of_undying[minecraft:custom_model_data=900004] run scoreboard players set @s mid_run_shovel_level 0
execute unless items entity @s enderchest.* minecraft:totem_of_undying[minecraft:custom_model_data=900002] run scoreboard players set @s mid_run_hoe_level 0
execute unless items entity @s enderchest.* minecraft:totem_of_undying[minecraft:custom_model_data=900007] run scoreboard players set @s mid_run_bow_level 0