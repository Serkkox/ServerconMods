##macros
#enchantment
#weapon, tool, bow, armor, boots, helmet, leggings

##debug
#$say weapon: $(weapon)
#$say tool: $(tool)
#$say bow: $(bow)
#$say armor: $(armor)
#$say boots: $(boots)
#$say helmet: $(helmet)
#$say leggings: $(leggings)

#add to storage
$data modify storage roguecraft:master equipment_upgrades.current_book_enchantment set value $(enchantment)

#set level
$data modify storage roguecraft:master equipment_upgrades.current_book_level set from storage roguecraft:master equipment_upgrades."minecraft:$(enchantment)"

#apply
$execute if score 1 int matches $(weapon) run function roguecraft:equipment_upgrades/enchanted_book/apply/weapon
$execute if score 1 int matches $(sword) run function roguecraft:equipment_upgrades/enchanted_book/apply/singular {type:"sword"}
$execute if score 1 int matches $(tool) run function roguecraft:equipment_upgrades/enchanted_book/apply/tool
$execute if score 1 int matches $(bow) run function roguecraft:equipment_upgrades/enchanted_book/apply/singular {type:"bow"}
$execute if score 1 int matches $(armor) run function roguecraft:equipment_upgrades/enchanted_book/apply/armor
$execute if score 1 int matches $(boots) run function roguecraft:equipment_upgrades/enchanted_book/apply/singular {type:"boots"}
$execute if score 1 int matches $(helmet) run function roguecraft:equipment_upgrades/enchanted_book/apply/singular {type:"helmet"}
$execute if score 1 int matches $(leggings) run function roguecraft:equipment_upgrades/enchanted_book/apply/singular {type:"leggings"}