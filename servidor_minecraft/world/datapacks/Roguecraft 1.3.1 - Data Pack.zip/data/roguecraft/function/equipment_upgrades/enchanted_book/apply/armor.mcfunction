#helmet
data modify storage roguecraft:master equipment_upgrades.current_piece set value "helmet"
function roguecraft:equipment_upgrades/enchanted_book/apply/apply with storage roguecraft:master equipment_upgrades

#chestplate
data modify storage roguecraft:master equipment_upgrades.current_piece set value "chestplate"
function roguecraft:equipment_upgrades/enchanted_book/apply/apply with storage roguecraft:master equipment_upgrades

#leggings
data modify storage roguecraft:master equipment_upgrades.current_piece set value "leggings"
function roguecraft:equipment_upgrades/enchanted_book/apply/apply with storage roguecraft:master equipment_upgrades

#boots
data modify storage roguecraft:master equipment_upgrades.current_piece set value "boots"
function roguecraft:equipment_upgrades/enchanted_book/apply/apply with storage roguecraft:master equipment_upgrades