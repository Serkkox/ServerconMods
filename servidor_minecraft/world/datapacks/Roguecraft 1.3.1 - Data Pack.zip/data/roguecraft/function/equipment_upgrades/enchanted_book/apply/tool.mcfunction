#pickaxe
data modify storage roguecraft:master equipment_upgrades.current_piece set value "pickaxe"
function roguecraft:equipment_upgrades/enchanted_book/apply/apply with storage roguecraft:master equipment_upgrades

#axe
data modify storage roguecraft:master equipment_upgrades.current_piece set value "axe"
function roguecraft:equipment_upgrades/enchanted_book/apply/apply with storage roguecraft:master equipment_upgrades

#shovel
data modify storage roguecraft:master equipment_upgrades.current_piece set value "shovel"
function roguecraft:equipment_upgrades/enchanted_book/apply/apply with storage roguecraft:master equipment_upgrades

#hoe
data modify storage roguecraft:master equipment_upgrades.current_piece set value "hoe"
function roguecraft:equipment_upgrades/enchanted_book/apply/apply with storage roguecraft:master equipment_upgrades