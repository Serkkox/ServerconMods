tellraw @s {"translate":"roguecraft.equipment_upgrades.gold_upgrade","color":"red"}
playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5
playsound minecraft:block.note_block.didgeridoo master @s ~ ~ ~ 1 0.5


$execute if score @s scan_index matches ..35 unless items entity @s container.$(scan_index) * run return 0
execute if score @s scan_index matches -106 unless items entity @s weapon.offhand * run return 0

$execute if score @s scan_index matches ..35 run item modify entity @s container.$(scan_index) roguecraft:decrease
execute if score @s scan_index matches -106 run item modify entity @s weapon.offhand roguecraft:decrease

execute at @s run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 1 1
xp add @s 15