#this value will decide of the book is consumed or not
data modify storage roguecraft:master equipment_upgrades.book_success set value 0b

#get advancements
function roguecraft:equipment_upgrades/enchanted_book/get_enchantments with storage roguecraft:master equipment_upgrades

#remove book
execute if data storage roguecraft:master {equipment_upgrades:{book_success:1b}} run function roguecraft:equipment_upgrades/enchanted_book/remove with storage roguecraft:master equipment_upgrades

#exhaust book
execute unless data storage roguecraft:master {equipment_upgrades:{book_success:1b}} run function roguecraft:equipment_upgrades/enchanted_book/exhaust with storage roguecraft:master equipment_upgrades

#tellraw @a {"storage":"roguecraft:master","nbt":"equipment_upgrades.scan_index"}
#$data modify storage roguecraft:master equipment_upgrades merge from entity @s Inventory[{Slot:$(scan_index)b}].components."minecraft:enchantments".levels