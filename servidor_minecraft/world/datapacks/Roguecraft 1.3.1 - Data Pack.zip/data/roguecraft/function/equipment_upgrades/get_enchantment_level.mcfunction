#what a stupid name this was, this is way more than just getting the enchantment level. once again, fuck you, mono from several months ago
#edit: WHY WAS IT NAMED THIS, AND WHY IS THERE STUFF IN HERE THAT SHOULDN'T BE HERE
#EVERYTHING BROKE BECAUSE OF THIS AND IT TOOK ME HOURS TO FIGURE THIS OUT
data modify storage roguecraft:master equipment_upgrades.current_level set value 0
$data modify storage roguecraft:master equipment_upgrades.current_level set from storage roguecraft:master equipment_upgrades."minecraft:$(current_enchantment)"

execute unless data storage roguecraft:master {equipment_upgrades:{current_level:0}} run function roguecraft:equipment_upgrades/compare_enchantments with storage roguecraft:master equipment_upgrades
$execute store result storage roguecraft:master equipment_upgrades.previous_tier byte 1 run scoreboard players get @s mid_run_$(scan_type)_level
function roguecraft:equipment_upgrades/compare_tiers with storage roguecraft:master equipment_upgrades

execute if data storage roguecraft:master equipment_upgrades.new_equipment run return run function roguecraft:equipment_upgrades/new_equipment/get_type with storage roguecraft:master equipment_upgrades


$execute if score @s scan_index matches ..35 if data storage roguecraft:master {equipment_upgrades:{change:1b}} run item modify entity @s container.$(scan_index) roguecraft:decrease
execute if score @s scan_index matches -106 if data storage roguecraft:master {equipment_upgrades:{change:1b}} run item modify entity @s weapon.offhand roguecraft:decrease
execute if score @s scan_index matches 100 if data storage roguecraft:master {equipment_upgrades:{change:1b}} run item modify entity @s armor.feet roguecraft:decrease
execute if score @s scan_index matches 101 if data storage roguecraft:master {equipment_upgrades:{change:1b}} run item modify entity @s armor.legs roguecraft:decrease
execute if score @s scan_index matches 102 if data storage roguecraft:master {equipment_upgrades:{change:1b}} run item modify entity @s armor.chest roguecraft:decrease
execute if score @s scan_index matches 103 if data storage roguecraft:master {equipment_upgrades:{change:1b}} run item modify entity @s armor.head roguecraft:decrease

$execute if data entity @s Inventory[{Slot:$(scan_index)b}].components."minecraft:custom_data" run return run data modify storage roguecraft:master equipment_upgrades.change set value 0b

execute if data storage roguecraft:master {equipment_upgrades:{change:1b}} run return 0

$execute if score @s scan_index matches ..35 unless items entity @s container.$(scan_index) * run return 0
execute if score @s scan_index matches -106 unless items entity @s weapon.offhand * run return 0
execute if score @s scan_index matches 100 unless items entity @s armor.feet * run return 0
execute if score @s scan_index matches 101 unless items entity @s armor.legs * run return 0
execute if score @s scan_index matches 102 unless items entity @s armor.chest * run return 0
execute if score @s scan_index matches 103 unless items entity @s armor.head * run return 0

$execute if score @s scan_index matches ..35 run item modify entity @s container.$(scan_index) roguecraft:decrease
execute if score @s scan_index matches -106 run item modify entity @s weapon.offhand roguecraft:decrease
execute if score @s scan_index matches 100 run item modify entity @s armor.feet roguecraft:decrease
execute if score @s scan_index matches 101 run item modify entity @s armor.legs roguecraft:decrease
execute if score @s scan_index matches 102 run item modify entity @s armor.chest roguecraft:decrease
execute if score @s scan_index matches 103 run item modify entity @s armor.head roguecraft:decrease

execute at @s run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 1 1
xp add @s 15