data modify storage roguecraft:master equipment_upgrades.current_item.type set value "shovel"

function roguecraft:equipment_upgrades/check_starter_equipment/tools with storage roguecraft:master equipment_upgrades.current_item