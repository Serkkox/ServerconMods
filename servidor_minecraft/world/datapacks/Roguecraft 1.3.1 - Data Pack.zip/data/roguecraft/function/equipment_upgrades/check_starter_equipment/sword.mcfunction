data modify storage roguecraft:master equipment_upgrades.current_item.type set value "sword"
execute as @s[scores={golden_scythe=589000069}] run return run scoreboard players set @s mid_run_unapplied_sword 0

function roguecraft:equipment_upgrades/check_starter_equipment/tools with storage roguecraft:master equipment_upgrades.current_item