data modify storage roguecraft:master equipment_upgrades.current_item.type set value "pickaxe"

function roguecraft:equipment_upgrades/check_starter_equipment/tools with storage roguecraft:master equipment_upgrades.current_item