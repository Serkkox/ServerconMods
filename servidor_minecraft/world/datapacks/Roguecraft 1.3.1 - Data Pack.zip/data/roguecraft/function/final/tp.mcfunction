schedule clear roguecraft:final/tp

gamemode adventure @a[tag=!garden,tag=!hub]
scoreboard players set @a[tag=!garden,tag=!hub] true_gamemode 2

clear @a

execute in minecraft:overworld run tp @a 0.5 135.00 26.5 180 -6

effect clear @a
execute as @a run attribute @s minecraft:movement_speed base set 0.1

effect give @a minecraft:resistance infinite 4 true
effect give @a minecraft:saturation infinite 0 true
effect give @a minecraft:darkness 1 0 true
effect give @s minecraft:blindness 1 0 true

tag @a add victory
tag @a remove end

execute as @a run function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/dirt_walker/disable_bossbar"}
execute as @a run function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/liquid_walker/disable_bossbar"}

scoreboard players set @a dirt_timer 0
scoreboard players set @a liquid_timer 0

bossbar set minecraft:difficulty players @s[tag=tjrrtjrtaesf]
function roguecraft:misc/execute_with_player_id {function:"roguecraft:ability/set_mana_bar"}

schedule function roguecraft:final/spawn 3t
function roguecraft:final/tp_effects