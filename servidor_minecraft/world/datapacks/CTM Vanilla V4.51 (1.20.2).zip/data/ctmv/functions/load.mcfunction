#Message and sounds
tellraw @a {"text": "Datapack reloaded succesfully!", "color": "green"}
execute as @a at @s run playsound entity.experience_orb.pickup master @s ~ ~ ~