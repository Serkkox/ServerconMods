#Set blocks and particles
execute if score time MonumentSequence matches 90 at @e[tag=monument_coal] run particle dust 0.157 0.157 0.157 1 ~ ~ ~ 0.7 0.7 0.1 0 100 force
execute if score time MonumentSequence matches 90 at @e[tag=monument_coal] run summon firework_rocket ~ ~ ~1 {LifeTime:0,FireworksItem:{id:"firework_rocket",Count:1,tag:{Fireworks:{Explosions:[{Type:0,Trail:1,Colors:[I;2829099]}],Flight:1}}}}
execute if score time MonumentSequence matches 90 at @e[tag=monument_coal] run setblock ~ ~ ~1 coal_block
execute if score time MonumentSequence matches 90 at @e[tag=monument_coal] run playsound entity.evoker.cast_spell block @a ~ ~ ~1 2 1 0

execute if score time MonumentSequence matches 95 at @e[tag=monument_iron] run particle dust 0.827 0.827 0.827 1 ~ ~ ~ 0.7 0.7 0.1 0 100 force
execute if score time MonumentSequence matches 95 at @e[tag=monument_iron] run summon firework_rocket ~ ~ ~1 {LifeTime:0,FireworksItem:{id:"firework_rocket",Count:1,tag:{Fireworks:{Explosions:[{Type:0,Trail:1,Colors:[I;13619151]}],Flight:1}}}}
execute if score time MonumentSequence matches 95 at @e[tag=monument_iron] run setblock ~ ~ ~1 iron_block
execute if score time MonumentSequence matches 95 at @e[tag=monument_iron] run playsound entity.evoker.cast_spell block @a ~ ~ ~1 2 0.8 0

execute if score time MonumentSequence matches 100 at @e[tag=monument_gold] run particle dust 1 0.769 0 1 ~ ~ ~ 0.7 0.7 0.1 0 100 force
execute if score time MonumentSequence matches 100 at @e[tag=monument_gold] run summon firework_rocket ~ ~ ~1 {LifeTime:0,FireworksItem:{id:"firework_rocket",Count:1,tag:{Fireworks:{Explosions:[{Type:0,Trail:1,Colors:[I;16763904]}],Flight:1}}}}
execute if score time MonumentSequence matches 100 at @e[tag=monument_gold] run setblock ~ ~ ~1 gold_block
execute if score time MonumentSequence matches 100 at @e[tag=monument_gold] run playsound entity.evoker.cast_spell block @a ~ ~ ~1 2 0.8 0

execute if score time MonumentSequence matches 106 at @e[tag=monument_lapis] run particle dust 0 0.384 1 1 ~ ~ ~ 0.7 0.7 0.1 0 100 force
execute if score time MonumentSequence matches 106 at @e[tag=monument_lapis] run summon firework_rocket ~ ~ ~1 {LifeTime:0,FireworksItem:{id:"firework_rocket",Count:1,tag:{Fireworks:{Explosions:[{Type:0,Trail:1,Colors:[I;15615]}],Flight:1}}}}
execute if score time MonumentSequence matches 106 at @e[tag=monument_lapis] run setblock ~ ~ ~1 lapis_block
execute if score time MonumentSequence matches 106 at @e[tag=monument_lapis] run playsound entity.evoker.cast_spell block @a ~ ~ ~1 2 0.8 0

execute if score time MonumentSequence matches 112 at @e[tag=monument_redstone] run particle dust 0.788 0 0 1 ~ ~ ~ 0.7 0.7 0.1 0 100 force
execute if score time MonumentSequence matches 112 at @e[tag=monument_redstone] run summon firework_rocket ~ ~ ~1 {LifeTime:0,FireworksItem:{id:"firework_rocket",Count:1,tag:{Fireworks:{Explosions:[{Type:0,Trail:1,Colors:[I;13172736]}],Flight:1}}}}
execute if score time MonumentSequence matches 112 at @e[tag=monument_redstone] run setblock ~ ~ ~1 redstone_block
execute if score time MonumentSequence matches 112 at @e[tag=monument_redstone] run playsound entity.evoker.cast_spell block @a ~ ~ ~1 2 0.8 0

execute if score time MonumentSequence matches 118 at @e[tag=monument_emerald] run particle dust 0.098 0.831 0 1 ~ ~ ~ 0.7 0.7 0.1 0 100 force
execute if score time MonumentSequence matches 118 at @e[tag=monument_emerald] run summon firework_rocket ~ ~ ~1 {LifeTime:0,FireworksItem:{id:"firework_rocket",Count:1,tag:{Fireworks:{Explosions:[{Type:0,Trail:1,Colors:[I;55058]}],Flight:1}}}}
execute if score time MonumentSequence matches 118 at @e[tag=monument_emerald] run setblock ~ ~ ~1 emerald_block
execute if score time MonumentSequence matches 118 at @e[tag=monument_emerald] run playsound entity.evoker.cast_spell block @a ~ ~ ~1 2 0.8 0

execute if score time MonumentSequence matches 123 at @e[tag=monument_diamond] run particle dust 0 1 0.867 1 ~ ~ ~ 0.7 0.7 0.1 0 100 force
execute if score time MonumentSequence matches 123 at @e[tag=monument_diamond] run summon firework_rocket ~ ~ ~1 {LifeTime:0,FireworksItem:{id:"firework_rocket",Count:1,tag:{Fireworks:{Explosions:[{Type:0,Trail:1,Colors:[I;65518]}],Flight:1}}}}
execute if score time MonumentSequence matches 123 at @e[tag=monument_diamond] run setblock ~ ~ ~1 diamond_block
execute if score time MonumentSequence matches 123 at @e[tag=monument_diamond] run playsound entity.evoker.cast_spell block @a ~ ~ ~1 2 0.8 0

execute if score time MonumentSequence matches 129 at @e[tag=monument_copper] run particle dust 0.612 0.31 0.212 1 ~ ~ ~ 0.7 0.7 0.1 0 100 force
execute if score time MonumentSequence matches 129 at @e[tag=monument_copper] run summon firework_rocket ~ ~ ~1 {LifeTime:0,FireworksItem:{id:"firework_rocket",Count:1,tag:{Fireworks:{Explosions:[{Type:0,Trail:1,Colors:[I;11030066]}],Flight:1}}}}
execute if score time MonumentSequence matches 129 at @e[tag=monument_copper] run setblock ~ ~ ~1 waxed_copper_block
execute if score time MonumentSequence matches 129 at @e[tag=monument_copper] run playsound entity.evoker.cast_spell block @a ~ ~ ~1 2 0.8 0
