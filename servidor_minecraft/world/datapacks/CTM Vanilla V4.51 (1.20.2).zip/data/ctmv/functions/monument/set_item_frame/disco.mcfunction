#Set items from Normal mode to the item frames
execute if score time MonumentSequence matches 0 as @e[tag=monument_white] run data merge entity @s {Item:{id:"minecraft:music_disc_13",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 5 as @e[tag=monument_orange] run data merge entity @s {Item:{id:"minecraft:music_disc_cat",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 10 as @e[tag=monument_magenta] run data merge entity @s {Item:{id:"minecraft:music_disc_blocks",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 16 as @e[tag=monument_light_blue] run data merge entity @s {Item:{id:"minecraft:music_disc_chirp",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 22 as @e[tag=monument_yellow] run data merge entity @s {Item:{id:"minecraft:music_disc_far",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 28 as @e[tag=monument_lime] run data merge entity @s {Item:{id:"minecraft:music_disc_mall",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 33 as @e[tag=monument_pink] run data merge entity @s {Item:{id:"minecraft:music_disc_mellohi",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 39 as @e[tag=monument_gray] run data merge entity @s {Item:{id:"minecraft:music_disc_stal",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 44 as @e[tag=monument_light_gray] run data merge entity @s {Item:{id:"minecraft:music_disc_strad",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 50 as @e[tag=monument_cyan] run data merge entity @s {Item:{id:"minecraft:music_disc_ward",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 56 as @e[tag=monument_purple] run data merge entity @s {Item:{id:"minecraft:music_disc_11",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 61 as @e[tag=monument_blue] run data merge entity @s {Item:{id:"minecraft:music_disc_wait",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 67 as @e[tag=monument_brown] run data merge entity @s {Item:{id:"minecraft:music_disc_otherside",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 72 as @e[tag=monument_green] run data merge entity @s {Item:{id:"minecraft:music_disc_5",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 78 as @e[tag=monument_red] run data merge entity @s {Item:{id:"minecraft:music_disc_pigstep",Count:1b,tag:{Enchantments:[{}]}}}
execute if score time MonumentSequence matches 83 as @e[tag=monument_black] run data merge entity @s {Item:{id:"minecraft:music_disc_relic",Count:1b,tag:{Enchantments:[{}]}}}